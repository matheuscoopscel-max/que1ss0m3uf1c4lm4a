import { NestFactory } from '@nestjs/core';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { NestExpressApplication } from '@nestjs/platform-express';
import helmet from 'helmet';
import * as compression from 'compression';
import * as cookieParser from 'cookie-parser';
import { AppModule } from './app.module';
import { ConfigService } from '@nestjs/config';
import { HttpExceptionFilter } from './common/filters/http-exception.filter';
import { TransformInterceptor } from './common/interceptors/transform.interceptor';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor';
import { PrismaService } from './common/services/prisma.service';
import { RedisIoAdapter } from './modules/websocket/redis-io.adapter';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    logger: ['error', 'warn', 'log', 'debug'],
    bufferLogs: true,
  });

  const config = app.get(ConfigService);
  const nodeEnv  = config.get<string>('NODE_ENV', 'development');
  const port     = config.get<number>('PORT', 3001);
  const frontendUrl = config.get<string>('FRONTEND_URL', 'http://localhost:3000');
  const adminUrl    = config.get<string>('ADMIN_URL', 'http://localhost:3002');

  // Prisma graceful shutdown
  const prismaService = app.get(PrismaService);
  await prismaService.enableShutdownHooks(app);

  // WebSocket com Redis Pub/Sub
  const redisIoAdapter = new RedisIoAdapter(app, config);
  await redisIoAdapter.connectToRedis();
  app.useWebSocketAdapter(redisIoAdapter);

  // Segurança: Helmet + CSP
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc:  ["'self'"],
          scriptSrc:   ["'self'", "'strict-dynamic'"],
          styleSrc:    ["'self'", "'unsafe-inline'"],
          imgSrc:      ["'self'", 'data:', 'blob:', '*.aureusbet.com'],
          connectSrc:  ["'self'", 'wss://*.aureusbet.com', 'https://polygon-rpc.com'],
          fontSrc:     ["'self'", 'data:'],
          objectSrc:   ["'none'"],
          frameSrc:    ["'none'"],
        },
      },
      hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
    }),
  );

  app.use(compression());
  app.use(cookieParser(config.get<string>('JWT_SECRET')));
  app.set('trust proxy', 1); // Proxy Cloudflare/Nginx

  // CORS estrito
  app.enableCors({
    origin: [frontendUrl, adminUrl].filter(Boolean),
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-CSRF-Token', 'X-Temp-Token'],
    credentials: true,
    maxAge: 86400,
  });

  // Prefix + versioning
  app.setGlobalPrefix('api');
  app.enableVersioning({ type: VersioningType.URI, defaultVersion: '1' });

  // Pipes globais
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  // Filtros + Interceptors globais
  app.useGlobalFilters(new HttpExceptionFilter());
  app.useGlobalInterceptors(new TransformInterceptor(), new LoggingInterceptor());

  // Swagger apenas fora de produção
  if (nodeEnv !== 'production') {
    const swaggerCfg = new DocumentBuilder()
      .setTitle('AureusBet API')
      .setDescription('Enterprise iGaming Platform — API Documentation')
      .setVersion('1.0')
      .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }, 'JWT')
      .addCookieAuth('refresh_token')
      .addTag('Auth')
      .addTag('Users')
      .addTag('Games')
      .addTag('Payments')
      .addTag('Blockchain')
      .addTag('Collectibles')
      .addTag('Market')
      .addTag('Admin')
      .build();
    const document = SwaggerModule.createDocument(app, swaggerCfg);
    SwaggerModule.setup('api/docs', app, document);
  }

  await app.listen(port, '0.0.0.0');
  console.log(`\n🎰 AureusBet API → http://localhost:${port}/api`);
  console.log(`📚 Swagger       → http://localhost:${port}/api/docs`);
  console.log(`🌍 Ambiente      → ${nodeEnv}\n`);
}

bootstrap();
