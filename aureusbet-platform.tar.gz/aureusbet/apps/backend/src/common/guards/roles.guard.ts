import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { UserRole } from '@prisma/client';
import { ROLES_KEY } from '../decorators/roles.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<UserRole[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!required || required.length === 0) return true;

    const { user } = context.switchToHttp().getRequest();
    if (!user) throw new ForbiddenException('Não autenticado.');

    const roleHierarchy: Record<UserRole, number> = {
      PLAYER: 0, VIP: 1, MODERATOR: 2, ADMIN: 3, SUPER_ADMIN: 4,
    };

    const userLevel  = roleHierarchy[user.role as UserRole] ?? 0;
    const minRequired = Math.min(...required.map(r => roleHierarchy[r] ?? 0));

    if (userLevel < minRequired) {
      throw new ForbiddenException('Permissão insuficiente.');
    }
    return true;
  }
}
