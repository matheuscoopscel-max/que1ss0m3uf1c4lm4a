import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import type { INestApplication } from '@nestjs/common';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  private readonly logger = new Logger(PrismaService.name);

  constructor() {
    super({
      log: [
        { emit: 'event', level: 'query'  },
        { emit: 'event', level: 'error'  },
        { emit: 'event', level: 'warn'   },
      ],
    });

    // Log slow queries em desenvolvimento
    if (process.env.NODE_ENV !== 'production') {
      (this as any).$on('query', (e: any) => {
        if (e.duration > 100) {
          this.logger.warn(`Query lenta (${e.duration}ms): ${e.query}`);
        }
      });
    }

    (this as any).$on('error', (e: any) => {
      this.logger.error('Prisma error:', e);
    });
  }

  async onModuleInit() {
    await this.$connect();
    this.logger.log('PostgreSQL conectado via Prisma');
  }

  async enableShutdownHooks(app: INestApplication) {
    process.on('beforeExit', async () => {
      await app.close();
    });
  }

  /** Executa uma query paginada com cursor */
  async paginate<T>(
    model: any,
    args: { where?: any; orderBy?: any; take?: number; skip?: number; include?: any },
    page = 1,
    perPage = 20,
  ): Promise<{ data: T[]; total: number; page: number; perPage: number; totalPages: number }> {
    const skip = (page - 1) * perPage;
    const [data, total] = await Promise.all([
      model.findMany({ ...args, take: perPage, skip }),
      model.count({ where: args.where }),
    ]);
    return { data, total, page, perPage, totalPages: Math.ceil(total / perPage) };
  }
}
