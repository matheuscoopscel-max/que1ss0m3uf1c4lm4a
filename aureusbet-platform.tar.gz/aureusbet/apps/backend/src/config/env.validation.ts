import { plainToClass } from 'class-transformer';
import { IsString, IsNumber, IsOptional, IsBoolean, validateSync, MinLength, IsUrl } from 'class-validator';

class EnvironmentVariables {
  @IsString() NODE_ENV: string;
  @IsNumber() PORT: number;
  @IsString() @IsUrl() FRONTEND_URL: string;
  @IsString() DATABASE_URL: string;
  @IsString() REDIS_HOST: string;
  @IsNumber() REDIS_PORT: number;
  @IsString() @MinLength(32) JWT_SECRET: string;
  @IsString() @MinLength(32) JWT_REFRESH_SECRET: string;
  @IsString() @MinLength(32) ENCRYPTION_KEY: string;
  @IsString() S3_ENDPOINT: string;
  @IsString() S3_ACCESS_KEY: string;
  @IsString() S3_SECRET_KEY: string;
  @IsString() POLYGON_RPC_URL: string;
  @IsString() AUR_TOKEN_ADDRESS: string;
  @IsString() PLATFORM_WALLET_ADDRESS: string;
  @IsString() PLATFORM_WALLET_PRIVATE_KEY: string;
  @IsString() STRIPE_SECRET_KEY: string;
  @IsString() STRIPE_WEBHOOK_SECRET: string;
  @IsString() SMTP_HOST: string;
  @IsString() SMTP_PASS: string;
  @IsString() @MinLength(32) RNG_SEED_SECRET: string;
  @IsString() @MinLength(32) ADMIN_JWT_SECRET: string;
}

export function validate(config: Record<string, unknown>) {
  const validatedConfig = plainToClass(EnvironmentVariables, config, {
    enableImplicitConversion: true,
  });
  const errors = validateSync(validatedConfig, { skipMissingProperties: false });

  if (errors.length > 0) {
    const msg = errors.map(e => Object.values(e.constraints ?? {}).join(', ')).join('\n');
    throw new Error(`❌ Validação de ambiente falhou:\n${msg}`);
  }
  return validatedConfig;
}
