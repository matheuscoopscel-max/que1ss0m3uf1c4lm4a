import {
  Injectable, Logger, BadRequestException,
  NotFoundException, ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../../common/services/prisma.service';
import { WalletService } from '../payments/wallet.service';
import { AuditService }  from '../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';

const PLATFORM_FEE = 0.05; // 5%

@Injectable()
export class MarketService {
  private readonly logger = new Logger(MarketService.name);

  constructor(
    private readonly prisma:  PrismaService,
    private readonly wallet:  WalletService,
    private readonly audit:   AuditService,
    private readonly emitter: EventEmitter2,
  ) {}

  /** Listar colecionável para venda */
  async list(userId: string, collectibleId: string, priceAur: number, expiresInDays?: number) {
    if (priceAur < 0.1) throw new BadRequestException('Preço mínimo: 0.1 AUR');

    const ownership = await this.prisma.userCollectible.findUnique({
      where:   { userId_collectibleId: { userId, collectibleId } },
      include: { collectible: true },
    });
    if (!ownership) throw new NotFoundException('Você não possui este colecionável.');
    if (ownership.isListed) throw new BadRequestException('Já está listado no mercado.');
    if (!ownership.collectible.isTransferable) throw new ForbiddenException('Este colecionável não pode ser vendido.');

    // Verificar se tem ordem ativa
    const existingOrder = await this.prisma.marketOrder.findFirst({
      where: { sellerId: userId, collectibleId, status: 'OPEN' },
    });
    if (existingOrder) throw new BadRequestException('Já existe uma ordem de venda para este item.');

    const expiresAt = expiresInDays
      ? new Date(Date.now() + expiresInDays * 86400000)
      : undefined;

    const order = await this.prisma.$transaction(async (tx) => {
      await tx.userCollectible.update({
        where: { userId_collectibleId: { userId, collectibleId } },
        data:  { isListed: true },
      });

      return tx.marketOrder.create({
        data: {
          sellerId:          userId,
          collectibleId,
          userCollectibleId: ownership.id,
          priceAur,
          platformFee:       PLATFORM_FEE,
          expiresAt,
        },
        include: { collectible: true },
      });
    });

    await this.audit.log({
      userId,
      action:   'MARKET_LISTED',
      entityId: order.id,
      metadata: { collectibleId, priceAur, expiresAt },
    });

    this.emitter.emit('market.listed', { orderId: order.id, collectibleId, priceAur });
    return order;
  }

  /** Comprar colecionável do mercado */
  async buy(buyerId: string, orderId: string) {
    const order = await this.prisma.marketOrder.findUnique({
      where:   { id: orderId },
      include: { collectible: true, seller: { select: { id: true, username: true } } },
    });

    if (!order) throw new NotFoundException('Ordem não encontrada.');
    if (order.status !== 'OPEN') throw new BadRequestException('Esta ordem não está mais disponível.');
    if (order.sellerId === buyerId) throw new BadRequestException('Você não pode comprar seu próprio item.');

    if (order.expiresAt && order.expiresAt < new Date()) {
      await this.cancelExpired(order.id);
      throw new BadRequestException('Esta ordem expirou.');
    }

    const priceAur   = Number(order.priceAur);
    const feeAmount  = priceAur * PLATFORM_FEE;
    const sellerGets = priceAur - feeAmount;

    // Verificar saldo do comprador
    const balance = await this.wallet.getBalance(buyerId);
    if (balance.aurBalance < priceAur) throw new BadRequestException('Saldo insuficiente.');

    await this.prisma.$transaction(async (tx) => {
      // Debitar comprador
      await tx.wallet.update({
        where: { userId: buyerId },
        data:  { aurBalance: { decrement: priceAur } },
      });

      // Creditar vendedor (menos taxa)
      await tx.wallet.update({
        where: { userId: order.sellerId },
        data:  { aurBalance: { increment: sellerGets } },
      });

      // Transferir colecionável
      await tx.userCollectible.delete({
        where: { userId_collectibleId: { userId: order.sellerId, collectibleId: order.collectibleId } },
      });

      await tx.userCollectible.create({
        data: {
          userId:         buyerId,
          collectibleId:  order.collectibleId,
          acquiredFromId: order.id,
          acquireMethod:  'market_purchase',
        },
      });

      // Fechar ordem
      await tx.marketOrder.update({
        where: { id: orderId },
        data:  { status: 'SOLD', buyerId, soldAt: new Date() },
      });

      // Transações financeiras
      const [buyerWallet, sellerWallet] = await Promise.all([
        tx.wallet.findUniqueOrThrow({ where: { userId: buyerId } }),
        tx.wallet.findUniqueOrThrow({ where: { userId: order.sellerId } }),
      ]);

      await tx.transaction.createMany({
        data: [
          {
            userId: buyerId, walletId: buyerWallet.id,
            type: 'COLLECTIBLE_PURCHASE', status: 'COMPLETED',
            amount: priceAur, currency: 'AUR',
            balanceBefore: balance.aurBalance, balanceAfter: balance.aurBalance - priceAur,
            description: `Compra: ${order.collectible.name}`, completedAt: new Date(),
          },
          {
            userId: order.sellerId, walletId: sellerWallet.id,
            type: 'COLLECTIBLE_SALE', status: 'COMPLETED',
            amount: sellerGets, currency: 'AUR',
            balanceBefore: balance.aurBalance, balanceAfter: 0, // seria o saldo do vendedor
            description: `Venda: ${order.collectible.name}`, completedAt: new Date(),
          },
        ],
      });
    });

    await Promise.all([
      this.audit.log({ userId: buyerId, action: 'MARKET_PURCHASED', entityId: orderId, metadata: { priceAur, collectibleId: order.collectibleId } }),
      this.audit.log({ userId: order.sellerId, action: 'MARKET_SOLD', entityId: orderId, metadata: { priceAur, sellerGets, fee: feeAmount } }),
    ]);

    this.emitter.emit('market.sold', { orderId, buyerId, sellerId: order.sellerId, priceAur });
    this.logger.log(`Mercado: ${order.collectible.name} vendido por ${priceAur} AUR`);

    return { success: true, collectible: order.collectible, priceAur, fee: feeAmount };
  }

  /** Cancelar listagem */
  async cancel(userId: string, orderId: string) {
    const order = await this.prisma.marketOrder.findUnique({ where: { id: orderId } });
    if (!order) throw new NotFoundException('Ordem não encontrada.');
    if (order.sellerId !== userId) throw new ForbiddenException('Não é sua ordem.');
    if (order.status !== 'OPEN') throw new BadRequestException('Ordem já encerrada.');

    await this.prisma.$transaction(async (tx) => {
      await tx.marketOrder.update({ where: { id: orderId }, data: { status: 'CANCELLED', cancelledAt: new Date() } });
      await tx.userCollectible.update({
        where: { userId_collectibleId: { userId, collectibleId: order.collectibleId } },
        data:  { isListed: false },
      });
    });

    return { success: true };
  }

  /** Listar ordens abertas com filtros */
  async getOrders(filters: { collectibleId?: string; rarity?: string; minPrice?: number; maxPrice?: number; page?: number; perPage?: number }) {
    const { collectibleId, rarity, minPrice, maxPrice, page = 1, perPage = 20 } = filters;

    return this.prisma.paginate(
      this.prisma.marketOrder,
      {
        where: {
          status: 'OPEN',
          expiresAt: { gte: new Date() },
          ...(collectibleId ? { collectibleId } : {}),
          ...(minPrice ? { priceAur: { gte: minPrice } } : {}),
          ...(maxPrice ? { priceAur: { lte: maxPrice } } : {}),
          ...(rarity ? { collectible: { rarity: rarity as any } } : {}),
        },
        include: {
          collectible: true,
          seller: { select: { username: true, avatarUrl: true } },
        },
        orderBy: { priceAur: 'asc' },
      },
      page,
      perPage,
    );
  }

  private async cancelExpired(orderId: string) {
    const order = await this.prisma.marketOrder.findUnique({ where: { id: orderId } });
    if (!order) return;
    await this.prisma.$transaction(async (tx) => {
      await tx.marketOrder.update({ where: { id: orderId }, data: { status: 'EXPIRED', cancelledAt: new Date() } });
      await tx.userCollectible.update({
        where: { userId_collectibleId: { userId: order.sellerId, collectibleId: order.collectibleId } },
        data:  { isListed: false },
      });
    });
  }
}
