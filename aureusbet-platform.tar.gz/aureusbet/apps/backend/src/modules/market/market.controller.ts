import { Controller, Get, Post, Delete, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { MarketService } from './market.service';
import { JwtAuthGuard }  from '../auth/guards/jwt-auth.guard';
import { CurrentUser }   from '../../common/decorators/current-user.decorator';

@ApiTags('Market')
@Controller('market')
export class MarketController {
  constructor(private readonly market: MarketService) {}

  @Get('orders')
  getOrders(
    @Query('collectibleId') collectibleId?: string,
    @Query('rarity')        rarity?: string,
    @Query('minPrice')      minPrice?: number,
    @Query('maxPrice')      maxPrice?: number,
    @Query('page')          page = 1,
    @Query('perPage')       perPage = 20,
  ) {
    return this.market.getOrders({ collectibleId, rarity, minPrice, maxPrice, page, perPage });
  }

  @Post('list')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  list(
    @CurrentUser('id') uid: string,
    @Body('collectibleId') collectibleId: string,
    @Body('priceAur')      priceAur: number,
    @Body('expiresInDays') expiresInDays?: number,
  ) {
    return this.market.list(uid, collectibleId, priceAur, expiresInDays);
  }

  @Post('buy/:orderId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  buy(@CurrentUser('id') uid: string, @Param('orderId') orderId: string) {
    return this.market.buy(uid, orderId);
  }

  @Delete('orders/:orderId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  cancel(@CurrentUser('id') uid: string, @Param('orderId') orderId: string) {
    return this.market.cancel(uid, orderId);
  }
}
