import { Module } from '@nestjs/common';
import { MarketController } from './market.controller';
import { MarketService }    from './market.service';
import { PaymentsModule }   from '../payments/payments.module';
import { AuditModule }      from '../audit/audit.module';

@Module({
  imports: [PaymentsModule, AuditModule],
  controllers: [MarketController],
  providers:   [MarketService],
  exports:     [MarketService],
})
export class MarketModule {}
