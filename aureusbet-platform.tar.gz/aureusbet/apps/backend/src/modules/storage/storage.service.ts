import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { randomBytes } from 'crypto';
import * as path from 'path';

const ALLOWED_MIME = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MAX_SIZE_MB  = 10;

@Injectable()
export class StorageService {
  private readonly logger = new Logger(StorageService.name);
  private readonly s3:        S3Client;
  private readonly publicUrl: string;
  private readonly kycBucket:     string;
  private readonly assetsBucket:  string;

  constructor(private readonly config: ConfigService) {
    this.s3 = new S3Client({
      endpoint:         this.config.get<string>('S3_ENDPOINT'),
      region:           this.config.get<string>('S3_REGION', 'us-east-1'),
      credentials: {
        accessKeyId:     this.config.get<string>('S3_ACCESS_KEY')!,
        secretAccessKey: this.config.get<string>('S3_SECRET_KEY')!,
      },
      forcePathStyle: true,
    });

    this.publicUrl    = this.config.get<string>('S3_PUBLIC_URL')!;
    this.kycBucket    = this.config.get<string>('S3_BUCKET_KYC')!;
    this.assetsBucket = this.config.get<string>('S3_BUCKET_ASSETS')!;
  }

  /** Upload de asset público (imagens de jogos, colecionáveis, etc.) */
  async uploadPublic(file: Express.Multer.File, prefix: string): Promise<string> {
    this.validateFile(file);

    const ext = path.extname(file.originalname).toLowerCase();
    const key = `${prefix}/${randomBytes(16).toString('hex')}${ext}`;

    await this.s3.send(new PutObjectCommand({
      Bucket:        this.assetsBucket,
      Key:           key,
      Body:          file.buffer,
      ContentType:   file.mimetype,
      CacheControl:  'public, max-age=31536000',
      ACL:           'public-read' as any,
    }));

    return `${this.publicUrl}/${key}`;
  }

  /** Upload privado para KYC (sem acesso público) */
  async uploadKyc(file: Express.Multer.File, userId: string, docType: string): Promise<{ key: string; bucket: string }> {
    this.validateFile(file, 20);

    const ext = path.extname(file.originalname).toLowerCase();
    const key = `kyc/${userId}/${docType}/${randomBytes(16).toString('hex')}${ext}`;

    await this.s3.send(new PutObjectCommand({
      Bucket:      this.kycBucket,
      Key:         key,
      Body:        file.buffer,
      ContentType: file.mimetype,
      // Sem ACL pública — apenas acesso via URL assinada
    }));

    return { key, bucket: this.kycBucket };
  }

  /** URL temporária para visualizar documento KYC */
  async getKycSignedUrl(key: string, expiresInSeconds = 300): Promise<string> {
    const command = new GetObjectCommand({ Bucket: this.kycBucket, Key: key });
    return getSignedUrl(this.s3, command, { expiresIn: expiresInSeconds });
  }

  /** Deletar objeto */
  async delete(bucket: string, key: string): Promise<void> {
    await this.s3.send(new DeleteObjectCommand({ Bucket: bucket, Key: key }));
  }

  private validateFile(file: Express.Multer.File, maxMb = MAX_SIZE_MB) {
    if (!ALLOWED_MIME.includes(file.mimetype)) {
      throw new Error(`Tipo de arquivo não permitido: ${file.mimetype}`);
    }
    if (file.size > maxMb * 1024 * 1024) {
      throw new Error(`Arquivo muito grande. Máximo: ${maxMb}MB`);
    }
  }
}
