import { Injectable } from '@nestjs/common';
import { PrismaService }  from '../../common/services/prisma.service';
import { AurTokenService } from './aur-token.service';

@Injectable()
export class BlockchainService {
  constructor(
    private readonly prisma:    PrismaService,
    private readonly aurToken:  AurTokenService,
  ) {}

  async getUserOnChainBalance(userId: string) {
    const wallet = await this.prisma.wallet.findUnique({ where: { userId } });
    if (!wallet?.polygonAddress) return { onChainBalance: null, address: null };

    const balance = await this.aurToken.getOnChainBalance(wallet.polygonAddress);
    return { onChainBalance: balance, address: wallet.polygonAddress };
  }
}
