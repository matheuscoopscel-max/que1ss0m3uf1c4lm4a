import { Module } from '@nestjs/common';
import { BlockchainController } from './blockchain.controller';
import { BlockchainService }    from './blockchain.service';
import { AurTokenService }      from './aur-token.service';
import { PaymentsModule }       from '../payments/payments.module';
import { AuditModule }          from '../audit/audit.module';

@Module({
  imports:     [PaymentsModule, AuditModule],
  controllers: [BlockchainController],
  providers:   [BlockchainService, AurTokenService],
  exports:     [BlockchainService, AurTokenService],
})
export class BlockchainModule {}
