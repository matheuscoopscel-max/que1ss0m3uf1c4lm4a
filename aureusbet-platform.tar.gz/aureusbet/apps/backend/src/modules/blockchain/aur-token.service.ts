import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ethers } from 'ethers';
import { PrismaService } from '../../common/services/prisma.service';
import { AuditService }  from '../audit/audit.service';
import { WalletService } from '../payments/wallet.service';
import { EventEmitter2 } from '@nestjs/event-emitter';

// ABI mínimo ERC-20 necessário
const ERC20_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function totalSupply() view returns (uint256)',
  'function balanceOf(address) view returns (uint256)',
  'function transfer(address to, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function transferFrom(address from, address to, uint256 amount) returns (bool)',
  'event Transfer(address indexed from, address indexed to, uint256 value)',
  'event Approval(address indexed owner, address indexed spender, uint256 value)',
];

@Injectable()
export class AurTokenService {
  private readonly logger    = new Logger(AurTokenService.name);
  private readonly provider: ethers.JsonRpcProvider;
  private readonly wallet:   ethers.Wallet;
  private readonly contract: ethers.Contract;
  private readonly tokenAddress:   string;
  private readonly platformAddress: string;

  constructor(
    private readonly config:   ConfigService,
    private readonly prisma:   PrismaService,
    private readonly audit:    AuditService,
    private readonly walletSvc: WalletService,
    private readonly emitter:  EventEmitter2,
  ) {
    const rpcUrl     = this.config.get<string>('POLYGON_RPC_URL')!;
    const privateKey = this.config.get<string>('PLATFORM_WALLET_PRIVATE_KEY')!;

    this.tokenAddress    = this.config.get<string>('AUR_TOKEN_ADDRESS')!;
    this.platformAddress = this.config.get<string>('PLATFORM_WALLET_ADDRESS')!;

    this.provider = new ethers.JsonRpcProvider(rpcUrl);
    this.wallet   = new ethers.Wallet(privateKey, this.provider);
    this.contract = new ethers.Contract(this.tokenAddress, ERC20_ABI, this.wallet);

    this.startEventListener();
  }

  /** Saldo de AUR on-chain de um endereço */
  async getOnChainBalance(address: string): Promise<string> {
    this.validateAddress(address);
    const balance  = await this.contract.balanceOf(address);
    const decimals = await this.contract.decimals();
    return ethers.formatUnits(balance, decimals);
  }

  /** Transferir AUR da plataforma para carteira do usuário (saque) */
  async withdrawToWallet(userId: string, toAddress: string, aurAmount: number): Promise<string> {
    this.validateAddress(toAddress);
    if (aurAmount <= 0) throw new BadRequestException('Valor inválido.');

    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (user.kycStatus !== 'APPROVED') throw new BadRequestException('KYC obrigatório para saque blockchain.');

    const balance   = await this.walletSvc.getBalance(userId);
    if (balance.aurBalance < aurAmount) throw new BadRequestException('Saldo interno insuficiente.');

    // Verificar saldo on-chain da plataforma
    const platformBalance = await this.getOnChainBalance(this.platformAddress);
    if (parseFloat(platformBalance) < aurAmount) {
      throw new BadRequestException('Liquidez insuficiente. Tente mais tarde.');
    }

    const decimals  = await this.contract.decimals();
    const amount    = ethers.parseUnits(aurAmount.toString(), decimals);

    // Estimar gas
    const gasPrice  = await this.provider.getFeeData();
    const gasLimit  = await this.contract.transfer.estimateGas(toAddress, amount);

    // Executar transferência on-chain
    const tx = await this.contract.transfer(toAddress, amount, {
      gasLimit: gasLimit * 120n / 100n, // +20% buffer
      maxFeePerGas:         gasPrice.maxFeePerGas,
      maxPriorityFeePerGas: gasPrice.maxPriorityFeePerGas,
    });

    this.logger.log(`AUR withdrawal tx: ${tx.hash} (${aurAmount} AUR → ${toAddress})`);

    // Aguardar confirmação (1 bloco)
    const receipt = await tx.wait(1);
    if (!receipt || receipt.status !== 1) throw new BadRequestException('Transação falhou on-chain.');

    // Debitar saldo interno
    await this.walletSvc.debitBalance(userId, aurAmount, 'AUR');

    // Registrar no banco
    await this.prisma.transaction.create({
      data: {
        userId,
        walletId:      (await this.prisma.wallet.findUniqueOrThrow({ where: { userId } })).id,
        type:          'WITHDRAWAL',
        status:        'COMPLETED',
        method:        'CRYPTO_AUR',
        amount:        aurAmount,
        currency:      'AUR',
        balanceBefore: balance.aurBalance,
        balanceAfter:  balance.aurBalance - aurAmount,
        txHash:        tx.hash,
        polygonBlock:  receipt.blockNumber,
        description:   `Saque ${aurAmount} AUR → ${toAddress}`,
        completedAt:   new Date(),
      },
    });

    await this.audit.log({
      userId,
      action:   'WITHDRAWAL',
      metadata: { method: 'polygon', amount: aurAmount, toAddress, txHash: tx.hash },
    });

    return tx.hash;
  }

  /** Vincular endereço Polygon ao perfil */
  async linkWalletAddress(userId: string, address: string, signature: string) {
    this.validateAddress(address);

    // Verificar que o usuário possui a chave privada do endereço
    const message  = `AureusBet - Vincular carteira: ${address} - ${userId}`;
    const recovered = ethers.verifyMessage(message, signature);

    if (recovered.toLowerCase() !== address.toLowerCase()) {
      throw new BadRequestException('Assinatura inválida. Você não é o dono desta carteira.');
    }

    // Verificar que endereço não está em uso por outro usuário
    const existing = await this.prisma.wallet.findFirst({
      where: { polygonAddress: address.toLowerCase(), userId: { not: userId } },
    });
    if (existing) throw new BadRequestException('Este endereço já está vinculado a outra conta.');

    await this.prisma.wallet.update({
      where: { userId },
      data:  { polygonAddress: address.toLowerCase() },
    });

    return { address, linked: true };
  }

  /** Monitorar depósitos on-chain */
  async checkOnChainDeposit(txHash: string, userId: string) {
    const receipt = await this.provider.getTransactionReceipt(txHash);
    if (!receipt) throw new BadRequestException('Transação não encontrada.');
    if (receipt.status !== 1) throw new BadRequestException('Transação falhou.');

    const iface  = new ethers.Interface(ERC20_ABI);
    const transfers: any[] = [];

    for (const log of receipt.logs) {
      try {
        const parsed = iface.parseLog({ topics: log.topics as string[], data: log.data });
        if (parsed?.name === 'Transfer') {
          const decimals = await this.contract.decimals();
          transfers.push({
            from:   parsed.args[0],
            to:     parsed.args[1],
            amount: ethers.formatUnits(parsed.args[2], decimals),
          });
        }
      } catch { /* skip non-AUR logs */ }
    }

    const wallet   = await this.prisma.wallet.findUniqueOrThrow({ where: { userId } });
    const deposit  = transfers.find(
      t => t.to.toLowerCase() === this.platformAddress.toLowerCase()
    );

    if (!deposit) throw new BadRequestException('Nenhum depósito AUR encontrado nesta tx.');

    // Verificar se já processado
    const alreadyProcessed = await this.prisma.transaction.findFirst({ where: { txHash } });
    if (alreadyProcessed) throw new BadRequestException('Transação já processada.');

    const amount = parseFloat(deposit.amount);

    // Creditar saldo interno
    await this.walletSvc.creditBalance(userId, amount, 'AUR', 'DEPOSIT');

    await this.prisma.transaction.create({
      data: {
        userId,
        walletId:      wallet.id,
        type:          'DEPOSIT',
        status:        'COMPLETED',
        method:        'CRYPTO_AUR',
        amount,
        currency:      'AUR',
        balanceBefore: Number(wallet.aurBalance),
        balanceAfter:  Number(wallet.aurBalance) + amount,
        txHash,
        polygonBlock:  receipt.blockNumber,
        description:   `Depósito ${amount} AUR via Polygon`,
        completedAt:   new Date(),
      },
    });

    return { txHash, amount, credited: true };
  }

  /** Informações do token */
  async getTokenInfo() {
    const [name, symbol, decimals, totalSupply] = await Promise.all([
      this.contract.name(),
      this.contract.symbol(),
      this.contract.decimals(),
      this.contract.totalSupply(),
    ]);
    return {
      address: this.tokenAddress,
      name,
      symbol,
      decimals: Number(decimals),
      totalSupply: ethers.formatUnits(totalSupply, decimals),
      network: 'Polygon',
      chainId: this.config.get<number>('POLYGON_CHAIN_ID', 137),
    };
  }

  // ── PRIVADOS ──────────────────────────────────────────────────

  private validateAddress(address: string) {
    if (!ethers.isAddress(address)) {
      throw new BadRequestException('Endereço Polygon inválido.');
    }
  }

  private startEventListener() {
    this.contract.on('Transfer', async (from, to, amount, event) => {
      // Monitorar depósitos para a plataforma
      if (to.toLowerCase() === this.platformAddress.toLowerCase()) {
        const decimals = await this.contract.decimals();
        const aurAmount = parseFloat(ethers.formatUnits(amount, decimals));
        this.logger.log(`Recebido ${aurAmount} AUR de ${from}`);
        this.emitter.emit('blockchain.transfer.received', {
          from, to, amount: aurAmount, txHash: event.log.transactionHash,
        });
      }
    });
    this.logger.log('Ouvindo eventos AUR Token na Polygon');
  }
}
