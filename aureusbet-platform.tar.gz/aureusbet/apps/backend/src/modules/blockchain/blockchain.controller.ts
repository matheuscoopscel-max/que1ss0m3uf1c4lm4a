import { Controller, Get, Post, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { BlockchainService } from './blockchain.service';
import { AurTokenService }   from './aur-token.service';
import { JwtAuthGuard }      from '../auth/guards/jwt-auth.guard';
import { CurrentUser }       from '../../common/decorators/current-user.decorator';

@ApiTags('Blockchain')
@Controller('blockchain')
export class BlockchainController {
  constructor(
    private readonly blockchain: BlockchainService,
    private readonly aurToken:   AurTokenService,
  ) {}

  @Get('token-info')
  getTokenInfo() { return this.aurToken.getTokenInfo(); }

  @Get('on-chain-balance')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  getOnChainBalance(@CurrentUser('id') uid: string) {
    return this.blockchain.getUserOnChainBalance(uid);
  }

  @Post('link-wallet')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 3, ttl: 60000 } })
  linkWallet(
    @CurrentUser('id') uid: string,
    @Body('address') address: string,
    @Body('signature') signature: string,
  ) {
    return this.aurToken.linkWalletAddress(uid, address, signature);
  }

  @Post('withdraw-onchain')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 3, ttl: 300000 } })
  withdrawOnChain(
    @CurrentUser('id') uid: string,
    @Body('toAddress') toAddress: string,
    @Body('amount') amount: number,
  ) {
    return this.aurToken.withdrawToWallet(uid, toAddress, amount);
  }

  @Post('verify-deposit')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  verifyDeposit(@CurrentUser('id') uid: string, @Body('txHash') txHash: string) {
    return this.aurToken.checkOnChainDeposit(txHash, uid);
  }
}
