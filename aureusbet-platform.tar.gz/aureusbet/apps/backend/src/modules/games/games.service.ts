import { Injectable, NotFoundException, OnModuleInit, Logger } from '@nestjs/common';
import { PrismaService } from '../../common/services/prisma.service';
import { CrashService }  from './crash/crash.service';
import { createHash }    from 'crypto';

@Injectable()
export class GamesService implements OnModuleInit {
  private readonly logger = new Logger(GamesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly crash:  CrashService,
  ) {}

  async onModuleInit() {
    await this.seedGamesIfEmpty();
    await this.crash.initialize();
  }

  async listActive() {
    return this.prisma.game.findMany({
      where:   { status: 'ACTIVE' },
      orderBy: [{ isFeatured: 'desc' }, { sortOrder: 'asc' }],
    });
  }

  async findBySlug(slug: string) {
    const game = await this.prisma.game.findUnique({ where: { slug } });
    if (!game) throw new NotFoundException('Jogo não encontrado.');
    return game;
  }

  async getHistory(slug: string, page = 1) {
    const game = await this.prisma.game.findUnique({ where: { slug } });
    if (!game) throw new NotFoundException();

    return this.prisma.paginate(
      this.prisma.gameRound,
      {
        where:   { gameId: game.id, status: 'COMPLETED' },
        orderBy: { createdAt: 'desc' },
      },
      page, 20,
    );
  }

  async verifyRound(roundId: string) {
    const round = await this.prisma.gameRound.findUnique({
      where: { id: roundId },
      select: { serverSeed: true, serverSeedHash: true, serverSeedRevealed: true, clientSeed: true, nonce: true, result: true },
    });
    if (!round) throw new NotFoundException('Round não encontrado.');

    const computedHash = createHash('sha256').update(round.serverSeedRevealed ?? round.serverSeed).digest('hex');
    const isValid = computedHash === round.serverSeedHash;

    return { ...round, serverSeed: undefined, isValid, computedHash };
  }

  async getUserBets(userId: string, page = 1, gameSlug?: string) {
    const game = gameSlug ? await this.prisma.game.findUnique({ where: { slug: gameSlug } }) : null;

    return this.prisma.paginate(
      this.prisma.bet,
      {
        where: { userId, ...(game ? { gameId: game.id } : {}) },
        include: { game: { select: { name: true, slug: true } } },
        orderBy: { createdAt: 'desc' },
      },
      page, 20,
    );
  }

  private async seedGamesIfEmpty() {
    const count = await this.prisma.game.count();
    if (count > 0) return;

    const games = [
      { type: 'CRASH',    name: 'Crash',    slug: 'crash',    sortOrder: 1, isFeatured: true },
      { type: 'ROULETTE', name: 'Roleta',   slug: 'roulette', sortOrder: 2 },
      { type: 'BLACKJACK', name: 'Blackjack', slug: 'blackjack', sortOrder: 3 },
      { type: 'SLOTS',    name: 'Slots',    slug: 'slots',    sortOrder: 4 },
      { type: 'DICE',     name: 'Dado',     slug: 'dice',     sortOrder: 5 },
      { type: 'MINES',    name: 'Minas',    slug: 'mines',    sortOrder: 6 },
      { type: 'TOWER',    name: 'Torre',    slug: 'tower',    sortOrder: 7 },
      { type: 'COINFLIP', name: 'CoinFlip', slug: 'coinflip', sortOrder: 8 },
    ];

    for (const g of games) {
      await this.prisma.game.upsert({
        where:  { type: g.type as any },
        create: g as any,
        update: {},
      });
    }
    this.logger.log('Jogos inicializados no banco');
  }
}
