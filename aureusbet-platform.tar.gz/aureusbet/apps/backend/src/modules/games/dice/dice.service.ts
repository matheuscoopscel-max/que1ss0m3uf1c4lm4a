import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../../common/services/prisma.service';
import { WalletService } from '../../payments/wallet.service';
import { RngService }    from '../rng.service';

@Injectable()
export class DiceService {
  constructor(
    private readonly prisma:  PrismaService,
    private readonly wallet:  WalletService,
    private readonly rng:     RngService,
  ) {}

  async roll(userId: string, amount: number, target: number, isOver: boolean, clientSeed: string, ip?: string) {
    if (target < 2 || target > 98) throw new BadRequestException('Target deve ser entre 2 e 98.');
    if (amount <= 0) throw new BadRequestException('Aposta inválida.');

    const game = await this.prisma.game.findUnique({ where: { type: 'DICE' } });
    if (!game) throw new BadRequestException('Jogo indisponível.');

    const serverSeed = this.rng.generateServerSeed();
    const nonce = Math.floor(Math.random() * 1000000);
    const roll  = this.rng.calculateDiceRoll(serverSeed, clientSeed, nonce);

    const houseEdge = Number(game.houseEdge);
    const winChance = isOver ? (100 - target - houseEdge * 100) / 100 : (target - 1 - houseEdge * 100) / 100;
    const payout    = winChance > 0 ? (1 / winChance) * amount * (1 - houseEdge) : 0;
    const won       = isOver ? roll > target : roll < target;

    await this.wallet.debitBalance(userId, amount, 'AUR');
    if (won) await this.wallet.creditBalance(userId, payout, 'AUR', 'WIN');

    const wallet = await this.prisma.wallet.findUniqueOrThrow({ where: { userId } });
    await this.prisma.bet.create({
      data: {
        userId, gameId: game.id, amount, currency: 'AUR',
        multiplier: won ? payout / amount : 0,
        payout: won ? payout : 0, profit: won ? payout - amount : -amount,
        status: won ? 'WON' : 'LOST',
        data: { target, isOver, clientSeed },
        result: { roll, won },
        serverSeed, clientSeed, nonce, isProvablyFair: true,
        ipAddress: ip, resolvedAt: new Date(),
      },
    });

    return { roll, target, isOver, won, payout: won ? payout : 0, serverSeedHash: this.rng.hashServerSeed(serverSeed) };
  }
}
