import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createHmac, createHash, randomBytes } from 'crypto';

/**
 * RNG Service — Provably Fair
 * Todos os resultados derivam de: HMAC-SHA256(serverSeed, clientSeed:nonce)
 * O serverSeed é hashed e publicado ANTES do jogo.
 * Após o jogo, o seed original é revelado para verificação independente.
 */
@Injectable()
export class RngService {
  private readonly masterSeed: string;

  constructor(private readonly config: ConfigService) {
    this.masterSeed = this.config.get<string>('RNG_SEED_SECRET')!;
  }

  /** Gera um novo serverSeed aleatório */
  generateServerSeed(): string {
    return randomBytes(32).toString('hex');
  }

  /** Hash público do serverSeed (revelado antes do round) */
  hashServerSeed(serverSeed: string): string {
    return createHash('sha256').update(serverSeed).digest('hex');
  }

  /**
   * Deriva bytes aleatórios provably fair
   * @param serverSeed seed do servidor (confidencial)
   * @param clientSeed seed do cliente (público)
   * @param nonce contador incremental
   * @param count quantidade de floats [0,1) a gerar
   */
  generateFloats(serverSeed: string, clientSeed: string, nonce: number, count = 1): number[] {
    const results: number[] = [];
    let cursor = 0;

    while (results.length < count) {
      const hmac = createHmac('sha256', serverSeed)
        .update(`${clientSeed}:${nonce}:${cursor}`)
        .digest('hex');

      for (let i = 0; i < Math.floor(hmac.length / 8) && results.length < count; i++) {
        const hex   = hmac.slice(i * 8, (i + 1) * 8);
        const value = parseInt(hex, 16);
        const float = value / 0xffffffff;
        results.push(float);
        cursor++;
      }
    }

    return results;
  }

  /** Gera resultado para Crash */
  calculateCrashPoint(serverSeed: string, clientSeed: string, nonce: number): number {
    const [float] = this.generateFloats(serverSeed, clientSeed, nonce);
    const houseEdge = 0.01; // 1%

    if (float < houseEdge) return 1.00; // House wins

    const crashPoint = (1 / (1 - float)) * (1 - houseEdge);
    return Math.max(1.00, Math.floor(crashPoint * 100) / 100);
  }

  /** Gera resultado para Roulette (0-36) */
  calculateRouletteNumber(serverSeed: string, clientSeed: string, nonce: number): number {
    const [float] = this.generateFloats(serverSeed, clientSeed, nonce);
    return Math.floor(float * 37); // 0-36
  }

  /** Gera deck embaralhado para Blackjack */
  generateShuffledDeck(serverSeed: string, clientSeed: string, nonce: number): number[] {
    const deck = Array.from({ length: 52 }, (_, i) => i);
    const floats = this.generateFloats(serverSeed, clientSeed, nonce, 52);

    // Fisher-Yates com floats determinísticos
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(floats[i] * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
  }

  /** Gera resultado de Dice (0-9999 / 100 para 2 casas decimais de 0.00-99.99) */
  calculateDiceRoll(serverSeed: string, clientSeed: string, nonce: number): number {
    const [float] = this.generateFloats(serverSeed, clientSeed, nonce);
    return Math.floor(float * 10000) / 100; // 0.00 - 99.99
  }

  /** Gera grid de minas (posições das bombas) */
  calculateMinesGrid(serverSeed: string, clientSeed: string, nonce: number, mineCount: number): number[] {
    const positions = Array.from({ length: 25 }, (_, i) => i);
    const floats    = this.generateFloats(serverSeed, clientSeed, nonce, 25);
    const shuffled  = positions
      .map((v, i) => ({ v, f: floats[i] }))
      .sort((a, b) => a.f - b.f)
      .map(x => x.v);
    return shuffled.slice(0, mineCount);
  }

  /** Verifica um resultado (para auditing) */
  verifyResult(serverSeed: string, clientSeed: string, nonce: number, expected: number): boolean {
    const results = this.generateFloats(serverSeed, clientSeed, nonce);
    const [float] = results;
    const derived = (1 / (1 - float)) * 0.99;
    return Math.abs(derived - expected) < 0.01;
  }
}
