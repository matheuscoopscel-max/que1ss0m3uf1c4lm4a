import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../../common/services/prisma.service';
import { WalletService } from '../../payments/wallet.service';
import { RngService }    from '../rng.service';
import { AuditService }  from '../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { randomBytes }   from 'crypto';

const ROULETTE_PAYOUTS: Record<string, number> = {
  straight: 35, split: 17, street: 11, corner: 8, line: 5,
  column: 2, dozen: 2, red: 1, black: 1, odd: 1, even: 1,
  low: 1, high: 1, zero: 35,
};

const RED_NUMBERS  = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
const BLACK_NUMBERS = [2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35];

@Injectable()
export class RouletteService {
  constructor(
    private readonly prisma:  PrismaService,
    private readonly wallet:  WalletService,
    private readonly rng:     RngService,
    private readonly audit:   AuditService,
    private readonly emitter: EventEmitter2,
  ) {}

  async spin(userId: string, bets: { type: string; numbers?: number[]; amount: number }[], ip?: string) {
    if (!bets.length) throw new BadRequestException('Nenhuma aposta informada.');
    const totalBet = bets.reduce((s, b) => s + b.amount, 0);
    if (totalBet <= 0) throw new BadRequestException('Valor de aposta inválido.');

    const game = await this.prisma.game.findUnique({ where: { type: 'ROULETTE' } });
    if (!game) throw new BadRequestException('Jogo indisponível.');

    const serverSeed   = this.rng.generateServerSeed();
    const serverSeedHash = this.rng.hashServerSeed(serverSeed);
    const clientSeed   = `roulette_${userId}_${Date.now()}`;
    const nonce        = Math.floor(Math.random() * 1000000);
    const result       = this.rng.calculateRouletteNumber(serverSeed, clientSeed, nonce);

    // Debitar total apostado
    await this.wallet.debitBalance(userId, totalBet, 'AUR');

    let totalPayout = 0;
    const betResults: any[] = [];

    for (const bet of bets) {
      const payout = this.calculatePayout(result, bet.type, bet.numbers ?? [], bet.amount);
      totalPayout += payout;
      betResults.push({ ...bet, result, payout, won: payout > 0 });
    }

    // Creditar ganhos
    if (totalPayout > 0) {
      await this.wallet.creditBalance(userId, totalPayout, 'AUR', 'WIN');
    }

    // Registrar no banco
    const wallet = await this.prisma.wallet.findUniqueOrThrow({ where: { userId } });
    const round  = await this.prisma.gameRound.create({
      data: {
        gameId: game.id, status: 'COMPLETED', serverSeed, serverSeedHash,
        clientSeed, nonce, result: { number: result }, startedAt: new Date(), endedAt: new Date(),
      },
    });

    await this.prisma.bet.create({
      data: {
        userId, gameId: game.id, roundId: round.id,
        amount: totalBet, currency: 'AUR',
        multiplier: totalPayout / totalBet,
        payout: totalPayout, profit: totalPayout - totalBet,
        status: totalPayout >= totalBet ? 'WON' : 'LOST',
        data: { bets }, result: { number: result, betResults },
        clientSeed, nonce, isProvablyFair: true, ipAddress: ip, resolvedAt: new Date(),
      },
    });

    return { result, betResults, totalBet, totalPayout, profit: totalPayout - totalBet, serverSeedHash };
  }

  private calculatePayout(result: number, type: string, numbers: number[], amount: number): number {
    const mult = ROULETTE_PAYOUTS[type];
    if (mult === undefined) return 0;

    let won = false;
    switch (type) {
      case 'straight': won = numbers.includes(result); break;
      case 'zero':     won = result === 0; break;
      case 'red':      won = RED_NUMBERS.includes(result); break;
      case 'black':    won = BLACK_NUMBERS.includes(result); break;
      case 'odd':      won = result !== 0 && result % 2 !== 0; break;
      case 'even':     won = result !== 0 && result % 2 === 0; break;
      case 'low':      won = result >= 1 && result <= 18; break;
      case 'high':     won = result >= 19 && result <= 36; break;
      case 'dozen':    won = numbers.length > 0 && Math.ceil(result / 12) === numbers[0]; break;
      case 'column':   won = numbers.length > 0 && result % 3 === numbers[0] % 3; break;
      default:         won = numbers.includes(result);
    }
    return won ? amount * (mult + 1) : 0;
  }
}
