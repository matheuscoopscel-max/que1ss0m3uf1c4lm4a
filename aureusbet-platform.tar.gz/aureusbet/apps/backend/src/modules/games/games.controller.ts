import { Controller, Get, Post, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { GamesService }    from './games.service';
import { CrashService }    from './crash/crash.service';
import { JwtAuthGuard }    from '../auth/guards/jwt-auth.guard';
import { CurrentUser }     from '../../common/decorators/current-user.decorator';
import { GetIpAddress }    from '../../common/decorators/get-ip.decorator';

@ApiTags('Games')
@Controller('games')
export class GamesController {
  constructor(
    private readonly games: GamesService,
    private readonly crash: CrashService,
  ) {}

  @Get()
  listGames() { return this.games.listActive(); }

  @Get(':slug')
  getGame(@Param('slug') slug: string) { return this.games.findBySlug(slug); }

  @Get(':slug/history')
  getHistory(@Param('slug') slug: string, @Query('page') p = 1) {
    return this.games.getHistory(slug, p);
  }

  // ── CRASH ─────────────────────────────────────────────────────
  @Get('crash/state')
  getCrashState() { return this.crash.getState(); }

  @Post('crash/bet')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 5, ttl: 10000 } })
  placeCrashBet(
    @CurrentUser('id') uid: string,
    @Body('amount') amount: number,
    @Body('autoCashout') autoCashout?: number,
    @GetIpAddress() ip?: string,
  ) {
    return this.crash.placeBet(uid, amount, autoCashout, ip);
  }

  @Post('crash/cashout')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  cashout(@CurrentUser('id') uid: string) {
    return this.crash.cashout(uid);
  }

  // ── Verificação provably fair ─────────────────────────────────
  @Get('verify/:roundId')
  verifyRound(@Param('roundId') roundId: string) {
    return this.games.verifyRound(roundId);
  }

  @Get('my-bets')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  getMyBets(
    @CurrentUser('id') uid: string,
    @Query('page') p = 1,
    @Query('gameSlug') slug?: string,
  ) {
    return this.games.getUserBets(uid, p, slug);
  }
}
