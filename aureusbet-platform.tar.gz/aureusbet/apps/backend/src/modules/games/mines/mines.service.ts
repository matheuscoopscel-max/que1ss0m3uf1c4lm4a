import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRedis } from '@nestjs-modules/ioredis';
import Redis from 'ioredis';
import { PrismaService } from '../../../common/services/prisma.service';
import { WalletService } from '../../payments/wallet.service';
import { RngService }    from '../rng.service';
import { randomBytes }   from 'crypto';

interface MinesSession {
  userId: string; gameId: string; betId: string;
  amount: number; mineCount: number; mines: number[];
  revealed: number[]; serverSeed: string; clientSeed: string; nonce: number;
  cashoutAt?: number;
}

const SESSION_TTL = 3600; // 1 hora

@Injectable()
export class MinesService {
  constructor(
    private readonly prisma:  PrismaService,
    private readonly wallet:  WalletService,
    private readonly rng:     RngService,
    @InjectRedis() private readonly redis: Redis,
  ) {}

  async startGame(userId: string, amount: number, mineCount: number, clientSeed: string, ip?: string) {
    if (mineCount < 1 || mineCount > 24) throw new BadRequestException('Entre 1 e 24 minas.');
    if (amount <= 0) throw new BadRequestException('Aposta inválida.');

    const game = await this.prisma.game.findUnique({ where: { type: 'MINES' } });
    if (!game) throw new BadRequestException('Jogo indisponível.');

    await this.wallet.debitBalance(userId, amount, 'AUR');

    const serverSeed = this.rng.generateServerSeed();
    const nonce      = Math.floor(Math.random() * 1000000);
    const mines      = this.rng.calculateMinesGrid(serverSeed, clientSeed, nonce, mineCount);

    const bet = await this.prisma.bet.create({
      data: {
        userId, gameId: game.id, amount, currency: 'AUR',
        status: 'PLACED', data: { mineCount, clientSeed },
        serverSeed, clientSeed, nonce, isProvablyFair: true, ipAddress: ip,
      },
    });

    const session: MinesSession = {
      userId, gameId: game.id, betId: bet.id,
      amount, mineCount, mines, revealed: [],
      serverSeed, clientSeed, nonce,
    };

    await this.redis.setex(`mines:${userId}`, SESSION_TTL, JSON.stringify(session));

    return {
      betId:           bet.id,
      serverSeedHash:  this.rng.hashServerSeed(serverSeed),
      mineCount,
      totalCells:      25,
      revealedCells:   [],
    };
  }

  async revealCell(userId: string, cell: number) {
    if (cell < 0 || cell > 24) throw new BadRequestException('Célula inválida.');

    const raw = await this.redis.get(`mines:${userId}`);
    if (!raw) throw new BadRequestException('Nenhuma sessão ativa. Inicie uma nova partida.');

    const session: MinesSession = JSON.parse(raw);
    if (session.revealed.includes(cell)) throw new BadRequestException('Célula já revelada.');

    const isMine = session.mines.includes(cell);
    session.revealed.push(cell);

    if (isMine) {
      // Game over
      await this.redis.del(`mines:${userId}`);
      await this.prisma.bet.update({
        where: { id: session.betId },
        data: {
          status: 'LOST', payout: 0, profit: -session.amount,
          result: { mines: session.mines, revealed: session.revealed, hitMine: cell },
          resolvedAt: new Date(),
        },
      });
      return { cell, isMine: true, mines: session.mines, lost: true, payout: 0 };
    }

    // Calcular multiplicador atual
    const safeRevealed = session.revealed.length;
    const safeCells    = 25 - session.mineCount;
    const multiplier   = this.calculateMultiplier(safeRevealed, session.mineCount);
    const currentPayout = session.amount * multiplier;

    await this.redis.setex(`mines:${userId}`, SESSION_TTL, JSON.stringify(session));

    return {
      cell,
      isMine:         false,
      revealed:       session.revealed,
      currentPayout,
      currentMultiplier: multiplier,
      canCashout:     true,
    };
  }

  async cashout(userId: string) {
    const raw = await this.redis.get(`mines:${userId}`);
    if (!raw) throw new BadRequestException('Nenhuma sessão ativa.');

    const session: MinesSession = JSON.parse(raw);
    if (!session.revealed.length) throw new BadRequestException('Revele pelo menos uma célula antes de sacar.');

    const multiplier = this.calculateMultiplier(session.revealed.length, session.mineCount);
    const payout     = session.amount * multiplier;

    await this.redis.del(`mines:${userId}`);
    await this.wallet.creditBalance(userId, payout, 'AUR', 'WIN');

    await this.prisma.bet.update({
      where: { id: session.betId },
      data: {
        status: 'WON', multiplier, payout, profit: payout - session.amount,
        result: { mines: session.mines, revealed: session.revealed, cashedOut: true },
        resolvedAt: new Date(),
      },
    });

    return { payout, multiplier, revealed: session.revealed, mines: session.mines };
  }

  private calculateMultiplier(revealed: number, mineCount: number): number {
    // Fórmula: produto de (25-mineCount-i)/(25-i) para i de 0 a revealed-1
    let mult = 1;
    for (let i = 0; i < revealed; i++) {
      mult *= (25 - mineCount - i) / (25 - i);
    }
    return Math.max(1, 1 / mult * (1 - 0.01)); // 1% house edge
  }
}
