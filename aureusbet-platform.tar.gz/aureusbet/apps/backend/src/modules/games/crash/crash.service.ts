import { Injectable, Logger, BadRequestException, ForbiddenException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import { InjectRedis } from '@nestjs-modules/ioredis';
import Redis from 'ioredis';
import { Decimal } from '@prisma/client/runtime/library';

import { PrismaService }  from '../../../common/services/prisma.service';
import { WalletService }  from '../../payments/wallet.service';
import { RngService }     from '../rng.service';
import { AuditService }   from '../../audit/audit.service';
import { GameGateway }    from '../../websocket/game.gateway';

enum CrashState { WAITING = 'WAITING', RUNNING = 'RUNNING', CRASHED = 'CRASHED' }

interface CrashPlayer {
  userId:       string;
  username:     string;
  betId:        string;
  amount:       number;
  cashedOutAt?: number;
  payout?:      number;
  autoCashout?: number;
}

interface CrashRound {
  id:         string;
  state:      CrashState;
  multiplier: number;
  crashPoint: number;
  serverSeedHash: string;
  clientSeed: string;
  nonce:      number;
  players:    Map<string, CrashPlayer>;
  startTime?: number;
  history:    number[];
}

const TICK_MS    = 100;
const WAITING_MS = 8000;

@Injectable()
export class CrashService {
  private readonly logger = new Logger(CrashService.name);
  private currentRound: CrashRound | null = null;
  private tickInterval: ReturnType<typeof setInterval> | null = null;
  private waitTimeout: ReturnType<typeof setTimeout> | null  = null;
  private gameId: string | null = null;

  constructor(
    private readonly prisma:   PrismaService,
    private readonly wallet:   WalletService,
    private readonly rng:      RngService,
    private readonly audit:    AuditService,
    private readonly emitter:  EventEmitter2,
    private readonly config:   ConfigService,
    private readonly gateway:  GameGateway,
    @InjectRedis() private readonly redis: Redis,
  ) {}

  /** Inicializar game (chamado no onModuleInit do GamesService) */
  async initialize() {
    const game = await this.prisma.game.findUnique({ where: { type: 'CRASH' } });
    if (!game || game.status !== 'ACTIVE') return;
    this.gameId = game.id;
    this.logger.log('Crash game inicializado');
    this.scheduleNextRound();
  }

  // ── FASE DE ESPERA ────────────────────────────────────────────
  private scheduleNextRound() {
    this.logger.log(`Próximo round em ${WAITING_MS}ms`);
    this.waitTimeout = setTimeout(() => this.startRound(), WAITING_MS);

    this.gateway.broadcastCrash('waiting', {
      waitMs: WAITING_MS,
      history: this.currentRound?.history?.slice(-20) ?? [],
    });
  }

  // ── INICIAR ROUND ─────────────────────────────────────────────
  private async startRound() {
    const serverSeed     = this.rng.generateServerSeed();
    const serverSeedHash = this.rng.hashServerSeed(serverSeed);
    const clientSeed     = `crash_${Date.now()}`;
    const nonce          = await this.incrementNonce();
    const crashPoint     = this.rng.calculateCrashPoint(serverSeed, clientSeed, nonce);

    const dbRound = await this.prisma.gameRound.create({
      data: {
        gameId: this.gameId!,
        status: 'RUNNING',
        serverSeed,
        serverSeedHash,
        clientSeed,
        nonce,
        crashPoint,
        startedAt: new Date(),
      },
    });

    this.currentRound = {
      id:             dbRound.id,
      state:          CrashState.RUNNING,
      multiplier:     1.00,
      crashPoint,
      serverSeedHash,
      clientSeed,
      nonce,
      players:        new Map(),
      startTime:      Date.now(),
      history:        this.currentRound?.history ?? [],
    };

    this.gateway.broadcastCrash('started', { roundId: dbRound.id, serverSeedHash });
    this.logger.log(`Round ${dbRound.id} iniciado. Crash em ${crashPoint}x`);

    this.tickInterval = setInterval(() => this.tick(), TICK_MS);
  }

  // ── TICK ──────────────────────────────────────────────────────
  private async tick() {
    if (!this.currentRound || this.currentRound.state !== CrashState.RUNNING) return;

    const elapsed    = (Date.now() - this.currentRound.startTime!) / 1000;
    const multiplier = Math.pow(Math.E, elapsed * 0.08); // Curva exponencial
    this.currentRound.multiplier = Math.round(multiplier * 100) / 100;

    // Auto-cashout de jogadores
    for (const [uid, player] of this.currentRound.players) {
      if (!player.cashedOutAt && player.autoCashout && this.currentRound.multiplier >= player.autoCashout) {
        await this.cashout(uid, this.currentRound.multiplier).catch(() => {});
      }
    }

    this.gateway.broadcastCrash('tick', { multiplier: this.currentRound.multiplier });

    if (this.currentRound.multiplier >= this.currentRound.crashPoint) {
      await this.crash();
    }
  }

  // ── CRASH ─────────────────────────────────────────────────────
  private async crash() {
    if (!this.currentRound) return;
    clearInterval(this.tickInterval!);
    this.currentRound.state = CrashState.CRASHED;

    const round = this.currentRound;
    this.logger.log(`Round ${round.id} crashou em ${round.crashPoint}x`);

    // Marcar bets não sacadas como perdidas
    const lostPlayers = [...round.players.values()].filter(p => !p.cashedOutAt);
    await Promise.all(
      lostPlayers.map(p => this.resolveLostBet(p.betId, p.userId, p.amount, round.crashPoint))
    );

    // Atualizar round no banco
    await this.prisma.gameRound.update({
      where: { id: round.id },
      data: {
        status: 'COMPLETED',
        serverSeedRevealed: await this.prisma.gameRound.findUnique({ where: { id: round.id } }).then(r => r?.serverSeed),
        endedAt: new Date(),
        result: { crashPoint: round.crashPoint, players: [...round.players.values()] },
      },
    });

    round.history.push(round.crashPoint);

    this.gateway.broadcastCrash('crashed', {
      crashPoint:         round.crashPoint,
      serverSeedRevealed: round.id, // simplificado; usar seed real após consulta
    });

    setTimeout(() => this.scheduleNextRound(), 3000);
  }

  // ── APOSTAR ───────────────────────────────────────────────────
  async placeBet(userId: string, amount: number, autoCashout?: number, ip?: string) {
    if (!this.currentRound || this.currentRound.state !== CrashState.WAITING) {
      throw new BadRequestException('Apostas encerradas para este round.');
    }
    if (this.currentRound.players.has(userId)) {
      throw new BadRequestException('Você já apostou neste round.');
    }

    const game = await this.prisma.game.findUnique({ where: { type: 'CRASH' } });
    if (!game) throw new BadRequestException('Jogo indisponível.');
    if (amount < Number(game.minBet)) throw new BadRequestException(`Aposta mínima: ${game.minBet} AUR`);
    if (amount > Number(game.maxBet)) throw new BadRequestException(`Aposta máxima: ${game.maxBet} AUR`);

    // Debitar da carteira (método transacional)
    await this.wallet.debitBalance(userId, amount, 'AUR');

    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });

    const bet = await this.prisma.bet.create({
      data: {
        userId,
        gameId:     game.id,
        roundId:    this.currentRound.id,
        amount,
        currency:   'AUR',
        status:     'PLACED',
        data:       { autoCashout: autoCashout ?? null },
        clientSeed: this.currentRound.clientSeed,
        nonce:      this.currentRound.nonce,
        ipAddress:  ip,
      },
    });

    this.currentRound.players.set(userId, {
      userId,
      username:   user.username,
      betId:      bet.id,
      amount,
      autoCashout,
    });

    this.gateway.broadcastCrash('player_bet', {
      username: user.username,
      amount,
      totalPlayers: this.currentRound.players.size,
    });

    return { betId: bet.id, amount, autoCashout };
  }

  // ── SAQUE MANUAL ──────────────────────────────────────────────
  async cashout(userId: string, currentMultiplier?: number): Promise<{ payout: number; multiplier: number }> {
    if (!this.currentRound || this.currentRound.state !== CrashState.RUNNING) {
      throw new BadRequestException('Não é possível sacar agora.');
    }

    const player = this.currentRound.players.get(userId);
    if (!player) throw new BadRequestException('Você não tem aposta neste round.');
    if (player.cashedOutAt) throw new BadRequestException('Você já sacou neste round.');

    const mult    = currentMultiplier ?? this.currentRound.multiplier;
    const payout  = Math.floor(player.amount * mult * 100) / 100;
    player.cashedOutAt = mult;
    player.payout      = payout;

    await this.wallet.creditBalance(userId, payout, 'AUR', 'WIN');

    await this.prisma.bet.update({
      where: { id: player.betId },
      data: {
        status:     'WON',
        multiplier: mult,
        payout,
        profit:     payout - player.amount,
        resolvedAt: new Date(),
        result:     { cashedOutAt: mult },
      },
    });

    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    this.gateway.broadcastCrash('player_cashout', {
      username: user.username,
      multiplier: mult,
      payout,
    });

    return { payout, multiplier: mult };
  }

  // ── PRIVADOS ──────────────────────────────────────────────────
  private async resolveLostBet(betId: string, userId: string, amount: number, crashPoint: number) {
    await this.prisma.bet.update({
      where: { id: betId },
      data: {
        status: 'LOST',
        payout: 0,
        profit: -amount,
        resolvedAt: new Date(),
        result: { crashPoint },
      },
    });
  }

  private async incrementNonce(): Promise<number> {
    const val = await this.redis.incr('crash:nonce');
    return Number(val);
  }

  // ── ESTADO PÚBLICO ────────────────────────────────────────────
  getState() {
    if (!this.currentRound) return { state: 'WAITING', history: [] };
    return {
      state:          this.currentRound.state,
      multiplier:     this.currentRound.multiplier,
      serverSeedHash: this.currentRound.serverSeedHash,
      players:        this.currentRound.players.size,
      history:        (this.currentRound.history ?? []).slice(-20),
    };
  }
}
