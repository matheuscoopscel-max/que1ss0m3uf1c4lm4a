import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { GamesController } from './games.controller';
import { GamesService }    from './games.service';
import { CrashService }    from './crash/crash.service';
import { RouletteService } from './roulette/roulette.service';
import { BlackjackService } from './blackjack/blackjack.service';
import { DiceService }     from './dice/dice.service';
import { MinesService }    from './mines/mines.service';
import { RngService }      from './rng.service';
import { CollectiblesModule } from '../collectibles/collectibles.module';
import { PaymentsModule }     from '../payments/payments.module';
import { AuditModule }        from '../audit/audit.module';
import { WebsocketModule }    from '../websocket/websocket.module';

@Module({
  imports: [
    BullModule.registerQueue({ name: 'games' }),
    CollectiblesModule,
    PaymentsModule,
    AuditModule,
    WebsocketModule,
  ],
  controllers: [GamesController],
  providers: [
    GamesService, RngService,
    CrashService, RouletteService, BlackjackService, DiceService, MinesService,
  ],
  exports: [GamesService, CrashService],
})
export class GamesModule {}
