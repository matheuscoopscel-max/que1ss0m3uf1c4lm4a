import { Module } from '@nestjs/common';
import { GameGateway }    from './game.gateway';
import { WalletGateway }  from './wallet.gateway';
import { RedisIoAdapter } from './redis-io.adapter';

@Module({
  providers: [GameGateway, WalletGateway],
  exports:   [GameGateway, WalletGateway],
})
export class WebsocketModule {}
