import {
  WebSocketGateway, WebSocketServer,
  OnGatewayConnection, OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { OnEvent } from '@nestjs/event-emitter';

@WebSocketGateway({
  namespace: '/wallet',
  cors: {
    origin:      process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
  },
})
export class WalletGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private readonly logger = new Logger(WalletGateway.name);

  constructor(
    private readonly jwt:    JwtService,
    private readonly config: ConfigService,
  ) {}

  async handleConnection(client: Socket) {
    try {
      const token = client.handshake.auth?.token;
      if (!token) { client.disconnect(); return; }

      const payload = this.jwt.verify(token, { secret: this.config.get('JWT_SECRET') });
      client.data.userId = payload.sub;
      client.join(`wallet:${payload.sub}`);
    } catch {
      client.disconnect();
    }
  }

  handleDisconnect(client: Socket) {}

  @OnEvent('wallet.credited')
  handleCredited(data: { userId: string; amount: number; currency: string; balance: number }) {
    this.server.to(`wallet:${data.userId}`).emit('balance:update', {
      currency: data.currency,
      balance:  data.balance,
      change:   data.amount,
      type:     'credit',
    });
  }

  @OnEvent('wallet.debited')
  handleDebited(data: { userId: string; amount: number; currency: string; balance: number }) {
    this.server.to(`wallet:${data.userId}`).emit('balance:update', {
      currency: data.currency,
      balance:  data.balance,
      change:   -data.amount,
      type:     'debit',
    });
  }

  @OnEvent('collectible.earned')
  handleCollectibleEarned(data: { userId: string; collectible: any }) {
    this.server.to(`wallet:${data.userId}`).emit('collectible:earned', {
      collectible: data.collectible,
    });
  }
}
