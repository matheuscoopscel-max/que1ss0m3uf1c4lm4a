import {
  WebSocketGateway, WebSocketServer, SubscribeMessage,
  OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect,
  ConnectedSocket, MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Logger, UseGuards } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../common/services/prisma.service';

@WebSocketGateway({
  namespace: '/game',
  cors: {
    origin:      process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
  },
  transports: ['websocket', 'polling'],
})
export class GameGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private readonly logger = new Logger(GameGateway.name);

  constructor(
    private readonly jwt:     JwtService,
    private readonly config:  ConfigService,
    private readonly prisma:  PrismaService,
  ) {}

  afterInit() {
    this.logger.log('Game WebSocket Gateway iniciado');
  }

  async handleConnection(client: Socket) {
    try {
      const token = client.handshake.auth?.token || client.handshake.headers?.authorization?.replace('Bearer ', '');
      if (!token) { client.disconnect(); return; }

      const payload = this.jwt.verify(token, { secret: this.config.get('JWT_SECRET') });
      client.data.userId = payload.sub;
      client.data.role   = payload.role;

      // Entrar em salas de usuário (para eventos personalizados)
      client.join(`user:${payload.sub}`);
      this.logger.log(`User ${payload.sub} conectado ao Game WS`);
    } catch {
      client.disconnect();
    }
  }

  handleDisconnect(client: Socket) {
    if (client.data.userId) {
      this.logger.log(`User ${client.data.userId} desconectado do Game WS`);
    }
  }

  // ── Mensagens do cliente ──────────────────────────────────────

  @SubscribeMessage('join:crash')
  handleJoinCrash(@ConnectedSocket() client: Socket) {
    client.join('crash');
    return { event: 'joined', room: 'crash' };
  }

  @SubscribeMessage('leave:crash')
  handleLeaveCrash(@ConnectedSocket() client: Socket) {
    client.leave('crash');
  }

  @SubscribeMessage('join:roulette')
  handleJoinRoulette(@ConnectedSocket() client: Socket) {
    client.join('roulette');
    return { event: 'joined', room: 'roulette' };
  }

  @SubscribeMessage('crash:cashout')
  async handleCrashCashout(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { betId: string },
  ) {
    if (!client.data.userId) return;
    // Emitir evento para CrashService processar
    this.server.emit('crash:cashout_request', { userId: client.data.userId, betId: data.betId });
  }

  // ── Broadcasts (chamados por outros serviços) ─────────────────

  broadcastCrash(event: string, data: any) {
    this.server.to('crash').emit(`crash:${event}`, data);
  }

  broadcastRoulette(event: string, data: any) {
    this.server.to('roulette').emit(`roulette:${event}`, data);
  }

  broadcastToUser(userId: string, event: string, data: any) {
    this.server.to(`user:${userId}`).emit(event, data);
  }

  broadcastAll(event: string, data: any) {
    this.server.emit(event, data);
  }
}
