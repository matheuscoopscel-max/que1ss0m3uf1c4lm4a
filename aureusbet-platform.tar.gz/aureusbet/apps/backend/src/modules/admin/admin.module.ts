import { Module } from '@nestjs/common';
import { AdminController }       from './admin.controller';
import { AdminService }          from './admin.service';
import { AdminUsersController }  from './controllers/admin-users.controller';
import { AdminGamesController }  from './controllers/admin-games.controller';
import { AdminFinanceController } from './controllers/admin-finance.controller';
import { AdminCollectiblesController } from './controllers/admin-collectibles.controller';
import { AdminConfigController } from './controllers/admin-config.controller';
import { AdminUsersService }     from './services/admin-users.service';
import { AdminGamesService }     from './services/admin-games.service';
import { AdminFinanceService }   from './services/admin-finance.service';
import { AdminCollectiblesService } from './services/admin-collectibles.service';
import { StorageModule }         from '../storage/storage.module';
import { PaymentsModule }        from '../payments/payments.module';
import { AuditModule }           from '../audit/audit.module';

@Module({
  imports: [StorageModule, PaymentsModule, AuditModule],
  controllers: [
    AdminController, AdminUsersController, AdminGamesController,
    AdminFinanceController, AdminCollectiblesController, AdminConfigController,
  ],
  providers: [
    AdminService, AdminUsersService, AdminGamesService,
    AdminFinanceService, AdminCollectiblesService,
  ],
})
export class AdminModule {}
