import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AdminService }  from './admin.service';
import { JwtAuthGuard }  from '../auth/guards/jwt-auth.guard';
import { RolesGuard }    from '../../common/guards/roles.guard';
import { Roles }         from '../../common/decorators/roles.decorator';

@ApiTags('Admin')
@Controller('admin')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN')
@ApiBearerAuth('JWT')
export class AdminController {
  constructor(private readonly admin: AdminService) {}

  @Get('dashboard')
  getDashboard() { return this.admin.getDashboard(); }

  @Get('analytics')
  getAnalytics() { return this.admin.getAnalytics(); }

  @Get('realtime')
  getRealtime() { return this.admin.getRealtimeStats(); }
}
