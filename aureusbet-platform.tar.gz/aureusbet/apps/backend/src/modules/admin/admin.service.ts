import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../common/services/prisma.service';

@Injectable()
export class AdminService {
  constructor(private readonly prisma: PrismaService) {}

  async getDashboard() {
    const today = new Date(); today.setHours(0,0,0,0);

    const [
      totalUsers, activeUsers, newUsersToday,
      totalBets, betsToday,
      totalVolume, volumeToday,
      pendingWithdrawals, openTickets,
      suspiciousCount,
    ] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.user.count({ where: { status: 'ACTIVE' } }),
      this.prisma.user.count({ where: { createdAt: { gte: today } } }),
      this.prisma.bet.count(),
      this.prisma.bet.count({ where: { createdAt: { gte: today } } }),
      this.prisma.transaction.aggregate({ where: { type: 'BET', status: 'COMPLETED' }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { type: 'BET', status: 'COMPLETED', createdAt: { gte: today } }, _sum: { amount: true } }),
      this.prisma.withdrawalRequest.count({ where: { status: 'PENDING' } }),
      this.prisma.supportTicket.count({ where: { status: { in: ['OPEN', 'IN_PROGRESS'] } } }),
      this.prisma.suspiciousActivity.count({ where: { reviewed: false } }),
    ]);

    return {
      users:       { total: totalUsers, active: activeUsers, newToday: newUsersToday },
      bets:        { total: Number(totalBets), today: Number(betsToday) },
      volume:      { total: Number(totalVolume._sum.amount ?? 0), today: Number(volumeToday._sum.amount ?? 0) },
      pending:     { withdrawals: pendingWithdrawals, tickets: openTickets, suspicious: suspiciousCount },
    };
  }

  async getAnalytics() {
    const last30 = new Date(Date.now() - 30 * 86400000);

    const [gameStats, dailyVolume, topPlayers] = await Promise.all([
      this.prisma.game.findMany({
        select: { name: true, type: true, totalBets: true, totalVolume: true, totalPayout: true, houseEdge: true },
      }),
      this.prisma.$queryRaw`
        SELECT DATE(created_at) as date, SUM(amount) as volume, COUNT(*) as bets
        FROM bets WHERE created_at >= ${last30} AND status = 'WON' OR status = 'LOST'
        GROUP BY DATE(created_at) ORDER BY date DESC LIMIT 30
      `,
      this.prisma.user.findMany({
        where:   { status: 'ACTIVE' },
        orderBy: { wallet: { totalLost: 'desc' } },
        take:    10,
        select:  { username: true, wallet: { select: { totalLost: true, totalWon: true } } },
      }),
    ]);

    return { gameStats, dailyVolume, topPlayers };
  }

  async getRealtimeStats() {
    const since1h = new Date(Date.now() - 3600000);
    const [activeSessions, betsLastHour, depositsLastHour] = await Promise.all([
      this.prisma.session.count({ where: { isValid: true, expiresAt: { gt: new Date() } } }),
      this.prisma.bet.count({ where: { createdAt: { gte: since1h } } }),
      this.prisma.transaction.aggregate({
        where: { type: 'DEPOSIT', status: 'COMPLETED', createdAt: { gte: since1h } },
        _sum:  { amount: true },
      }),
    ]);

    return {
      activeSessions,
      betsLastHour,
      depositsLastHour: Number(depositsLastHour._sum.amount ?? 0),
      timestamp:        new Date(),
    };
  }
}
