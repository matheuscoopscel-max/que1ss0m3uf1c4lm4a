import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AdminFinanceService } from '../services/admin-finance.service';
import { JwtAuthGuard }        from '../../auth/guards/jwt-auth.guard';
import { RolesGuard }          from '../../../common/guards/roles.guard';
import { Roles }               from '../../../common/decorators/roles.decorator';
import { CurrentUser }         from '../../../common/decorators/current-user.decorator';

@ApiTags('Admin')
@Controller('admin/finance')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN')
@ApiBearerAuth('JWT')
export class AdminFinanceController {
  constructor(private readonly service: AdminFinanceService) {}

  @Get('summary')  getSummary()   { return this.service.getFinancialSummary(); }

  @Get('withdrawals')
  getWithdrawals(@Query('page') p = 1, @Query('perPage') pp = 20) {
    return this.service.getPendingWithdrawals(p, pp);
  }

  @Post('withdrawals/:id/approve')
  approve(@CurrentUser('id') adminId: string, @Param('id') id: string) {
    return this.service.approveWithdrawal(adminId, id);
  }

  @Post('withdrawals/:id/reject')
  reject(@CurrentUser('id') adminId: string, @Param('id') id: string, @Body('reason') reason: string) {
    return this.service.rejectWithdrawal(adminId, id, reason);
  }

  @Post('aur-rate')
  @Roles('SUPER_ADMIN')
  setRate(@CurrentUser('id') adminId: string, @Body('rateAurBrl') rate: number) {
    return this.service.setAurConversionRate(adminId, rate);
  }
}
