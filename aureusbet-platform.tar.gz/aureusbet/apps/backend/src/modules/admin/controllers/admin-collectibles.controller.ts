import { Controller, Get, Post, Patch, Param, Query, Body, UseGuards, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AdminCollectiblesService } from '../services/admin-collectibles.service';
import { JwtAuthGuard }  from '../../auth/guards/jwt-auth.guard';
import { RolesGuard }    from '../../../common/guards/roles.guard';
import { Roles }         from '../../../common/decorators/roles.decorator';
import { CurrentUser }   from '../../../common/decorators/current-user.decorator';

@ApiTags('Admin')
@Controller('admin/collectibles')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN')
@ApiBearerAuth('JWT')
export class AdminCollectiblesController {
  constructor(private readonly service: AdminCollectiblesService) {}

  @Get()
  list(@Query('page') p = 1, @Query('perPage') pp = 50) { return this.service.list(p, pp); }

  @Post()
  @UseInterceptors(FileInterceptor('image'))
  create(@CurrentUser('id') adminId: string, @Body() body: any, @UploadedFile() image: Express.Multer.File) {
    return this.service.create(adminId, body, image);
  }

  @Patch(':id')
  @UseInterceptors(FileInterceptor('image'))
  update(
    @CurrentUser('id') adminId: string,
    @Param('id') id: string, @Body() body: any,
    @UploadedFile() image?: Express.Multer.File,
  ) {
    return this.service.update(adminId, id, body, image);
  }

  @Post(':id/deactivate')
  deactivate(@CurrentUser('id') adminId: string, @Param('id') id: string) {
    return this.service.deactivate(adminId, id);
  }
}
