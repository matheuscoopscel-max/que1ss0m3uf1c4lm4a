import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards, UploadedFile, UseInterceptors } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AdminUsersService } from '../services/admin-users.service';
import { JwtAuthGuard }      from '../../auth/guards/jwt-auth.guard';
import { RolesGuard }        from '../../../common/guards/roles.guard';
import { Roles }             from '../../../common/decorators/roles.decorator';
import { CurrentUser }       from '../../../common/decorators/current-user.decorator';

@ApiTags('Admin')
@Controller('admin/users')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN')
@ApiBearerAuth('JWT')
export class AdminUsersController {
  constructor(private readonly service: AdminUsersService) {}

  @Get()
  list(@Query() q: any) { return this.service.list(q); }

  @Get(':userId')
  getOne(@Param('userId') uid: string) { return this.service.getOne(uid); }

  @Post(':userId/ban')
  ban(@CurrentUser('id') adminId: string, @Param('userId') uid: string, @Body('reason') reason: string) {
    return this.service.ban(adminId, uid, reason);
  }

  @Post(':userId/unban')
  unban(@CurrentUser('id') adminId: string, @Param('userId') uid: string) {
    return this.service.unban(adminId, uid);
  }

  @Post(':userId/kyc/approve')
  approveKyc(@CurrentUser('id') adminId: string, @Param('userId') uid: string) {
    return this.service.approveKyc(adminId, uid);
  }

  @Post(':userId/kyc/reject')
  rejectKyc(@CurrentUser('id') adminId: string, @Param('userId') uid: string, @Body('reason') reason: string) {
    return this.service.rejectKyc(adminId, uid, reason);
  }

  @Patch(':userId/role')
  updateRole(@CurrentUser('id') adminId: string, @Param('userId') uid: string, @Body('role') role: string) {
    return this.service.updateRole(adminId, uid, role);
  }

  @Post(':userId/balance/adjust')
  @Roles('SUPER_ADMIN')
  adjustBalance(
    @CurrentUser('id') adminId: string, @Param('userId') uid: string,
    @Body('amount') amount: number, @Body('reason') reason: string,
  ) {
    return this.service.adjustBalance(adminId, uid, amount, reason);
  }
}
