import { Controller, Get, Post, Patch, Body, Param, UploadedFile, UseInterceptors, UseGuards } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard }  from '../../auth/guards/jwt-auth.guard';
import { RolesGuard }    from '../../../common/guards/roles.guard';
import { Roles }         from '../../../common/decorators/roles.decorator';
import { CurrentUser }   from '../../../common/decorators/current-user.decorator';
import { PrismaService } from '../../../common/services/prisma.service';
import { StorageService } from '../../storage/storage.service';
import { AuditService }  from '../../audit/audit.service';

@ApiTags('Admin')
@Controller('admin/config')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('SUPER_ADMIN')
@ApiBearerAuth('JWT')
export class AdminConfigController {
  constructor(
    private readonly prisma:   PrismaService,
    private readonly storage:  StorageService,
    private readonly audit:    AuditService,
  ) {}

  @Get()
  getAll() { return this.prisma.siteConfig.findMany({ orderBy: { group: 'asc' } }); }

  @Patch(':key')
  async update(@CurrentUser('id') adminId: string, @Param('key') key: string, @Body('value') value: any) {
    const config = await this.prisma.siteConfig.upsert({
      where:  { key },
      create: { key, value, updatedById: adminId },
      update: { value, updatedById: adminId },
    });
    await this.audit.log({ adminId, action: 'ADMIN_ACTION', metadata: { action: 'config_update', key } });
    return config;
  }

  // Upload de assets globais (logo, backgrounds, etc.)
  @Post('assets/:category')
  @UseInterceptors(FileInterceptor('file'))
  async uploadAsset(
    @CurrentUser('id') adminId: string,
    @Param('category') category: string,
    @UploadedFile() file: Express.Multer.File,
    @Body('key') key: string,
  ) {
    const url = await this.storage.uploadPublic(file, `site-assets/${category}/${key || file.originalname}`);

    await this.prisma.siteConfig.upsert({
      where:  { key: `asset_${category}_${key}` },
      create: { key: `asset_${category}_${key}`, value: { url }, group: 'assets', updatedById: adminId },
      update: { value: { url }, updatedById: adminId },
    });

    return { url };
  }

  @Get('banners')
  getBanners() { return this.prisma.banner.findMany({ orderBy: { sortOrder: 'asc' } }); }

  @Post('banners')
  @UseInterceptors(FileInterceptor('image'))
  async createBanner(
    @CurrentUser('id') adminId: string, @Body() body: any, @UploadedFile() image: Express.Multer.File,
  ) {
    const imageUrl = await this.storage.uploadPublic(image, `banners/${Date.now()}`);
    return this.prisma.banner.create({
      data: { ...body, imageUrl, createdById: adminId },
    });
  }

  @Patch('banners/:id')
  updateBanner(@Param('id') id: string, @Body() body: any) {
    return this.prisma.banner.update({ where: { id }, data: body });
  }
}
