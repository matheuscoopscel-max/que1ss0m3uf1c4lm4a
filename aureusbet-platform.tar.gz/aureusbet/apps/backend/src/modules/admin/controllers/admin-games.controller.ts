import { Controller, Get, Patch, Post, Body, Param, Query, UseGuards, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AdminGamesService } from '../services/admin-games.service';
import { JwtAuthGuard }      from '../../auth/guards/jwt-auth.guard';
import { RolesGuard }        from '../../../common/guards/roles.guard';
import { Roles }             from '../../../common/decorators/roles.decorator';
import { CurrentUser }       from '../../../common/decorators/current-user.decorator';

@ApiTags('Admin')
@Controller('admin/games')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN')
@ApiBearerAuth('JWT')
export class AdminGamesController {
  constructor(private readonly service: AdminGamesService) {}

  @Get() list() { return this.service.list(); }

  @Patch(':gameType')
  update(@CurrentUser('id') adminId: string, @Param('gameType') type: string, @Body() body: any) {
    return this.service.update(adminId, type, body);
  }

  @Post(':gameType/assets/:field')
  @UseInterceptors(FileInterceptor('file'))
  uploadAsset(
    @CurrentUser('id') adminId: string,
    @Param('gameType') type: string,
    @Param('field') field: string,
    @UploadedFile() file: Express.Multer.File,
  ) {
    return this.service.uploadGameAsset(adminId, type, field, file);
  }

  @Get(':gameType/bets')
  getBets(@Param('gameType') type: string, @Query('page') p = 1, @Query('perPage') pp = 50) {
    return this.service.getBetHistory(type, p, pp);
  }
}
