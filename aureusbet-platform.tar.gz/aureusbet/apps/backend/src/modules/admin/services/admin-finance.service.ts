import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../../common/services/prisma.service';
import { WalletService } from '../../payments/wallet.service';
import { AuditService }  from '../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class AdminFinanceService {
  constructor(
    private readonly prisma:   PrismaService,
    private readonly wallet:   WalletService,
    private readonly audit:    AuditService,
    private readonly emitter:  EventEmitter2,
  ) {}

  async getPendingWithdrawals(page = 1, perPage = 20) {
    return this.prisma.paginate(
      this.prisma.withdrawalRequest,
      {
        where:   { status: 'PENDING' },
        include: { user: { select: { username: true, email: true, kycStatus: true } } },
        orderBy: { createdAt: 'asc' },
      },
      page, perPage,
    );
  }

  async approveWithdrawal(adminId: string, withdrawalId: string) {
    const req = await this.prisma.withdrawalRequest.findUnique({
      where: { id: withdrawalId },
      include: { user: true },
    });
    if (!req) throw new NotFoundException('Solicitação não encontrada.');
    if (req.status !== 'PENDING') throw new BadRequestException('Solicitação já processada.');

    await this.prisma.$transaction(async (tx) => {
      await tx.withdrawalRequest.update({
        where: { id: withdrawalId },
        data:  { status: 'COMPLETED', reviewedById: adminId, reviewedAt: new Date(), completedAt: new Date() },
      });

      await tx.wallet.update({
        where: { userId: req.userId },
        data:  {
          lockedBalance:  { decrement: Number(req.amount) },
          totalWithdrawn: { increment: Number(req.amount) },
        },
      });
    });

    await this.audit.log({
      adminId,
      action:   'WITHDRAWAL',
      entityId: withdrawalId,
      metadata: { action: 'withdrawal_approved', userId: req.userId, amount: Number(req.amount) },
    });

    this.emitter.emit('withdrawal.approved', { withdrawalId, userId: req.userId });
    return { success: true };
  }

  async rejectWithdrawal(adminId: string, withdrawalId: string, reason: string) {
    const req = await this.prisma.withdrawalRequest.findUnique({ where: { id: withdrawalId } });
    if (!req) throw new NotFoundException();
    if (req.status !== 'PENDING') throw new BadRequestException('Já processado.');

    await this.prisma.$transaction(async (tx) => {
      await tx.withdrawalRequest.update({
        where: { id: withdrawalId },
        data:  { status: 'FAILED', reviewedById: adminId, reviewedAt: new Date(), rejectReason: reason },
      });

      // Devolver saldo bloqueado
      await tx.wallet.update({
        where: { userId: req.userId },
        data: {
          aurBalance:    { increment: Number(req.amount) },
          lockedBalance: { decrement: Number(req.amount) },
        },
      });
    });

    this.emitter.emit('withdrawal.rejected', { withdrawalId, userId: req.userId, reason });
    return { success: true };
  }

  async getFinancialSummary() {
    const [totalDeposits, totalWithdrawals, totalBets, totalPayouts, houseProfit] = await Promise.all([
      this.prisma.transaction.aggregate({ where: { type: 'DEPOSIT', status: 'COMPLETED' }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { type: 'WITHDRAWAL', status: 'COMPLETED' }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { type: 'BET', status: 'COMPLETED' }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { type: 'WIN', status: 'COMPLETED' }, _sum: { amount: true } }),
      this.prisma.bet.aggregate({ where: { status: 'LOST' }, _sum: { amount: true } }),
    ]);

    return {
      totalDeposits:     Number(totalDeposits._sum.amount ?? 0),
      totalWithdrawals:  Number(totalWithdrawals._sum.amount ?? 0),
      totalBetsVolume:   Number(totalBets._sum.amount ?? 0),
      totalPayouts:      Number(totalPayouts._sum.amount ?? 0),
      houseProfit:       Number(houseProfit._sum.amount ?? 0) - Number(totalPayouts._sum.amount ?? 0),
    };
  }

  async setAurConversionRate(adminId: string, rateAurBrl: number) {
    if (rateAurBrl <= 0) throw new BadRequestException('Taxa inválida.');

    const rate = await this.prisma.aurConversionRate.create({
      data: { rateAurBrl, setById: adminId },
    });

    await this.prisma.siteConfig.upsert({
      where:  { key: 'aur_brl_rate' },
      create: { key: 'aur_brl_rate', value: { rate: rateAurBrl }, updatedById: adminId },
      update: { value: { rate: rateAurBrl }, updatedById: adminId },
    });

    return rate;
  }
}
