import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../../common/services/prisma.service';
import { AuditService }  from '../../audit/audit.service';
import { StorageService } from '../../storage/storage.service';

@Injectable()
export class AdminGamesService {
  constructor(
    private readonly prisma:   PrismaService,
    private readonly audit:    AuditService,
    private readonly storage:  StorageService,
  ) {}

  async list() {
    return this.prisma.game.findMany({ orderBy: { sortOrder: 'asc' } });
  }

  async update(adminId: string, gameType: string, data: any) {
    const game = await this.prisma.game.findUnique({ where: { type: gameType as any } });
    if (!game) throw new NotFoundException('Jogo não encontrado.');

    const { name, description, longDescription, status, houseEdge, minBet, maxBet, isFeatured, isNew, sortOrder, settings, collectibleDropRate } = data;

    const updated = await this.prisma.game.update({
      where: { type: gameType as any },
      data:  {
        ...(name               !== undefined ? { name }               : {}),
        ...(description        !== undefined ? { description }        : {}),
        ...(longDescription    !== undefined ? { longDescription }    : {}),
        ...(status             !== undefined ? { status }             : {}),
        ...(houseEdge          !== undefined ? { houseEdge }          : {}),
        ...(minBet             !== undefined ? { minBet }             : {}),
        ...(maxBet             !== undefined ? { maxBet }             : {}),
        ...(isFeatured         !== undefined ? { isFeatured }         : {}),
        ...(isNew              !== undefined ? { isNew }              : {}),
        ...(sortOrder          !== undefined ? { sortOrder }          : {}),
        ...(settings           !== undefined ? { settings }           : {}),
        ...(collectibleDropRate !== undefined ? { collectibleDropRate } : {}),
      },
    });

    await this.audit.log({ adminId, action: 'ADMIN_ACTION', entityId: game.id, metadata: { action: 'game_update', changes: data } });
    return updated;
  }

  async uploadGameAsset(adminId: string, gameType: string, field: string, file: Express.Multer.File) {
    const url = await this.storage.uploadPublic(file, `games/${gameType}/${field}`);

    await this.prisma.game.update({
      where: { type: gameType as any },
      data:  { [field]: url },
    });

    return { url };
  }

  async getBetHistory(gameType: string, page = 1, perPage = 50) {
    const game = await this.prisma.game.findUnique({ where: { type: gameType as any } });
    if (!game) throw new NotFoundException();

    return this.prisma.paginate(
      this.prisma.bet,
      {
        where:   { gameId: game.id },
        include: { user: { select: { username: true } } },
        orderBy: { createdAt: 'desc' },
      },
      page, perPage,
    );
  }
}
