import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService }  from '../../../common/services/prisma.service';
import { StorageService } from '../../storage/storage.service';
import { AuditService }   from '../../audit/audit.service';

@Injectable()
export class AdminCollectiblesService {
  constructor(
    private readonly prisma:   PrismaService,
    private readonly storage:  StorageService,
    private readonly audit:    AuditService,
  ) {}

  async create(adminId: string, data: any, imageFile: Express.Multer.File) {
    const slug = data.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');

    const existing = await this.prisma.collectible.findUnique({ where: { slug } });
    if (existing) throw new BadRequestException('Já existe um colecionável com este nome.');

    const imageUrl = await this.storage.uploadPublic(imageFile, `collectibles/${slug}`);

    const collectible = await this.prisma.collectible.create({
      data: {
        name:        data.name,
        slug,
        description: data.description,
        imageUrl,
        rarity:      data.rarity ?? 'COMMON',
        maxSupply:   data.maxSupply ?? 1,
        isTransferable: data.isTransferable ?? true,
        dropWeight:  data.dropWeight ?? 1,
        createdById: adminId,
      },
    });

    await this.audit.log({ adminId, action: 'ADMIN_ACTION', entityId: collectible.id, metadata: { action: 'collectible_created' } });
    return collectible;
  }

  async update(adminId: string, collectibleId: string, data: any, imageFile?: Express.Multer.File) {
    const existing = await this.prisma.collectible.findUnique({ where: { id: collectibleId } });
    if (!existing) throw new NotFoundException('Colecionável não encontrado.');

    let imageUrl = existing.imageUrl;
    if (imageFile) {
      imageUrl = await this.storage.uploadPublic(imageFile, `collectibles/${existing.slug}`);
    }

    const updated = await this.prisma.collectible.update({
      where: { id: collectibleId },
      data:  { ...data, imageUrl },
    });

    await this.audit.log({ adminId, action: 'ADMIN_ACTION', entityId: collectibleId, metadata: { action: 'collectible_updated' } });
    return updated;
  }

  async list(page = 1, perPage = 50) {
    return this.prisma.paginate(
      this.prisma.collectible,
      {
        include: { _count: { select: { owners: true } } },
        orderBy: { createdAt: 'desc' },
      },
      page, perPage,
    );
  }

  async deactivate(adminId: string, collectibleId: string) {
    await this.prisma.collectible.update({ where: { id: collectibleId }, data: { isActive: false } });
    await this.audit.log({ adminId, action: 'ADMIN_ACTION', entityId: collectibleId, metadata: { action: 'collectible_deactivated' } });
    return { success: true };
  }
}
