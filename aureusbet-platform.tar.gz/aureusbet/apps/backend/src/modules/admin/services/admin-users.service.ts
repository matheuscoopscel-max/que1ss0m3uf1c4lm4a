import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../../common/services/prisma.service';
import { AuditService }  from '../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class AdminUsersService {
  constructor(
    private readonly prisma:  PrismaService,
    private readonly audit:   AuditService,
    private readonly emitter: EventEmitter2,
  ) {}

  async list(filters: any) {
    const { search, status, role, kycStatus, page = 1, perPage = 20 } = filters;
    return this.prisma.paginate(
      this.prisma.user,
      {
        where: {
          ...(search ? {
            OR: [
              { email:       { contains: search, mode: 'insensitive' } },
              { username:    { contains: search, mode: 'insensitive' } },
              { displayName: { contains: search, mode: 'insensitive' } },
            ],
          } : {}),
          ...(status    ? { status }    : {}),
          ...(role      ? { role }      : {}),
          ...(kycStatus ? { kycStatus } : {}),
        },
        include: { wallet: true },
        orderBy: { createdAt: 'desc' },
      },
      page, perPage,
    );
  }

  async getOne(userId: string) {
    const user = await this.prisma.user.findUnique({
      where:   { id: userId },
      include: {
        wallet:      true,
        kycDocuments: { orderBy: { createdAt: 'desc' } },
        bets:        { take: 20, orderBy: { createdAt: 'desc' } },
        transactions: { take: 20, orderBy: { createdAt: 'desc' } },
        collectibles: { include: { collectible: true } },
        suspiciousActivities: { take: 10, orderBy: { createdAt: 'desc' } },
        auditLogs:   { take: 20, orderBy: { createdAt: 'desc' } },
      },
    });
    if (!user) throw new NotFoundException('Usuário não encontrado.');
    return user;
  }

  async ban(adminId: string, userId: string, reason: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('Usuário não encontrado.');
    if (user.role === 'SUPER_ADMIN') throw new BadRequestException('Não é possível banir um Super Admin.');

    await this.prisma.user.update({
      where: { id: userId },
      data:  { isBanned: true, banReason: reason, bannedAt: new Date(), bannedById: adminId, status: 'BANNED' },
    });

    // Revogar todos os tokens
    await this.prisma.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data:  { revokedAt: new Date() },
    });

    await this.audit.log({ userId: adminId, adminId, action: 'ACCOUNT_BANNED', entityId: userId, metadata: { reason } });
    this.emitter.emit('user.banned', { userId, reason });
    return { success: true };
  }

  async unban(adminId: string, userId: string) {
    await this.prisma.user.update({
      where: { id: userId },
      data:  { isBanned: false, banReason: null, bannedAt: null, bannedById: null, status: 'ACTIVE' },
    });
    await this.audit.log({ adminId, action: 'ACCOUNT_UNBANNED', entityId: userId });
    return { success: true };
  }

  async approveKyc(adminId: string, userId: string) {
    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: userId }, data: { kycStatus: 'APPROVED' } });
      await tx.kycDocument.updateMany({
        where: { userId, status: 'PENDING' },
        data:  { status: 'APPROVED', reviewedById: adminId, reviewedAt: new Date() },
      });
    });
    await this.audit.log({ adminId, action: 'KYC_APPROVED', entityId: userId });
    this.emitter.emit('user.kyc_approved', { userId });
    return { success: true };
  }

  async rejectKyc(adminId: string, userId: string, reason: string) {
    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: userId }, data: { kycStatus: 'REJECTED' } });
      await tx.kycDocument.updateMany({
        where: { userId, status: 'PENDING' },
        data:  { status: 'REJECTED', reviewedById: adminId, reviewedAt: new Date(), rejectReason: reason },
      });
    });
    await this.audit.log({ adminId, action: 'KYC_REJECTED', entityId: userId, metadata: { reason } });
    return { success: true };
  }

  async updateRole(adminId: string, userId: string, role: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException();
    await this.prisma.user.update({ where: { id: userId }, data: { role: role as any } });
    await this.audit.log({ adminId, action: 'ADMIN_ACTION', entityId: userId, metadata: { action: 'role_change', newRole: role } });
    return { success: true };
  }

  async selfExclude(adminId: string, userId: string, days: number | null) {
    const until = days ? new Date(Date.now() + days * 86400000) : null;
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        isSelfExcluded: true,
        selfExcludedUntil: until,
        status: 'SELF_EXCLUDED',
      },
    });
    await this.prisma.refreshToken.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } });
    await this.audit.log({ adminId, action: 'SELF_EXCLUSION', entityId: userId, metadata: { days } });
    return { success: true };
  }

  async adjustBalance(adminId: string, userId: string, amount: number, reason: string) {
    const wallet = await this.prisma.wallet.findUnique({ where: { userId } });
    if (!wallet) throw new NotFoundException('Carteira não encontrada.');

    const before = Number(wallet.aurBalance);
    const after  = before + amount;
    if (after < 0) throw new BadRequestException('Saldo ficaria negativo.');

    await this.prisma.$transaction(async (tx) => {
      await tx.wallet.update({ where: { userId }, data: { aurBalance: after } });
      await tx.transaction.create({
        data: {
          userId,
          walletId:      wallet.id,
          type:          amount > 0 ? 'BONUS' : 'FEE',
          status:        'COMPLETED',
          amount:        Math.abs(amount),
          currency:      'AUR',
          balanceBefore: before,
          balanceAfter:  after,
          description:   `Ajuste manual: ${reason}`,
          completedAt:   new Date(),
        },
      });
    });

    await this.audit.log({
      adminId,
      action:   'ADMIN_ACTION',
      entityId: userId,
      metadata: { action: 'balance_adjust', amount, reason },
    });
    return { success: true, newBalance: after };
  }
}
