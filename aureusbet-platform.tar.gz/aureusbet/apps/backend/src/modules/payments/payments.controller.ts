import {
  Controller, Post, Get, Body, Req, Param, Query,
  UseGuards, HttpCode, HttpStatus, RawBodyRequest,
} from '@nestjs/common';
import { Request } from 'express';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { PaymentsService } from './payments.service';
import { StripeService }   from './stripe.service';
import { PixService }      from './pix.service';
import { WalletService }   from './wallet.service';
import { JwtAuthGuard }    from '../auth/guards/jwt-auth.guard';
import { CurrentUser }     from '../../common/decorators/current-user.decorator';
import { GetIpAddress }    from '../../common/decorators/get-ip.decorator';

@ApiTags('Payments')
@Controller('payments')
export class PaymentsController {
  constructor(
    private readonly payments: PaymentsService,
    private readonly stripe:   StripeService,
    private readonly pix:      PixService,
    private readonly wallet:   WalletService,
  ) {}

  @Get('wallet')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  getWallet(@CurrentUser('id') uid: string) {
    return this.wallet.getWallet(uid);
  }

  @Get('balance')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  getBalance(@CurrentUser('id') uid: string) {
    return this.wallet.getBalance(uid);
  }

  @Get('transactions')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  getTransactions(
    @CurrentUser('id') uid: string,
    @Query('page') page = 1,
    @Query('perPage') perPage = 20,
    @Query('type') type?: string,
  ) {
    return this.wallet.getTransactionHistory(uid, page, perPage, type);
  }

  @Post('deposit/stripe')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  createStripeDeposit(
    @CurrentUser('id') uid: string,
    @Body('amountBrl') amountBrl: number,
    @Body('aurAmount') aurAmount: number,
  ) {
    return this.stripe.createPaymentIntent(uid, amountBrl, aurAmount);
  }

  @Post('deposit/pix')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  createPixDeposit(
    @CurrentUser('id') uid: string,
    @Body('amountBrl') amountBrl: number,
    @Body('aurAmount') aurAmount: number,
  ) {
    return this.pix.createPixDeposit(uid, amountBrl, aurAmount);
  }

  @Post('withdraw')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 3, ttl: 300000 } })
  createWithdrawal(
    @CurrentUser('id') uid: string,
    @Body('amountAur') amount: number,
    @Body('pixKey')    pixKey: string,
    @Body('pixKeyType') pixKeyType: string,
  ) {
    return this.pix.createWithdrawal(uid, amount, pixKey, pixKeyType);
  }

  @Post('transfer')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  transfer(
    @CurrentUser('id') uid: string,
    @Body('toUsername') toUsername: string,
    @Body('amount') amount: number,
    @GetIpAddress() ip: string,
  ) {
    return this.payments.transferByUsername(uid, toUsername, amount, ip);
  }

  @Post('subscription/create')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  createSubscription(@CurrentUser('id') uid: string, @Body('priceId') priceId: string) {
    return this.stripe.createSubscription(uid, priceId);
  }

  @Post('subscription/cancel')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  cancelSubscription(@CurrentUser('id') uid: string) {
    return this.stripe.cancelSubscription(uid);
  }

  // Webhooks — sem autenticação JWT, validados via assinaturas
  @Post('webhooks/stripe')
  @HttpCode(HttpStatus.OK)
  stripeWebhook(@Req() req: RawBodyRequest<Request>) {
    const sig = req.headers['stripe-signature'] as string;
    return this.stripe.handleWebhook(req.rawBody!, sig);
  }

  @Post('webhooks/pix')
  @HttpCode(HttpStatus.OK)
  pixWebhook(@Req() req: RawBodyRequest<Request>, @Body() body: any) {
    const sig = req.headers['x-pix-signature'] as string;
    return this.pix.handleWebhook(body, req.rawBody!, sig);
  }
}
