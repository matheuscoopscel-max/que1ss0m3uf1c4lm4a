import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../common/services/prisma.service';
import { EventEmitter2 } from '@nestjs/event-emitter';

interface AmlResult { riskScore: number; flags: string[]; shouldBlock: boolean; }

@Injectable()
export class AmlService {
  private readonly logger = new Logger(AmlService.name);

  constructor(
    private readonly prisma:  PrismaService,
    private readonly emitter: EventEmitter2,
  ) {}

  async analyzeTransaction(userId: string, amount: number, type: string): Promise<AmlResult> {
    const flags: string[] = [];
    let riskScore = 0;

    const [user, recentTx, totalToday] = await Promise.all([
      this.prisma.user.findUnique({ where: { id: userId } }),
      this.prisma.transaction.findMany({
        where:   { userId, createdAt: { gte: new Date(Date.now() - 3600000) } },
        orderBy: { createdAt: 'desc' },
        take:    50,
      }),
      this.prisma.transaction.aggregate({
        where: { userId, createdAt: { gte: new Date(Date.now() - 86400000) }, type: 'DEPOSIT', status: 'COMPLETED' },
        _sum:  { amount: true },
      }),
    ]);

    if (!user) return { riskScore: 0, flags: [], shouldBlock: false };

    // Transações de alto valor
    if (amount > 10000) { flags.push('HIGH_VALUE_TRANSACTION'); riskScore += 30; }
    if (amount > 50000) { flags.push('VERY_HIGH_VALUE'); riskScore += 50; }

    // Muitas transações em pouco tempo
    if (recentTx.length > 20) { flags.push('HIGH_FREQUENCY'); riskScore += 25; }

    // Depósito total alto em 24h (possível structuring)
    const dailyTotal = Number(totalToday._sum.amount ?? 0);
    if (dailyTotal > 9000 && dailyTotal < 10000) {
      flags.push('POSSIBLE_STRUCTURING'); riskScore += 40;
    }

    // KYC não aprovado com depósitos
    if (user.kycStatus !== 'APPROVED' && amount > 1000) {
      flags.push('KYC_NOT_APPROVED'); riskScore += 20;
    }

    // Conta recém criada com transação grande
    const accountAgeDays = (Date.now() - user.createdAt.getTime()) / 86400000;
    if (accountAgeDays < 7 && amount > 5000) {
      flags.push('NEW_ACCOUNT_HIGH_VALUE'); riskScore += 30;
    }

    const shouldBlock = riskScore >= 80;

    if (flags.length > 0) {
      await this.prisma.suspiciousActivity.create({
        data: {
          userId,
          type:        'AML_FLAG',
          severity:    riskScore >= 80 ? 'HIGH' : riskScore >= 50 ? 'MEDIUM' : 'LOW',
          description: `AML flags: ${flags.join(', ')}`,
          metadata:    { amount, type, riskScore, flags },
        },
      });

      if (shouldBlock) {
        this.emitter.emit('aml.high_risk', { userId, riskScore, flags, amount });
        this.logger.warn(`AML bloqueio: user ${userId}, score ${riskScore}, flags: ${flags.join(', ')}`);
      }
    }

    await this.prisma.transaction.updateMany({
      where: { userId, status: 'PENDING', type: type as any },
      data:  { amlChecked: true, amlFlagged: shouldBlock, amlNotes: flags.join(', ') || null },
    });

    return { riskScore, flags, shouldBlock };
  }

  async detectMultiAccount(userId: string, ip: string, fingerprint: string): Promise<boolean> {
    const [ipMatches, fingerprintMatches] = await Promise.all([
      this.prisma.user.count({ where: { ipAddress: ip, id: { not: userId } } }),
      fingerprint ? this.prisma.user.count({ where: { deviceFingerprint: fingerprint, id: { not: userId } } }) : Promise.resolve(0),
    ]);

    if (ipMatches > 2 || fingerprintMatches > 0) {
      await this.prisma.suspiciousActivity.create({
        data: {
          userId,
          type:     'MULTI_ACCOUNT',
          severity: 'HIGH',
          description: `Possível multi-conta: ${ipMatches} IPs, ${fingerprintMatches} fingerprints`,
          metadata: { ip, fingerprint, ipMatches, fingerprintMatches },
        },
      });
      this.emitter.emit('fraud.multi_account', { userId, ip, fingerprint });
      return true;
    }
    return false;
  }
}
