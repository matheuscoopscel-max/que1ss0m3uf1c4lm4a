import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../common/services/prisma.service';
import { WalletService } from './wallet.service';
import { AuditService }  from '../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { createHmac }    from 'crypto';
import axios from 'axios';

@Injectable()
export class PixService {
  private readonly logger = new Logger(PixService.name);
  private readonly gatewayUrl:   string;
  private readonly apiKey:       string;
  private readonly webhookSecret: string;

  constructor(
    private readonly config:  ConfigService,
    private readonly prisma:  PrismaService,
    private readonly wallet:  WalletService,
    private readonly audit:   AuditService,
    private readonly emitter: EventEmitter2,
  ) {
    this.gatewayUrl    = this.config.get<string>('PIX_GATEWAY_URL')!;
    this.apiKey        = this.config.get<string>('PIX_API_KEY')!;
    this.webhookSecret = this.config.get<string>('PIX_WEBHOOK_SECRET')!;
  }

  /** Gerar QR Code PIX para depósito */
  async createPixDeposit(userId: string, amountBrl: number, aurAmount: number) {
    await this.wallet.checkDepositLimit(userId, amountBrl);

    if (amountBrl < 5)      throw new BadRequestException('Depósito mínimo: R$ 5,00');
    if (amountBrl > 50000)  throw new BadRequestException('Depósito máximo: R$ 50.000,00');

    const user   = await this.prisma.user.findUniqueOrThrow({ where: { id: userId }, include: { wallet: true } });
    const wallet = user.wallet!;

    // Chamar gateway PIX real
    let pixData: any;
    try {
      const { data } = await axios.post(
        `${this.gatewayUrl}/v1/pix/charge`,
        {
          amount:      amountBrl,
          description: `AureusBet — ${aurAmount} AUR`,
          expiresAt:   new Date(Date.now() + 30 * 60 * 1000).toISOString(),
          metadata:    { userId, aurAmount: aurAmount.toString() },
        },
        {
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
          },
          timeout: 10000,
        },
      );
      pixData = data;
    } catch (err: any) {
      this.logger.error(`PIX gateway error: ${err.message}`);
      throw new BadRequestException('Erro ao gerar QR Code PIX. Tente novamente.');
    }

    // Registrar transação pendente
    const tx = await this.prisma.transaction.create({
      data: {
        userId,
        walletId:      wallet.id,
        type:          'DEPOSIT',
        status:        'PENDING',
        method:        'PIX',
        amount:        aurAmount,
        currency:      'AUR',
        amountBrl,
        balanceBefore: Number(wallet.aurBalance),
        balanceAfter:  Number(wallet.aurBalance),
        externalId:    pixData.id,
        description:   `Depósito PIX ${aurAmount} AUR`,
      },
    });

    return {
      txId:      tx.id,
      externalId: pixData.id,
      qrCode:    pixData.qrCode,
      qrCodeBase64: pixData.qrCodeBase64,
      pixKey:    pixData.pixKey,
      expiresAt: pixData.expiresAt,
      amountBrl,
      aurAmount,
    };
  }

  /** Webhook do gateway PIX */
  async handleWebhook(payload: any, rawBody: Buffer, signature: string) {
    // Verificar assinatura HMAC do webhook
    const expected = createHmac('sha256', this.webhookSecret)
      .update(rawBody)
      .digest('hex');

    if (signature !== `sha256=${expected}`) {
      this.logger.error('PIX webhook signature inválida');
      throw new BadRequestException('Signature inválida.');
    }

    const { type, data } = payload;

    switch (type) {
      case 'pix.payment.confirmed':
        await this.onPixConfirmed(data);
        break;
      case 'pix.payment.expired':
        await this.onPixExpired(data);
        break;
      case 'pix.refund.completed':
        await this.onPixRefunded(data);
        break;
      default:
        this.logger.log(`PIX webhook ignorado: ${type}`);
    }

    return { received: true };
  }

  /** Criar saque via PIX */
  async createWithdrawal(userId: string, amountAur: number, pixKey: string, pixKeyType: string) {
    if (amountAur < 5)      throw new BadRequestException('Saque mínimo: 5 AUR');
    if (amountAur > 100000) throw new BadRequestException('Saque máximo: 100.000 AUR');

    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });

    // KYC obrigatório para saques
    if (user.kycStatus !== 'APPROVED') {
      throw new BadRequestException('KYC obrigatório para realizar saques. Verifique sua identidade.');
    }

    // 2FA obrigatório para saques
    if (!user.twoFaEnabled) {
      throw new BadRequestException('2FA obrigatório para saques. Ative em Configurações > Segurança.');
    }

    // Verificar saldo
    const balance = await this.wallet.getBalance(userId);
    if (balance.aurBalance < amountAur) throw new BadRequestException('Saldo insuficiente.');

    // Criar solicitação de saque para revisão manual (acima de limite)
    const withdrawal = await this.prisma.withdrawalRequest.create({
      data: {
        userId,
        amount:     amountAur,
        method:     'PIX',
        status:     amountAur > 1000 ? 'PENDING' : 'PROCESSING', // Auto ou manual
        pixKey,
        pixKeyType,
      },
    });

    // Bloquear saldo imediatamente
    await this.prisma.wallet.update({
      where: { userId },
      data:  {
        aurBalance:    { decrement: amountAur },
        lockedBalance: { increment: amountAur },
      },
    });

    await this.audit.log({
      userId,
      action:   'WITHDRAWAL',
      metadata: { method: 'PIX', amount: amountAur, pixKeyType },
    });

    if (amountAur <= 1000) {
      // Auto-aprovar saques pequenos após verificação antifraude
      this.emitter.emit('withdrawal.auto_process', { withdrawalId: withdrawal.id });
    }

    return {
      withdrawalId: withdrawal.id,
      status: withdrawal.status,
      message: amountAur > 1000
        ? 'Saque solicitado. Revisão em até 24h.'
        : 'Saque sendo processado. Previsão: 30 minutos.',
    };
  }

  // ── PRIVADOS ──────────────────────────────────────────────────

  private async onPixConfirmed(data: any) {
    const tx = await this.prisma.transaction.findFirst({
      where: { externalId: data.id, status: 'PENDING' },
    });
    if (!tx) return;

    await this.prisma.transaction.update({
      where: { id: tx.id },
      data:  { status: 'COMPLETED', completedAt: new Date() },
    });

    await this.wallet.creditBalance(tx.userId, Number(tx.amount), 'AUR', 'DEPOSIT');
    await this.audit.log({ userId: tx.userId, action: 'DEPOSIT', metadata: { method: 'PIX', amount: Number(tx.amount) } });
    this.emitter.emit('payment.deposit.completed', { userId: tx.userId, amount: Number(tx.amount) });
    this.logger.log(`PIX confirmado: ${tx.amount} AUR → user ${tx.userId}`);
  }

  private async onPixExpired(data: any) {
    await this.prisma.transaction.updateMany({
      where: { externalId: data.id, status: 'PENDING' },
      data:  { status: 'EXPIRED' },
    });
  }

  private async onPixRefunded(data: any) {
    const tx = await this.prisma.transaction.findFirst({
      where: { externalId: data.originalId, status: 'COMPLETED' },
    });
    if (!tx) return;

    await this.wallet.creditBalance(tx.userId, Number(tx.amount), 'AUR', 'REFUND');
    this.logger.log(`PIX reembolsado: ${tx.amount} AUR → user ${tx.userId}`);
  }
}
