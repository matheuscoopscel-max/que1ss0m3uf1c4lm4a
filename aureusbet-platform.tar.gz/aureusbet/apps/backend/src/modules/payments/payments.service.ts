import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../common/services/prisma.service';
import { WalletService } from './wallet.service';

@Injectable()
export class PaymentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly wallet: WalletService,
  ) {}

  async transferByUsername(fromUserId: string, toUsername: string, amount: number, ip: string) {
    const toUser = await this.prisma.user.findUnique({ where: { username: toUsername.toLowerCase() } });
    if (!toUser) throw new NotFoundException('Usuário de destino não encontrado.');
    return this.wallet.transfer(fromUserId, toUser.id, amount, ip);
  }

  async getAurConversionRate() {
    const rate = await this.prisma.aurConversionRate.findFirst({ orderBy: { createdAt: 'desc' } });
    return { rateAurBrl: rate ? Number(rate.rateAurBrl) : 1.0, updatedAt: rate?.createdAt };
  }
}
