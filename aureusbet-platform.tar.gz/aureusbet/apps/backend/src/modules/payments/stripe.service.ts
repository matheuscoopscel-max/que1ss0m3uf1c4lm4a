import { Injectable, Logger, BadRequestException, InternalServerErrorException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';
import { PrismaService } from '../../common/services/prisma.service';
import { WalletService } from './wallet.service';
import { AuditService }  from '../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class StripeService {
  private readonly stripe: Stripe;
  private readonly logger = new Logger(StripeService.name);

  constructor(
    private readonly config:   ConfigService,
    private readonly prisma:   PrismaService,
    private readonly wallet:   WalletService,
    private readonly audit:    AuditService,
    private readonly emitter:  EventEmitter2,
  ) {
    this.stripe = new Stripe(this.config.get<string>('STRIPE_SECRET_KEY')!, {
      apiVersion: '2023-10-16',
      typescript: true,
    });
  }

  /** Criar PaymentIntent para compra de AUR com cartão */
  async createPaymentIntent(userId: string, amountBrl: number, aurAmount: number) {
    await this.wallet.checkDepositLimit(userId, amountBrl);

    const user = await this.prisma.user.findUniqueOrThrow({
      where: { id: userId },
      include: { wallet: true },
    });

    const amountCents = Math.round(amountBrl * 100);
    if (amountCents < 500) throw new BadRequestException('Depósito mínimo: R$ 5,00');

    const pi = await this.stripe.paymentIntents.create({
      amount:   amountCents,
      currency: 'brl',
      metadata: {
        userId,
        aurAmount: aurAmount.toString(),
        amountBrl: amountBrl.toString(),
      },
      description: `Compra de ${aurAmount} AUR — AureusBet`,
      automatic_payment_methods: { enabled: true },
    });

    // Registrar transação pendente
    const wallet = user.wallet!;
    await this.prisma.transaction.create({
      data: {
        userId,
        walletId:      wallet.id,
        type:          'DEPOSIT',
        status:        'PENDING',
        method:        'STRIPE',
        amount:        aurAmount,
        currency:      'AUR',
        amountBrl,
        balanceBefore: Number(wallet.aurBalance),
        balanceAfter:  Number(wallet.aurBalance), // ainda não creditado
        externalId:    pi.id,
        description:   `Compra ${aurAmount} AUR via cartão`,
      },
    });

    return {
      clientSecret: pi.client_secret,
      paymentIntentId: pi.id,
      amountBrl,
      aurAmount,
    };
  }

  /** Webhook Stripe — processar eventos */
  async handleWebhook(payload: Buffer, signature: string) {
    const secret = this.config.get<string>('STRIPE_WEBHOOK_SECRET')!;
    let event: Stripe.Event;

    try {
      event = this.stripe.webhooks.constructEvent(payload, signature, secret);
    } catch (err: any) {
      this.logger.error(`Webhook signature inválida: ${err.message}`);
      throw new BadRequestException('Webhook signature inválida.');
    }

    switch (event.type) {
      case 'payment_intent.succeeded':
        await this.onPaymentSucceeded(event.data.object as Stripe.PaymentIntent);
        break;
      case 'payment_intent.payment_failed':
        await this.onPaymentFailed(event.data.object as Stripe.PaymentIntent);
        break;
      case 'customer.subscription.deleted':
        await this.onSubscriptionCancelled(event.data.object as Stripe.Subscription);
        break;
      case 'invoice.payment_succeeded':
        await this.onInvoicePaid(event.data.object as Stripe.Invoice);
        break;
      default:
        this.logger.log(`Webhook ignorado: ${event.type}`);
    }

    return { received: true };
  }

  /** Criar assinatura VIP */
  async createSubscription(userId: string, priceId: string) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });

    // Criar/recuperar customer Stripe
    let customerId: string;
    const existing = await this.prisma.subscription.findFirst({ where: { userId, status: 'active' } });

    if (!existing) {
      const customer = await this.stripe.customers.create({
        email:    user.email,
        name:     user.displayName ?? user.username,
        metadata: { userId },
      });
      customerId = customer.id;
    } else {
      const sub = await this.stripe.subscriptions.retrieve(existing.stripeSubId!);
      customerId = sub.customer as string;
    }

    const subscription = await this.stripe.subscriptions.create({
      customer:             customerId,
      items:                [{ price: priceId }],
      payment_behavior:     'default_incomplete',
      expand:               ['latest_invoice.payment_intent'],
      metadata:             { userId },
    });

    await this.prisma.subscription.upsert({
      where:  { stripeSubId: subscription.id },
      create: {
        userId,
        stripeSubId:        subscription.id,
        plan:               'VIP_MONTHLY',
        status:             subscription.status,
        currentPeriodStart: new Date(subscription.current_period_start * 1000),
        currentPeriodEnd:   new Date(subscription.current_period_end   * 1000),
      },
      update: { status: subscription.status },
    });

    const invoice = subscription.latest_invoice as Stripe.Invoice;
    const pi      = invoice.payment_intent as Stripe.PaymentIntent;

    return { subscriptionId: subscription.id, clientSecret: pi.client_secret };
  }

  /** Cancelar assinatura VIP */
  async cancelSubscription(userId: string) {
    const sub = await this.prisma.subscription.findFirst({
      where: { userId, status: 'active' },
    });
    if (!sub?.stripeSubId) throw new BadRequestException('Nenhuma assinatura ativa.');

    await this.stripe.subscriptions.update(sub.stripeSubId, { cancel_at_period_end: true });
    await this.prisma.subscription.update({
      where: { id: sub.id },
      data:  { cancelAtPeriodEnd: true, cancelledAt: new Date() },
    });

    return { message: 'Assinatura cancelada ao final do período.' };
  }

  // ── HANDLERS PRIVADOS ─────────────────────────────────────────

  private async onPaymentSucceeded(pi: Stripe.PaymentIntent) {
    const { userId, aurAmount } = pi.metadata;
    if (!userId || !aurAmount) return;

    const tx = await this.prisma.transaction.findFirst({
      where: { externalId: pi.id, status: 'PENDING' },
    });
    if (!tx) return;

    const aur = parseFloat(aurAmount);

    await this.prisma.transaction.update({
      where: { id: tx.id },
      data:  { status: 'COMPLETED', completedAt: new Date() },
    });

    await this.wallet.creditBalance(userId, aur, 'AUR', 'DEPOSIT');

    await this.audit.log({
      userId,
      action:   'DEPOSIT',
      metadata: { method: 'stripe', aurAmount: aur, piId: pi.id },
    });

    this.emitter.emit('payment.deposit.completed', { userId, amount: aur, currency: 'AUR' });
    this.logger.log(`Depósito confirmado: ${aur} AUR para user ${userId}`);
  }

  private async onPaymentFailed(pi: Stripe.PaymentIntent) {
    const { userId } = pi.metadata;
    if (!userId) return;

    await this.prisma.transaction.updateMany({
      where: { externalId: pi.id, status: 'PENDING' },
      data:  { status: 'FAILED' },
    });

    this.emitter.emit('payment.deposit.failed', { userId, piId: pi.id });
    this.logger.warn(`Pagamento falhou: ${pi.id} para user ${userId}`);
  }

  private async onSubscriptionCancelled(sub: Stripe.Subscription) {
    const { userId } = sub.metadata;
    if (!userId) return;

    await this.prisma.subscription.updateMany({
      where: { stripeSubId: sub.id },
      data:  { status: 'cancelled', cancelledAt: new Date() },
    });

    await this.prisma.user.update({
      where: { id: userId },
      data:  { role: 'PLAYER' },
    });
  }

  private async onInvoicePaid(invoice: Stripe.Invoice) {
    const sub = await this.stripe.subscriptions.retrieve(invoice.subscription as string);
    const { userId } = sub.metadata;
    if (!userId) return;

    await this.prisma.subscription.updateMany({
      where: { stripeSubId: sub.id },
      data: {
        status:             'active',
        currentPeriodStart: new Date(sub.current_period_start * 1000),
        currentPeriodEnd:   new Date(sub.current_period_end   * 1000),
      },
    });

    await this.prisma.user.update({
      where: { id: userId },
      data:  { role: 'VIP' },
    });

    this.logger.log(`Assinatura VIP renovada para user ${userId}`);
  }
}
