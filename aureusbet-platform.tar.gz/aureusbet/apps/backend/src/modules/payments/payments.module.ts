import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { PaymentsController } from './payments.controller';
import { PaymentsService }    from './payments.service';
import { WalletService }      from './wallet.service';
import { PixService }         from './pix.service';
import { StripeService }      from './stripe.service';
import { AmlService }         from './aml.service';
import { AuditModule }        from '../audit/audit.module';

@Module({
  imports: [
    BullModule.registerQueue({ name: 'withdrawals' }),
    BullModule.registerQueue({ name: 'deposits' }),
    AuditModule,
  ],
  controllers: [PaymentsController],
  providers:   [PaymentsService, WalletService, PixService, StripeService, AmlService],
  exports:     [WalletService, PaymentsService],
})
export class PaymentsModule {}
