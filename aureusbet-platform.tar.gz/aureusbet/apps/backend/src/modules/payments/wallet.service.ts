import {
  Injectable, Logger, BadRequestException,
  NotFoundException, InternalServerErrorException,
} from '@nestjs/common';
import { PrismaService } from '../../common/services/prisma.service';
import { AuditService }  from '../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Prisma } from '@prisma/client';

@Injectable()
export class WalletService {
  private readonly logger = new Logger(WalletService.name);

  constructor(
    private readonly prisma:   PrismaService,
    private readonly audit:    AuditService,
    private readonly emitter:  EventEmitter2,
  ) {}

  async getWallet(userId: string) {
    const wallet = await this.prisma.wallet.findUnique({
      where:   { userId },
      include: {
        transactions: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
      },
    });
    if (!wallet) throw new NotFoundException('Carteira não encontrada.');
    return wallet;
  }

  async getBalance(userId: string) {
    const wallet = await this.prisma.wallet.findUnique({ where: { userId } });
    if (!wallet) throw new NotFoundException('Carteira não encontrada.');
    return {
      aurBalance:    Number(wallet.aurBalance),
      brlBalance:    Number(wallet.brlBalance),
      lockedBalance: Number(wallet.lockedBalance),
    };
  }

  /** Debitar saldo (para apostas) — atomicamente com lock */
  async debitBalance(userId: string, amount: number, currency: 'AUR' | 'BRL') {
    if (amount <= 0) throw new BadRequestException('Valor inválido.');

    return await this.prisma.$transaction(async (tx) => {
      // SELECT FOR UPDATE para evitar race conditions
      const wallet = await tx.wallet.findUnique({ where: { userId } });
      if (!wallet) throw new NotFoundException('Carteira não encontrada.');

      const field       = currency === 'AUR' ? 'aurBalance' : 'brlBalance';
      const current     = Number(wallet[field]);
      if (current < amount) throw new BadRequestException('Saldo insuficiente.');

      const after = current - amount;

      const updated = await tx.wallet.update({
        where: { userId },
        data: {
          [field]:       after,
          lockedBalance: { increment: amount },
        },
      });

      await tx.transaction.create({
        data: {
          userId,
          walletId:      wallet.id,
          type:          'BET',
          status:        'COMPLETED',
          amount,
          currency,
          balanceBefore: current,
          balanceAfter:  after,
          completedAt:   new Date(),
        },
      });

      this.emitter.emit('wallet.debited', { userId, amount, currency, balance: after });
      return updated;
    });
  }

  /** Creditar saldo (para ganhos, depósitos, bônus) */
  async creditBalance(userId: string, amount: number, currency: 'AUR' | 'BRL', type: 'WIN' | 'DEPOSIT' | 'BONUS' | 'REFUND' = 'WIN') {
    if (amount <= 0) throw new BadRequestException('Valor inválido.');

    return await this.prisma.$transaction(async (tx) => {
      const wallet = await tx.wallet.findUnique({ where: { userId } });
      if (!wallet) throw new NotFoundException('Carteira não encontrada.');

      const field   = currency === 'AUR' ? 'aurBalance' : 'brlBalance';
      const current = Number(wallet[field]);
      const after   = current + amount;

      const typeMap: Record<string, any> = {
        WIN:     { type: 'WIN',     totalWon:       { increment: amount } },
        DEPOSIT: { type: 'DEPOSIT', totalDeposited: { increment: amount } },
        BONUS:   { type: 'BONUS',   totalDeposited: { increment: amount } },
        REFUND:  { type: 'REFUND' },
      };

      const updated = await tx.wallet.update({
        where: { userId },
        data: {
          [field]:       after,
          lockedBalance: type === 'WIN' ? { decrement: 0 } : undefined,
          ...typeMap[type],
        },
      });

      await tx.transaction.create({
        data: {
          userId,
          walletId:      wallet.id,
          type:          typeMap[type].type,
          status:        'COMPLETED',
          amount,
          currency,
          balanceBefore: current,
          balanceAfter:  after,
          completedAt:   new Date(),
        },
      });

      this.emitter.emit('wallet.credited', { userId, amount, currency, balance: after });
      return updated;
    });
  }

  /** Transferência entre usuários */
  async transfer(fromUserId: string, toUserId: string, amount: number, ip: string) {
    if (amount <= 0 || amount > 10000) throw new BadRequestException('Valor de transferência inválido.');

    const [from, to] = await Promise.all([
      this.prisma.user.findUnique({ where: { id: fromUserId } }),
      this.prisma.user.findUnique({ where: { id: toUserId } }),
    ]);
    if (!from || !to) throw new NotFoundException('Usuário não encontrado.');

    return await this.prisma.$transaction(async (tx) => {
      const fromWallet = await tx.wallet.findUniqueOrThrow({ where: { userId: fromUserId } });
      const toWallet   = await tx.wallet.findUniqueOrThrow({ where: { userId: toUserId } });

      if (Number(fromWallet.aurBalance) < amount) throw new BadRequestException('Saldo insuficiente.');

      const fromBefore = Number(fromWallet.aurBalance);
      const fromAfter  = fromBefore - amount;
      const toBefore   = Number(toWallet.aurBalance);
      const toAfter    = toBefore + amount;

      await tx.wallet.update({ where: { userId: fromUserId }, data: { aurBalance: fromAfter } });
      await tx.wallet.update({ where: { userId: toUserId   }, data: { aurBalance: toAfter  } });

      await tx.transaction.createMany({
        data: [
          {
            userId: fromUserId, walletId: fromWallet.id, type: 'TRANSFER_SENT',
            status: 'COMPLETED', amount, currency: 'AUR',
            balanceBefore: fromBefore, balanceAfter: fromAfter,
            description: `Transferência para ${to.username}`, completedAt: new Date(),
          },
          {
            userId: toUserId, walletId: toWallet.id, type: 'TRANSFER_RECEIVED',
            status: 'COMPLETED', amount, currency: 'AUR',
            balanceBefore: toBefore, balanceAfter: toAfter,
            description: `Transferência de ${from.username}`, completedAt: new Date(),
          },
        ],
      });

      await this.audit.log({
        userId: fromUserId, action: 'DEPOSIT',
        metadata: { type: 'transfer', to: toUserId, amount, ip }, ipAddress: ip,
      });

      return { success: true, amount, from: from.username, to: to.username };
    });
  }

  /** Histórico de transações paginado */
  async getTransactionHistory(userId: string, page = 1, perPage = 20, type?: string) {
    return this.prisma.paginate(
      this.prisma.transaction,
      {
        where:   { userId, ...(type ? { type: type as any } : {}) },
        orderBy: { createdAt: 'desc' },
      },
      page,
      perPage,
    );
  }

  /** Verificar limites de depósito (responsible gambling) */
  async checkDepositLimit(userId: string, amount: number): Promise<void> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) return;

    const now     = new Date();
    const day1    = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const week1   = new Date(now.getTime() - 7 * 86400000);
    const month1  = new Date(now.getFullYear(), now.getMonth(), 1);

    const [daily, weekly, monthly] = await Promise.all([
      this.prisma.transaction.aggregate({
        where: { userId, type: 'DEPOSIT', status: 'COMPLETED', createdAt: { gte: day1 } },
        _sum:  { amountBrl: true },
      }),
      this.prisma.transaction.aggregate({
        where: { userId, type: 'DEPOSIT', status: 'COMPLETED', createdAt: { gte: week1 } },
        _sum:  { amountBrl: true },
      }),
      this.prisma.transaction.aggregate({
        where: { userId, type: 'DEPOSIT', status: 'COMPLETED', createdAt: { gte: month1 } },
        _sum:  { amountBrl: true },
      }),
    ]);

    const dailySum   = Number(daily._sum.amountBrl ?? 0) + amount;
    const weeklySum  = Number(weekly._sum.amountBrl ?? 0) + amount;
    const monthlySum = Number(monthly._sum.amountBrl ?? 0) + amount;

    const dailyLimit   = Number(user.dailyDepositLimit   ?? 1000);
    const weeklyLimit  = Number(user.weeklyDepositLimit  ?? 5000);
    const monthlyLimit = Number(user.monthlyDepositLimit ?? 15000);

    if (dailySum   > dailyLimit)   throw new BadRequestException(`Limite diário de depósito atingido (R$ ${dailyLimit}).`);
    if (weeklySum  > weeklyLimit)  throw new BadRequestException(`Limite semanal de depósito atingido (R$ ${weeklyLimit}).`);
    if (monthlySum > monthlyLimit) throw new BadRequestException(`Limite mensal de depósito atingido (R$ ${monthlyLimit}).`);
  }
}
