import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';

@Injectable()
export class NotificationsService {
  private readonly logger     = new Logger(NotificationsService.name);
  private readonly transporter: nodemailer.Transporter;
  private readonly fromEmail:  string;
  private readonly fromName:   string;
  private readonly appUrl:     string;

  constructor(private readonly config: ConfigService) {
    this.transporter = nodemailer.createTransport({
      host:   this.config.get<string>('SMTP_HOST'),
      port:   this.config.get<number>('SMTP_PORT', 587),
      secure: this.config.get<boolean>('SMTP_SECURE', false),
      auth:   { user: this.config.get<string>('SMTP_USER'), pass: this.config.get<string>('SMTP_PASS') },
    });

    this.fromEmail = this.config.get<string>('SMTP_FROM', 'noreply@aureusbet.com');
    this.fromName  = this.config.get<string>('SMTP_FROM_NAME', 'AureusBet');
    this.appUrl    = this.config.get<string>('FRONTEND_URL', 'https://app.aureusbet.com');
  }

  async sendEmailVerification(email: string, name: string, token: string): Promise<void> {
    const link = `${this.appUrl}/auth/verify-email?token=${token}`;
    await this.send(email, '✅ Verifique seu e-mail — AureusBet', this.verificationTemplate(name, link));
  }

  async sendPasswordReset(email: string, name: string, token: string): Promise<void> {
    const link = `${this.appUrl}/auth/reset-password?token=${token}`;
    await this.send(email, '🔒 Redefinir senha — AureusBet', this.passwordResetTemplate(name, link));
  }

  async sendWithdrawalConfirmation(email: string, name: string, amount: number, txHash?: string): Promise<void> {
    await this.send(email, '💸 Saque confirmado — AureusBet', this.withdrawalTemplate(name, amount, txHash));
  }

  async sendCollectibleEarned(email: string, name: string, collectibleName: string): Promise<void> {
    await this.send(email, `🏆 Você ganhou um colecionável — ${collectibleName}`, this.collectibleTemplate(name, collectibleName));
  }

  private async send(to: string, subject: string, html: string): Promise<void> {
    try {
      await this.transporter.sendMail({ from: `"${this.fromName}" <${this.fromEmail}>`, to, subject, html });
    } catch (e: any) {
      this.logger.error(`Email send error to ${to}: ${e.message}`);
      throw e;
    }
  }

  private verificationTemplate(name: string, link: string) {
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;background:#0a0a0a;color:#fff;padding:40px">
      <div style="max-width:500px;margin:0 auto;background:#111;border:1px solid #f59e0b;border-radius:12px;padding:40px">
        <h1 style="color:#f59e0b">🎰 AureusBet</h1>
        <h2>Olá, ${name}!</h2>
        <p>Clique no botão abaixo para verificar seu e-mail e ganhar seus <strong style="color:#f59e0b">25 AUR de boas-vindas</strong>.</p>
        <a href="${link}" style="display:inline-block;background:#f59e0b;color:#000;padding:14px 28px;border-radius:8px;text-decoration:none;font-weight:bold;margin:20px 0">Verificar E-mail</a>
        <p style="color:#666;font-size:12px">Link expira em 24 horas. Se não foi você, ignore este e-mail.</p>
      </div></body></html>`;
  }

  private passwordResetTemplate(name: string, link: string) {
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;background:#0a0a0a;color:#fff;padding:40px">
      <div style="max-width:500px;margin:0 auto;background:#111;border:1px solid #f59e0b;border-radius:12px;padding:40px">
        <h1 style="color:#f59e0b">🎰 AureusBet</h1>
        <h2>Redefinir senha</h2>
        <p>Olá ${name}, recebemos uma solicitação para redefinir sua senha.</p>
        <a href="${link}" style="display:inline-block;background:#ef4444;color:#fff;padding:14px 28px;border-radius:8px;text-decoration:none;font-weight:bold;margin:20px 0">Redefinir Senha</a>
        <p style="color:#666;font-size:12px">Link expira em 1 hora. Se não foi você, sua senha continua segura.</p>
      </div></body></html>`;
  }

  private withdrawalTemplate(name: string, amount: number, txHash?: string) {
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;background:#0a0a0a;color:#fff;padding:40px">
      <div style="max-width:500px;margin:0 auto;background:#111;border:1px solid #f59e0b;border-radius:12px;padding:40px">
        <h1 style="color:#f59e0b">🎰 AureusBet</h1>
        <h2 style="color:#22c55e">✅ Saque Confirmado</h2>
        <p>Olá ${name}, seu saque de <strong style="color:#f59e0b">${amount} AUR</strong> foi processado.</p>
        ${txHash ? `<p>TX Hash: <code style="color:#94a3b8;font-size:11px">${txHash}</code></p>` : ''}
      </div></body></html>`;
  }

  private collectibleTemplate(name: string, collectibleName: string) {
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;background:#0a0a0a;color:#fff;padding:40px">
      <div style="max-width:500px;margin:0 auto;background:#111;border:1px solid #f59e0b;border-radius:12px;padding:40px">
        <h1 style="color:#f59e0b">🎰 AureusBet</h1>
        <h2 style="color:#f59e0b">🏆 Colecionável Ganho!</h2>
        <p>Parabéns ${name}! Você ganhou o colecionável <strong style="color:#f59e0b">${collectibleName}</strong>.</p>
        <p>Acesse seu inventário para visualizá-lo.</p>
      </div></body></html>`;
  }
}
