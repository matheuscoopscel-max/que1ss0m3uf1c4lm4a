import { Controller, Get, Patch, Post, Body, Param, UseGuards, UploadedFile, UploadedFiles, UseInterceptors } from '@nestjs/common';
import { FileInterceptor, FileFieldsInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser }  from '../../common/decorators/current-user.decorator';

@ApiTags('Users')
@Controller('users')
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get('me')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  getMe(@CurrentUser('id') uid: string) { return this.users.getProfile(uid); }

  @Patch('me')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  updateMe(@CurrentUser('id') uid: string, @Body() body: any) {
    return this.users.updateProfile(uid, body);
  }

  @Post('me/avatar')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @UseInterceptors(FileInterceptor('avatar'))
  uploadAvatar(@CurrentUser('id') uid: string, @UploadedFile() file: Express.Multer.File) {
    return this.users.uploadAvatar(uid, file);
  }

  @Post('me/banner')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @UseInterceptors(FileInterceptor('banner'))
  uploadBanner(@CurrentUser('id') uid: string, @UploadedFile() file: Express.Multer.File) {
    return this.users.uploadProfileBanner(uid, file);
  }

  @Post('me/kyc')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'CPF',           maxCount: 1 },
    { name: 'RG',            maxCount: 1 },
    { name: 'SELFIE',        maxCount: 1 },
    { name: 'ADDRESS_PROOF', maxCount: 1 },
  ]))
  submitKyc(@CurrentUser('id') uid: string, @UploadedFiles() files: any) {
    return this.users.submitKyc(uid, files);
  }

  @Patch('me/deposit-limits')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  setDepositLimits(
    @CurrentUser('id') uid: string,
    @Body('daily') daily?: number,
    @Body('weekly') weekly?: number,
    @Body('monthly') monthly?: number,
  ) {
    return this.users.setDepositLimits(uid, daily, weekly, monthly);
  }

  @Post('me/self-exclude')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  selfExclude(
    @CurrentUser('id') uid: string,
    @Body('days') days: number | null,
    @Body('reason') reason?: string,
  ) {
    return this.users.selfExclude(uid, days, reason);
  }

  @Get(':username')
  getPublicProfile(@Param('username') username: string) {
    return this.users.getPublicProfile(username);
  }
}
