import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService }  from '../../common/services/prisma.service';
import { StorageService } from '../storage/storage.service';
import { AuditService }   from '../audit/audit.service';

@Injectable()
export class UsersService {
  constructor(
    private readonly prisma:   PrismaService,
    private readonly storage:  StorageService,
    private readonly audit:    AuditService,
  ) {}

  async getProfile(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true, username: true, email: true, displayName: true,
        avatarUrl: true, profileBannerUrl: true, bio: true, country: true,
        role: true, status: true, kycStatus: true, twoFaEnabled: true,
        emailVerified: true, cpfVerified: true, createdAt: true, lastLoginAt: true,
        dailyDepositLimit: true, weeklyDepositLimit: true, monthlyDepositLimit: true,
        sessionLimitHours: true, isSelfExcluded: true, selfExcludedUntil: true,
        marketingConsent: true,
        wallet: { select: { aurBalance: true, brlBalance: true, polygonAddress: true } },
        collectibles: {
          take: 10,
          include: { collectible: { select: { name: true, imageUrl: true, rarity: true } } },
        },
        _count: { select: { bets: true, collectibles: true } },
      },
    });
    if (!user) throw new NotFoundException('Usuário não encontrado.');
    return user;
  }

  async updateProfile(userId: string, data: { displayName?: string; bio?: string; country?: string }) {
    const { displayName, bio, country } = data;

    if (displayName && (displayName.length < 2 || displayName.length > 50)) {
      throw new BadRequestException('Nome de exibição deve ter entre 2 e 50 caracteres.');
    }

    const updated = await this.prisma.user.update({
      where: { id: userId },
      data: {
        ...(displayName !== undefined ? { displayName } : {}),
        ...(bio         !== undefined ? { bio }         : {}),
        ...(country     !== undefined ? { country }     : {}),
      },
      select: { id: true, displayName: true, bio: true, country: true },
    });

    await this.audit.log({ userId, action: 'PROFILE_UPDATED', after: data });
    return updated;
  }

  async uploadAvatar(userId: string, file: Express.Multer.File) {
    const url = await this.storage.uploadPublic(file, `avatars/${userId}`);
    await this.prisma.user.update({ where: { id: userId }, data: { avatarUrl: url } });
    return { avatarUrl: url };
  }

  async uploadProfileBanner(userId: string, file: Express.Multer.File) {
    const url = await this.storage.uploadPublic(file, `banners/profiles/${userId}`);
    await this.prisma.user.update({ where: { id: userId }, data: { profileBannerUrl: url } });
    return { profileBannerUrl: url };
  }

  async submitKyc(userId: string, files: { [field: string]: Express.Multer.File[] }) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (user.kycStatus === 'APPROVED') throw new BadRequestException('KYC já aprovado.');

    const docs: any[] = [];
    for (const [docType, fileArr] of Object.entries(files)) {
      for (const file of fileArr) {
        const { key, bucket } = await this.storage.uploadKyc(file, userId, docType);
        docs.push({ userId, type: docType as any, s3Key: key, s3Bucket: bucket, originalName: file.originalname, mimeType: file.mimetype, fileSize: file.size });
      }
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.kycDocument.createMany({ data: docs });
      await tx.user.update({ where: { id: userId }, data: { kycStatus: 'PENDING', status: 'PENDING_KYC' } });
    });

    await this.audit.log({ userId, action: 'KYC_SUBMITTED' });
    return { message: 'Documentos enviados para revisão. Prazo: 1-3 dias úteis.' };
  }

  async setDepositLimits(userId: string, daily?: number, weekly?: number, monthly?: number) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });

    // Limites só podem ser reduzidos imediatamente; aumentos têm 24h de espera
    const updates: any = {};
    const logs: any[]  = [];

    if (daily !== undefined) {
      const currentDaily = Number(user.dailyDepositLimit ?? 1000);
      updates.dailyDepositLimit = daily;
      logs.push({ userId, limitType: 'daily', previousLimit: currentDaily, newLimit: daily, effectiveAt: daily < currentDaily ? new Date() : new Date(Date.now() + 86400000) });
    }
    if (weekly !== undefined) {
      updates.weeklyDepositLimit = weekly;
      logs.push({ userId, limitType: 'weekly', previousLimit: Number(user.weeklyDepositLimit ?? 5000), newLimit: weekly, effectiveAt: new Date() });
    }
    if (monthly !== undefined) {
      updates.monthlyDepositLimit = monthly;
      logs.push({ userId, limitType: 'monthly', previousLimit: Number(user.monthlyDepositLimit ?? 15000), newLimit: monthly, effectiveAt: new Date() });
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: userId }, data: updates });
      if (logs.length) await tx.depositLimitLog.createMany({ data: logs });
    });

    await this.audit.log({ userId, action: 'LIMIT_SET', metadata: { daily, weekly, monthly } });
    return { success: true };
  }

  async selfExclude(userId: string, days: number | null, reason?: string) {
    const until = days ? new Date(Date.now() + days * 86400000) : null;
    await this.prisma.user.update({
      where: { id: userId },
      data: { isSelfExcluded: true, selfExcludedUntil: until, selfExclusionReason: reason, status: 'SELF_EXCLUDED' },
    });
    await this.prisma.refreshToken.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } });
    await this.audit.log({ userId, action: 'SELF_EXCLUSION', metadata: { days, reason } });
    return { message: `Auto-exclusão ativada${days ? ` por ${days} dias` : ' permanentemente'}.` };
  }

  async getPublicProfile(username: string) {
    const user = await this.prisma.user.findUnique({
      where: { username: username.toLowerCase() },
      select: {
        username: true, displayName: true, avatarUrl: true, profileBannerUrl: true,
        bio: true, role: true, createdAt: true,
        collectibles: {
          include: { collectible: { select: { name: true, imageUrl: true, rarity: true } } },
        },
        _count: { select: { bets: true } },
      },
    });
    if (!user) throw new NotFoundException('Usuário não encontrado.');
    return user;
  }
}
