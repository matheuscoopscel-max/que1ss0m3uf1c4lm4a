import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../common/services/prisma.service';
import { AuditAction } from '@prisma/client';

interface AuditLogInput {
  userId?:    string;
  adminId?:   string;
  action:     AuditAction;
  entity?:    string;
  entityId?:  string;
  before?:    any;
  after?:     any;
  metadata?:  any;
  ipAddress?: string;
  userAgent?: string;
}

@Injectable()
export class AuditService {
  private readonly logger = new Logger(AuditService.name);

  constructor(private readonly prisma: PrismaService) {}

  async log(input: AuditLogInput): Promise<void> {
    try {
      await this.prisma.auditLog.create({ data: input });
    } catch (e: any) {
      this.logger.error(`Audit log failed: ${e.message}`);
    }
  }

  async getForUser(userId: string, page = 1, perPage = 50) {
    return this.prisma.paginate(
      this.prisma.auditLog,
      { where: { userId }, orderBy: { createdAt: 'desc' } },
      page, perPage,
    );
  }

  async getAll(filters: { action?: AuditAction; userId?: string; from?: Date; to?: Date; page?: number; perPage?: number }) {
    const { action, userId, from, to, page = 1, perPage = 50 } = filters;
    return this.prisma.paginate(
      this.prisma.auditLog,
      {
        where: {
          ...(action    ? { action }    : {}),
          ...(userId    ? { userId }    : {}),
          ...(from || to ? { createdAt: { ...(from ? { gte: from } : {}), ...(to ? { lte: to } : {}) } } : {}),
        },
        orderBy: { createdAt: 'desc' },
      },
      page, perPage,
    );
  }
}
