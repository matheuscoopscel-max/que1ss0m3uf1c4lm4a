import { Injectable, Logger, NotFoundException, BadRequestException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../../common/services/prisma.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { AuditService }  from '../audit/audit.service';

@Injectable()
export class CollectiblesService {
  private readonly logger = new Logger(CollectiblesService.name);

  constructor(
    private readonly prisma:  PrismaService,
    private readonly emitter: EventEmitter2,
    private readonly audit:   AuditService,
  ) {}

  /** Tentar dropar colecionável após aposta */
  async tryDrop(userId: string, betId: string, gameId: string): Promise<string | null> {
    const game = await this.prisma.game.findUnique({ where: { id: gameId } });
    if (!game) return null;

    const dropRate = Number(game.collectibleDropRate);
    const roll     = Math.random();
    if (roll > dropRate) return null;

    // Buscar colecionável elegível (não possui ainda, disponível, com peso)
    const owned = await this.prisma.userCollectible.findMany({
      where:  { userId },
      select: { collectibleId: true },
    });
    const ownedIds = owned.map(o => o.collectibleId);

    const collectibles = await this.prisma.collectible.findMany({
      where: {
        isActive:      true,
        id:            { notIn: ownedIds },
        currentSupply: { lt: this.prisma.collectible.fields.maxSupply as any },
      },
    });

    if (!collectibles.length) return null;

    // Seleção ponderada pelo dropWeight
    const total  = collectibles.reduce((s, c) => s + Number(c.dropWeight), 0);
    let rand     = Math.random() * total;
    let selected = collectibles[0];

    for (const c of collectibles) {
      rand -= Number(c.dropWeight);
      if (rand <= 0) { selected = c; break; }
    }

    // Conceder colecionável
    await this.prisma.$transaction(async (tx) => {
      await tx.collectible.update({
        where: { id: selected.id },
        data:  { currentSupply: { increment: 1 } },
      });

      await tx.userCollectible.create({
        data: {
          userId,
          collectibleId:  selected.id,
          acquiredFromId: betId,
          acquireMethod:  'game_drop',
        },
      });

      await tx.bet.update({
        where: { id: betId },
        data:  { collectibleEarned: selected.id },
      });
    });

    await this.audit.log({
      userId,
      action:   'COLLECTIBLE_EARNED',
      entityId: selected.id,
      metadata: { betId, gameId, collectibleName: selected.name },
    });

    this.emitter.emit('collectible.earned', { userId, collectible: selected });
    this.logger.log(`Colecionável '${selected.name}' dropou para user ${userId}`);

    return selected.id;
  }

  /** Inventário do usuário */
  async getUserInventory(userId: string, page = 1, perPage = 20) {
    return this.prisma.paginate(
      this.prisma.userCollectible,
      {
        where:   { userId },
        include: { collectible: true },
        orderBy: { acquiredAt: 'desc' },
      },
      page,
      perPage,
    );
  }

  /** Transferir colecionável para outro usuário */
  async transfer(fromUserId: string, toUsername: string, collectibleId: string) {
    const ownership = await this.prisma.userCollectible.findUnique({
      where:   { userId_collectibleId: { userId: fromUserId, collectibleId } },
      include: { collectible: true },
    });

    if (!ownership) throw new NotFoundException('Você não possui este colecionável.');
    if (ownership.isListed) throw new BadRequestException('Colecionável listado no mercado. Cancele a listagem primeiro.');
    if (!ownership.collectible.isTransferable) throw new ForbiddenException('Este colecionável não é transferível.');

    const toUser = await this.prisma.user.findUnique({ where: { username: toUsername.toLowerCase() } });
    if (!toUser) throw new NotFoundException('Usuário destino não encontrado.');
    if (toUser.id === fromUserId) throw new BadRequestException('Não pode transferir para si mesmo.');

    const alreadyOwns = await this.prisma.userCollectible.findUnique({
      where: { userId_collectibleId: { userId: toUser.id, collectibleId } },
    });
    if (alreadyOwns) throw new BadRequestException('O usuário destino já possui este colecionável.');

    await this.prisma.$transaction(async (tx) => {
      await tx.userCollectible.delete({ where: { userId_collectibleId: { userId: fromUserId, collectibleId } } });
      await tx.userCollectible.create({
        data: {
          userId:         toUser.id,
          collectibleId,
          acquiredFromId: fromUserId,
          acquireMethod:  'transfer',
          transferredAt:  new Date(),
        },
      });
    });

    await this.audit.log({
      userId:   fromUserId,
      action:   'COLLECTIBLE_TRANSFERRED',
      entityId: collectibleId,
      metadata: { to: toUser.username, toUserId: toUser.id },
    });

    return { success: true, transferredTo: toUser.username };
  }

  /** Listar todos os colecionáveis disponíveis */
  async findAll(rarity?: string) {
    return this.prisma.collectible.findMany({
      where: { isActive: true, ...(rarity ? { rarity: rarity as any } : {}) },
      orderBy: [{ rarity: 'desc' }, { name: 'asc' }],
    });
  }

  /** Detalhes de um colecionável incluindo dono atual */
  async findOne(slug: string) {
    const c = await this.prisma.collectible.findUnique({
      where: { slug },
      include: {
        owners: {
          include: { user: { select: { username: true, avatarUrl: true } } },
          take: 1,
        },
        marketOrders: {
          where:   { status: 'OPEN' },
          orderBy: { priceAur: 'asc' },
          take:    1,
        },
      },
    });
    if (!c) throw new NotFoundException('Colecionável não encontrado.');
    return c;
  }
}
