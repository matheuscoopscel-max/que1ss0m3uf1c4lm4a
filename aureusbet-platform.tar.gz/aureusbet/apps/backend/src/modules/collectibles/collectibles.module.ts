import { Module } from '@nestjs/common';
import { CollectiblesController } from './collectibles.controller';
import { CollectiblesService }    from './collectibles.service';
import { StorageModule }          from '../storage/storage.module';

@Module({
  imports:     [StorageModule],
  controllers: [CollectiblesController],
  providers:   [CollectiblesService],
  exports:     [CollectiblesService],
})
export class CollectiblesModule {}
