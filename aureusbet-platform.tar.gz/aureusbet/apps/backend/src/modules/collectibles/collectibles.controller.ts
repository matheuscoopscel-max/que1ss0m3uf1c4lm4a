import { Controller, Get, Post, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { CollectiblesService } from './collectibles.service';
import { JwtAuthGuard }        from '../auth/guards/jwt-auth.guard';
import { CurrentUser }         from '../../common/decorators/current-user.decorator';

@ApiTags('Collectibles')
@Controller('collectibles')
export class CollectiblesController {
  constructor(private readonly service: CollectiblesService) {}

  @Get()
  findAll(@Query('rarity') rarity?: string) {
    return this.service.findAll(rarity);
  }

  @Get('inventory')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  getInventory(
    @CurrentUser('id') uid: string,
    @Query('page') page = 1, @Query('perPage') perPage = 20,
  ) {
    return this.service.getUserInventory(uid, page, perPage);
  }

  @Get(':slug')
  findOne(@Param('slug') slug: string) {
    return this.service.findOne(slug);
  }

  @Post('transfer')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  transfer(
    @CurrentUser('id') uid: string,
    @Body('collectibleId') collectibleId: string,
    @Body('toUsername')    toUsername: string,
  ) {
    return this.service.transfer(uid, toUsername, collectibleId);
  }
}
