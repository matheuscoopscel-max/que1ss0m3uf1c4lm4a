import { Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRedis } from '@nestjs-modules/ioredis';
import Redis from 'ioredis';
import { randomBytes, createHash } from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { PrismaService } from '../../common/services/prisma.service';

const TEMP_TTL = 300; // 5 min

@Injectable()
export class TokenService {
  private readonly logger = new Logger(TokenService.name);

  constructor(
    private readonly jwtService: JwtService,
    private readonly prisma:     PrismaService,
    private readonly config:     ConfigService,
    @InjectRedis() private readonly redis: Redis,
  ) {}

  async generateTokenPair(
    user: { id: string; email: string; role: string; status: string },
    ip: string,
    ua: string,
  ) {
    const jti    = uuidv4();
    const family = uuidv4();

    const payload = { sub: user.id, email: user.email, role: user.role, status: user.status, jti };

    const [accessToken, rawRefresh] = await Promise.all([
      this.jwtService.signAsync(payload, {
        secret:     this.config.get<string>('JWT_SECRET'),
        expiresIn:  this.config.get<string>('JWT_EXPIRES_IN', '15m'),
      }),
      Promise.resolve(randomBytes(64).toString('hex')),
    ]);

    const refreshExpiry = this.config.get<string>('JWT_REFRESH_EXPIRES_IN', '7d');
    const expiresAt = this.parseExpiry(refreshExpiry);
    const tokenHash = createHash('sha256').update(rawRefresh).digest('hex');

    await this.prisma.refreshToken.create({
      data: { userId: user.id, tokenHash, family, expiresAt, ipAddress: ip, userAgent: ua },
    });

    return { accessToken, refreshToken: rawRefresh, expiresIn: 900, tokenType: 'Bearer' as const };
  }

  async refreshTokens(rawToken: string, ip: string, ua: string) {
    const hash = createHash('sha256').update(rawToken).digest('hex');
    const stored = await this.prisma.refreshToken.findUnique({
      where: { tokenHash: hash },
      include: { user: true },
    });

    if (!stored) throw new UnauthorizedException('Refresh token inválido.');

    if (stored.revokedAt) {
      // Reutilização detectada — revogar família inteira
      this.logger.warn(`Token reuse! Family: ${stored.family} User: ${stored.userId}`);
      await this.prisma.refreshToken.updateMany({
        where: { family: stored.family, revokedAt: null },
        data:  { revokedAt: new Date() },
      });
      throw new UnauthorizedException('Reutilização de token detectada. Faça login novamente.');
    }

    if (stored.expiresAt < new Date()) throw new UnauthorizedException('Refresh token expirado.');

    await this.prisma.refreshToken.update({ where: { id: stored.id }, data: { revokedAt: new Date() } });

    const { user } = stored;
    if (user.isBanned || user.status === 'BANNED') throw new UnauthorizedException('Conta suspensa.');

    return this.generateTokenPair(user, ip, ua);
  }

  async revokeRefreshToken(rawToken: string) {
    const hash = createHash('sha256').update(rawToken).digest('hex');
    await this.prisma.refreshToken
      .updateMany({ where: { tokenHash: hash, revokedAt: null }, data: { revokedAt: new Date() } })
      .catch(() => {});
  }

  async revokeAllUserTokens(userId: string) {
    await this.prisma.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data:  { revokedAt: new Date() },
    });
  }

  async createTempToken(userId: string): Promise<string> {
    const token = randomBytes(32).toString('hex');
    await this.redis.setex(`temp:${token}`, TEMP_TTL, userId);
    return token;
  }

  async verifyTempToken(token: string): Promise<string | null> {
    const userId = await this.redis.get(`temp:${token}`);
    if (userId) await this.redis.del(`temp:${token}`);
    return userId;
  }

  async validatePayload(payload: any) {
    return this.prisma.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, email: true, role: true, status: true, isBanned: true, twoFaEnabled: true },
    });
  }

  private parseExpiry(expr: string): Date {
    const m = expr.match(/^(\d+)([smhd])$/);
    if (!m) return new Date(Date.now() + 7 * 86400000);
    const mul: Record<string, number> = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
    return new Date(Date.now() + parseInt(m[1]) * mul[m[2]]);
  }
}
