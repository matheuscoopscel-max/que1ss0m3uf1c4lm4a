import {
  Controller, Post, Get, Patch, Body, Req, Res, Query,
  UseGuards, HttpCode, HttpStatus, Headers,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { Throttle, SkipThrottle } from '@nestjs/throttler';
import { AuthService }      from './auth.service';
import { TwoFactorService } from './two-factor.service';
import { JwtAuthGuard }     from './guards/jwt-auth.guard';
import { CurrentUser }      from '../../common/decorators/current-user.decorator';
import { GetIpAddress }     from '../../common/decorators/get-ip.decorator';

const COOKIE  = 'refresh_token';
const COPTS   = {
  httpOnly: true,
  secure:   process.env.NODE_ENV === 'production',
  sameSite: 'strict' as const,
  path:     '/api/v1/auth',
  maxAge:   7 * 24 * 60 * 60 * 1000,
};

@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(
    private readonly auth:  AuthService,
    private readonly twoFa: TwoFactorService,
  ) {}

  @Post('register')
  @Throttle({ default: { limit: 3, ttl: 60000 } })
  @ApiOperation({ summary: 'Cadastrar nova conta' })
  register(@Body() body: any, @GetIpAddress() ip: string, @Headers('user-agent') ua: string) {
    return this.auth.register(body, ip, ua);
  }

  @Post('login')
  @HttpCode(HttpStatus.OK)
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  @ApiOperation({ summary: 'Login com e-mail e senha' })
  async login(
    @Body() body: any, @GetIpAddress() ip: string, @Headers('user-agent') ua: string,
    @Res({ passthrough: true }) res: Response,
  ) {
    const result = await this.auth.login(body, ip, ua);
    if ('requiresTwoFa' in result) return result;
    res.cookie(COOKIE, (result as any).refreshToken, COPTS);
    const { refreshToken: _, ...safe } = result as any;
    return safe;
  }

  @Post('2fa/verify')
  @HttpCode(HttpStatus.OK)
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  async verifyTwoFa(
    @Body('code') code: string, @Headers('x-temp-token') tempToken: string,
    @GetIpAddress() ip: string, @Headers('user-agent') ua: string,
    @Res({ passthrough: true }) res: Response,
  ) {
    const result = await this.auth.verifyTwoFa(code, tempToken, ip, ua);
    res.cookie(COOKIE, result.refreshToken, COPTS);
    const { refreshToken: _, ...safe } = result;
    return safe;
  }

  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  @SkipThrottle()
  async refresh(
    @Req() req: Request, @GetIpAddress() ip: string, @Headers('user-agent') ua: string,
    @Res({ passthrough: true }) res: Response,
  ) {
    const token = req.cookies[COOKIE];
    if (!token) throw new Error('Sem refresh token.');
    const result = await this.auth.refreshTokens(token, ip, ua);
    res.cookie(COOKIE, result.refreshToken, COPTS);
    const { refreshToken: _, ...safe } = result;
    return safe;
  }

  @Post('logout')
  @HttpCode(HttpStatus.NO_CONTENT)
  @UseGuards(JwtAuthGuard)
  async logout(
    @CurrentUser('id') userId: string, @Req() req: Request,
    @GetIpAddress() ip: string, @Headers('user-agent') ua: string,
    @Res({ passthrough: true }) res: Response,
  ) {
    const token = req.cookies[COOKIE];
    if (token) await this.auth.logout(userId, token, ip, ua);
    res.clearCookie(COOKIE, { path: '/api/v1/auth' });
  }

  @Get('verify-email')
  verifyEmail(@Query('token') token: string) {
    return this.auth.verifyEmail(token);
  }

  @Post('forgot-password')
  @HttpCode(HttpStatus.OK)
  @Throttle({ default: { limit: 3, ttl: 300000 } })
  forgotPassword(@Body('email') email: string, @GetIpAddress() ip: string) {
    return this.auth.forgotPassword(email, ip);
  }

  @Post('reset-password')
  @HttpCode(HttpStatus.OK)
  @Throttle({ default: { limit: 3, ttl: 300000 } })
  resetPassword(@Body('token') token: string, @Body('password') pw: string, @GetIpAddress() ip: string) {
    return this.auth.resetPassword(token, pw, ip);
  }

  @Patch('change-password')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  changePassword(
    @CurrentUser('id') uid: string,
    @Body('currentPassword') cur: string, @Body('newPassword') nw: string,
    @GetIpAddress() ip: string, @Headers('user-agent') ua: string,
  ) {
    return this.auth.changePassword(uid, cur, nw, ip, ua);
  }

  @Post('2fa/setup')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  setupTwoFa(@CurrentUser('id') uid: string, @CurrentUser('email') email: string) {
    return this.twoFa.setupTwoFa(uid, email);
  }

  @Post('2fa/enable')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  enableTwoFa(@CurrentUser('id') uid: string, @Body('code') code: string) {
    return this.twoFa.enableTwoFa(uid, code);
  }

  @Post('2fa/disable')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @Throttle({ default: { limit: 3, ttl: 60000 } })
  disableTwoFa(@CurrentUser('id') uid: string, @Body('code') code: string) {
    return this.twoFa.disableTwoFa(uid, code);
  }
}
