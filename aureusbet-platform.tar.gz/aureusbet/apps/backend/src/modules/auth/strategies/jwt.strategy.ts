import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { TokenService } from '../token.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(cfg: ConfigService, private readonly tokenService: TokenService) {
    super({
      jwtFromRequest:   ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey:      cfg.get<string>('JWT_SECRET'),
      issuer:           'aureusbet.com',
      audience:         'aureusbet-app',
    });
  }

  async validate(payload: any) {
    const user = await this.tokenService.validatePayload(payload);
    if (!user || user.isBanned || user.status === 'BANNED') {
      throw new UnauthorizedException('Sessão inválida.');
    }
    return user;
  }
}
