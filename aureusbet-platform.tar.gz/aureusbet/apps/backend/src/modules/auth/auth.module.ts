import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { BullModule } from '@nestjs/bull';
import { AuthController }     from './auth.controller';
import { AuthService }        from './auth.service';
import { TokenService }       from './token.service';
import { TwoFactorService }   from './two-factor.service';
import { JwtStrategy }        from './strategies/jwt.strategy';
import { JwtRefreshStrategy } from './strategies/jwt-refresh.strategy';
import { UsersModule }         from '../users/users.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { AuditModule }         from '../audit/audit.module';

@Module({
  imports: [
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: (cfg: ConfigService) => ({
        secret: cfg.get<string>('JWT_SECRET'),
        signOptions: {
          expiresIn: cfg.get<string>('JWT_EXPIRES_IN', '15m'),
          issuer: 'aureusbet.com',
          audience: 'aureusbet-app',
        },
      }),
      inject: [ConfigService],
    }),
    BullModule.registerQueue({ name: 'email' }),
    UsersModule,
    NotificationsModule,
    AuditModule,
  ],
  controllers: [AuthController],
  providers:   [AuthService, TokenService, TwoFactorService, JwtStrategy, JwtRefreshStrategy],
  exports:     [AuthService, TokenService, JwtModule],
})
export class AuthModule {}
