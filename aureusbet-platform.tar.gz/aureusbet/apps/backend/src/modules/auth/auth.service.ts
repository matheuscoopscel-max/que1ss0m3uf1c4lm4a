import {
  Injectable, UnauthorizedException, BadRequestException,
  ConflictException, ForbiddenException, Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import { randomBytes } from 'crypto';
import { differenceInYears } from 'date-fns';

import { PrismaService }       from '../../common/services/prisma.service';
import { TokenService }        from './token.service';
import { TwoFactorService }    from './two-factor.service';
import { NotificationsService } from '../notifications/notifications.service';
import { AuditService }        from '../audit/audit.service';

export interface AuthTokens {
  accessToken:  string;
  refreshToken: string;
  expiresIn:    number;
  tokenType:    'Bearer';
}

const BCRYPT_ROUNDS = 12;
const MAX_FAIL_ATTEMPTS = 5;
const LOCKOUT_MINUTES  = 30;

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma:    PrismaService,
    private readonly tokens:    TokenService,
    private readonly twoFa:     TwoFactorService,
    private readonly notify:    NotificationsService,
    private readonly audit:     AuditService,
    private readonly config:    ConfigService,
  ) {}

  // ── REGISTRO ──────────────────────────────────────────────────
  async register(dto: any, ip: string, ua: string) {
    const age = differenceInYears(new Date(), new Date(dto.dateOfBirth));
    if (age < 18) throw new ForbiddenException('Você precisa ter 18 anos ou mais para se registrar.');

    await this.checkRegistrationRateLimit(ip);

    const [existEmail, existUser] = await Promise.all([
      this.prisma.user.findUnique({ where: { email: dto.email.toLowerCase() } }),
      this.prisma.user.findUnique({ where: { username: dto.username.toLowerCase() } }),
    ]);
    if (existEmail) throw new ConflictException('E-mail já cadastrado.');
    if (existUser)  throw new ConflictException('Nome de usuário indisponível.');

    if (dto.cpf) {
      const cpfClean = dto.cpf.replace(/\D/g, '');
      const existCpf = await this.prisma.user.findUnique({ where: { cpf: cpfClean } });
      if (existCpf) throw new ConflictException('CPF já cadastrado.');
    }

    const passwordHash = await bcrypt.hash(dto.password, BCRYPT_ROUNDS);
    const token        = randomBytes(32).toString('hex');
    const tokenExpiry  = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const welcomeAur    = this.config.get<boolean>('WELCOME_AUR_ENABLED', true);
    const welcomeAmount = this.config.get<number>('WELCOME_AUR_AMOUNT', 25);

    const user = await this.prisma.$transaction(async (tx) => {
      const u = await tx.user.create({
        data: {
          email:               dto.email.toLowerCase(),
          username:            dto.username.toLowerCase(),
          displayName:         dto.displayName || dto.username,
          passwordHash,
          cpf:                 dto.cpf ? dto.cpf.replace(/\D/g, '') : null,
          dateOfBirth:         new Date(dto.dateOfBirth),
          isAdult:             age >= 18,
          country:             dto.country ?? null,
          ipAddress:           ip,
          termsAcceptedAt:     new Date(),
          privacyAcceptedAt:   new Date(),
          gdprConsentAt:       dto.gdprConsent ? new Date() : null,
          marketingConsent:    dto.marketingConsent ?? false,
          status:              'PENDING_EMAIL',
        },
      });

      const wallet = await tx.wallet.create({
        data: { userId: u.id, aurBalance: 0, brlBalance: 0 },
      });

      // Bônus de boas-vindas registrado mas não creditado ainda
      // (é creditado na verificação do e-mail)
      if (welcomeAur && welcomeAmount > 0) {
        await tx.userNotification.create({
          data: {
            userId: u.id,
            type:  'PROMOTION',
            title: `Bônus de boas-vindas: ${welcomeAmount} AUR`,
            body:  `Verifique seu e-mail para ativar sua conta e receber ${welcomeAmount} AUR!`,
          },
        });
      }

      await tx.emailVerification.create({
        data: { email: u.email, token, expiresAt: tokenExpiry },
      });

      return u;
    });

    this.notify.sendEmailVerification(user.email, user.displayName ?? user.username, token)
      .catch(e => this.logger.error(`Email verification send error: ${e.message}`));

    await this.audit.log({ userId: user.id, action: 'REGISTER', metadata: { ip }, ipAddress: ip, userAgent: ua });
    this.logger.log(`Novo usuário: ${user.email} de ${ip}`);

    return { message: 'Conta criada. Verifique seu e-mail para ativar.' };
  }

  // ── LOGIN ─────────────────────────────────────────────────────
  async login(dto: any, ip: string, ua: string) {
    await this.checkLoginLockout(ip, dto.email.toLowerCase());

    const user = await this.prisma.user.findUnique({
      where: { email: dto.email.toLowerCase() },
    });

    if (!user) {
      await this.recordAttempt(dto.email, ip, null, false, 'USER_NOT_FOUND');
      throw new UnauthorizedException('Credenciais inválidas.');
    }

    const ok = await bcrypt.compare(dto.password, user.passwordHash);
    if (!ok) {
      await this.recordAttempt(dto.email, ip, user.id, false, 'WRONG_PASSWORD');
      throw new UnauthorizedException('Credenciais inválidas.');
    }

    if (user.isBanned || user.status === 'BANNED') {
      throw new ForbiddenException('Conta suspensa. Entre em contato com o suporte.');
    }
    if (user.isSelfExcluded && user.selfExcludedUntil && user.selfExcludedUntil > new Date()) {
      throw new ForbiddenException(`Você se auto-excluiu até ${user.selfExcludedUntil.toLocaleDateString()}.`);
    }
    if (user.status === 'PENDING_EMAIL') {
      throw new ForbiddenException('Verifique seu e-mail antes de fazer login.');
    }

    await this.recordAttempt(dto.email, ip, user.id, true, null);

    if (user.twoFaEnabled) {
      const tempToken = await this.tokens.createTempToken(user.id);
      return { requiresTwoFa: true, tempToken };
    }

    const result = await this.tokens.generateTokenPair(user, ip, ua);
    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date(), lastLoginIp: ip },
    });
    await this.audit.log({ userId: user.id, action: 'LOGIN', metadata: { ip }, ipAddress: ip, userAgent: ua });

    return result;
  }

  // ── VERIFICAR 2FA ─────────────────────────────────────────────
  async verifyTwoFa(code: string, tempToken: string, ip: string, ua: string): Promise<AuthTokens> {
    const userId = await this.tokens.verifyTempToken(tempToken);
    if (!userId) throw new UnauthorizedException('Sessão inválida ou expirada.');

    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user?.twoFaEnabled || !user.twoFaSecret) throw new BadRequestException('2FA não ativado.');

    const valid = await this.twoFa.verifyToken(user.twoFaSecret, code);
    if (!valid) {
      const backupOk = await this.twoFa.verifyBackupCode(user.id, code);
      if (!backupOk) throw new UnauthorizedException('Código 2FA inválido.');
    }

    const tokens = await this.tokens.generateTokenPair(user, ip, ua);
    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date(), lastLoginIp: ip },
    });
    return tokens;
  }

  // ── REFRESH ───────────────────────────────────────────────────
  async refreshTokens(refreshToken: string, ip: string, ua: string): Promise<AuthTokens> {
    return this.tokens.refreshTokens(refreshToken, ip, ua);
  }

  // ── LOGOUT ────────────────────────────────────────────────────
  async logout(userId: string, refreshToken: string, ip: string, ua: string) {
    await this.tokens.revokeRefreshToken(refreshToken);
    await this.audit.log({ userId, action: 'LOGOUT', metadata: { ip }, ipAddress: ip, userAgent: ua });
  }

  // ── VERIFICAR EMAIL ───────────────────────────────────────────
  async verifyEmail(token: string) {
    const rec = await this.prisma.emailVerification.findUnique({ where: { token } });
    if (!rec || rec.expiresAt < new Date()) throw new BadRequestException('Token inválido ou expirado.');
    if (rec.usedAt) throw new BadRequestException('Token já utilizado.');

    const welcomeAur    = this.config.get<boolean>('WELCOME_AUR_ENABLED', true);
    const welcomeAmount = this.config.get<number>('WELCOME_AUR_AMOUNT', 25);

    await this.prisma.$transaction(async (tx) => {
      await tx.emailVerification.update({ where: { token }, data: { usedAt: new Date() } });

      const user = await tx.user.update({
        where:  { email: rec.email },
        data:   { emailVerified: true, emailVerifiedAt: new Date(), status: 'ACTIVE' },
      });

      if (welcomeAur && welcomeAmount > 0) {
        const wallet = await tx.wallet.findUnique({ where: { userId: user.id } });
        if (wallet) {
          const before = Number(wallet.aurBalance);
          const after  = before + welcomeAmount;

          await tx.wallet.update({
            where: { userId: user.id },
            data:  { aurBalance: after, totalDeposited: { increment: welcomeAmount } },
          });

          await tx.transaction.create({
            data: {
              userId:        user.id,
              walletId:      wallet.id,
              type:          'BONUS',
              status:        'COMPLETED',
              amount:        welcomeAmount,
              currency:      'AUR',
              balanceBefore: before,
              balanceAfter:  after,
              description:   `Bônus de boas-vindas: ${welcomeAmount} AUR`,
              completedAt:   new Date(),
            },
          });
        }
      }
    });

    return { message: 'E-mail verificado! Bem-vindo à AureusBet.' };
  }

  // ── ESQUECI SENHA ─────────────────────────────────────────────
  async forgotPassword(email: string, ip: string) {
    const msg = { message: 'Se o e-mail existir, você receberá as instruções.' };
    const user = await this.prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (!user) return msg;

    const token   = randomBytes(32).toString('hex');
    const expires = new Date(Date.now() + 60 * 60 * 1000);

    await this.prisma.passwordReset.create({
      data: { email: user.email, token, expiresAt: expires, ipAddress: ip },
    });

    await this.notify.sendPasswordReset(user.email, user.displayName ?? user.username, token);
    return msg;
  }

  // ── REDEFINIR SENHA ───────────────────────────────────────────
  async resetPassword(token: string, password: string, ip: string) {
    const rec = await this.prisma.passwordReset.findUnique({ where: { token } });
    if (!rec || rec.expiresAt < new Date() || rec.usedAt) {
      throw new BadRequestException('Token inválido ou expirado.');
    }

    const hash = await bcrypt.hash(password, BCRYPT_ROUNDS);

    await this.prisma.$transaction(async (tx) => {
      await tx.passwordReset.update({ where: { token }, data: { usedAt: new Date() } });
      const user = await tx.user.update({
        where: { email: rec.email },
        data:  { passwordHash: hash },
      });
      await tx.refreshToken.updateMany({
        where: { userId: user.id, revokedAt: null },
        data:  { revokedAt: new Date() },
      });
      await this.audit.log({ userId: user.id, action: 'PASSWORD_CHANGE', metadata: { method: 'reset', ip }, ipAddress: ip });
    });

    return { message: 'Senha redefinida com sucesso.' };
  }

  // ── TROCAR SENHA ──────────────────────────────────────────────
  async changePassword(userId: string, currentPw: string, newPw: string, ip: string, ua: string) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    const ok = await bcrypt.compare(currentPw, user.passwordHash);
    if (!ok) throw new UnauthorizedException('Senha atual incorreta.');
    if (currentPw === newPw) throw new BadRequestException('A nova senha deve ser diferente.');

    const hash = await bcrypt.hash(newPw, BCRYPT_ROUNDS);
    await this.prisma.user.update({ where: { id: userId }, data: { passwordHash: hash } });
    await this.audit.log({ userId, action: 'PASSWORD_CHANGE', metadata: { method: 'change', ip }, ipAddress: ip, userAgent: ua });

    return { message: 'Senha alterada com sucesso.' };
  }

  // ── PRIVADOS ──────────────────────────────────────────────────
  private async checkLoginLockout(ip: string, email: string) {
    const since = new Date(Date.now() - LOCKOUT_MINUTES * 60 * 1000);
    const count = await this.prisma.loginAttempt.count({
      where: { email, success: false, createdAt: { gte: since } },
    });
    if (count >= MAX_FAIL_ATTEMPTS) {
      throw new ForbiddenException(`Muitas tentativas. Tente novamente em ${LOCKOUT_MINUTES} minutos.`);
    }
  }

  private async checkRegistrationRateLimit(ip: string) {
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const count = await this.prisma.loginAttempt.count({
      where: { ipAddress: ip, createdAt: { gte: since } },
    });
    if (count > 5) throw new ForbiddenException('Muitas tentativas de cadastro deste IP.');
  }

  private async recordAttempt(email: string, ip: string, userId: string | null, success: boolean, reason: string | null) {
    await this.prisma.loginAttempt
      .create({ data: { email, ipAddress: ip, userId, success, failReason: reason } })
      .catch(e => this.logger.warn(`recordAttempt error: ${e.message}`));
  }
}
