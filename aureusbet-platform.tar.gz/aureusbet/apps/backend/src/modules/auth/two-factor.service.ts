import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as speakeasy from 'speakeasy';
import * as qrcode from 'qrcode';
import { randomBytes, createCipheriv, createDecipheriv } from 'crypto';
import { PrismaService } from '../../common/services/prisma.service';
import { AuditService } from '../audit/audit.service';

@Injectable()
export class TwoFactorService {
  private readonly logger = new Logger(TwoFactorService.name);
  private readonly encKey: Buffer;

  constructor(
    private readonly prisma:  PrismaService,
    private readonly audit:   AuditService,
    private readonly config:  ConfigService,
  ) {
    const key = this.config.get<string>('ENCRYPTION_KEY')!;
    this.encKey = Buffer.from(key, 'hex');
  }

  async setupTwoFa(userId: string, email: string) {
    const secret = speakeasy.generateSecret({
      name:   `AureusBet (${email})`,
      issuer: this.config.get<string>('TOTP_ISSUER', 'AureusBet'),
      length: 32,
    });

    // Armazena secret temporariamente criptografado
    const enc = this.encrypt(secret.base32);
    await this.prisma.user.update({
      where: { id: userId },
      data:  { twoFaSecret: enc },
    });

    const qrCodeUrl = await qrcode.toDataURL(secret.otpauth_url!);
    return { secret: secret.base32, qrCode: qrCodeUrl };
  }

  async enableTwoFa(userId: string, code: string) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (!user.twoFaSecret) throw new BadRequestException('Execute o setup do 2FA primeiro.');

    const secret = this.decrypt(user.twoFaSecret);
    const valid  = speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token:    code,
      window:   this.config.get<number>('TOTP_WINDOW', 1),
    });
    if (!valid) throw new BadRequestException('Código 2FA inválido.');

    // Gerar backup codes
    const backupCodes = Array.from({ length: 8 }, () => randomBytes(4).toString('hex').toUpperCase());
    const encCodes    = backupCodes.map(c => this.encrypt(c));

    await this.prisma.user.update({
      where: { id: userId },
      data:  { twoFaEnabled: true, twoFaBackupCodes: encCodes },
    });

    await this.audit.log({ userId, action: 'TWO_FA_ENABLED' });
    return { backupCodes, message: '2FA ativado com sucesso. Salve os códigos de backup.' };
  }

  async disableTwoFa(userId: string, code: string) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (!user.twoFaEnabled || !user.twoFaSecret) throw new BadRequestException('2FA não ativado.');

    const valid = this.verifyToken(user.twoFaSecret, code);
    if (!await valid) {
      const backup = await this.verifyBackupCode(userId, code);
      if (!backup) throw new BadRequestException('Código inválido.');
    }

    await this.prisma.user.update({
      where: { id: userId },
      data:  { twoFaEnabled: false, twoFaSecret: null, twoFaBackupCodes: [] },
    });

    await this.audit.log({ userId, action: 'TWO_FA_DISABLED' });
    return { message: '2FA desativado.' };
  }

  async verifyToken(encSecret: string, code: string): Promise<boolean> {
    const secret = this.decrypt(encSecret);
    return speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token:    code.replace(/\s/g, ''),
      window:   this.config.get<number>('TOTP_WINDOW', 1),
    });
  }

  async verifyBackupCode(userId: string, code: string): Promise<boolean> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.twoFaBackupCodes.length) return false;

    const codeUpper = code.toUpperCase();
    let found = false;
    const remaining: string[] = [];

    for (const enc of user.twoFaBackupCodes) {
      const dec = this.decrypt(enc);
      if (dec === codeUpper && !found) { found = true; continue; }
      remaining.push(enc);
    }

    if (found) {
      await this.prisma.user.update({
        where: { id: userId },
        data:  { twoFaBackupCodes: remaining },
      });
    }
    return found;
  }

  private encrypt(text: string): string {
    const iv     = randomBytes(16);
    const cipher = createCipheriv('aes-256-cbc', this.encKey, iv);
    const enc    = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
    return `${iv.toString('hex')}:${enc.toString('hex')}`;
  }

  private decrypt(data: string): string {
    const [ivHex, encHex] = data.split(':');
    const iv      = Buffer.from(ivHex, 'hex');
    const enc     = Buffer.from(encHex, 'hex');
    const decipher = createDecipheriv('aes-256-cbc', this.encKey, iv);
    return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
  }
}
