import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { BullModule } from '@nestjs/bull';
import { ScheduleModule } from '@nestjs/schedule';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { CacheModule } from '@nestjs/cache-manager';
import * as redisStore from 'cache-manager-redis-store';

import { PrismaModule }        from './common/modules/prisma.module';
import { AuthModule }          from './modules/auth/auth.module';
import { UsersModule }         from './modules/users/users.module';
import { GamesModule }         from './modules/games/games.module';
import { PaymentsModule }      from './modules/payments/payments.module';
import { BlockchainModule }    from './modules/blockchain/blockchain.module';
import { CollectiblesModule }  from './modules/collectibles/collectibles.module';
import { MarketModule }        from './modules/market/market.module';
import { AdminModule }         from './modules/admin/admin.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { WebsocketModule }     from './modules/websocket/websocket.module';
import { AuditModule }         from './modules/audit/audit.module';
import { HealthModule }        from './modules/health/health.module';
import { validate }            from './config/env.validation';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env.local', '.env'],
      validate,
      cache: true,
    }),

    ScheduleModule.forRoot(),

    EventEmitterModule.forRoot({ wildcard: false, maxListeners: 30 }),

    CacheModule.registerAsync({
      isGlobal: true,
      imports: [ConfigModule],
      useFactory: (cfg: ConfigService) => ({
        store: redisStore,
        host: cfg.get('REDIS_HOST', 'localhost'),
        port: cfg.get<number>('REDIS_PORT', 6379),
        password: cfg.get('REDIS_PASSWORD') || undefined,
        db: cfg.get<number>('REDIS_DB', 0),
        ttl: 300,
      }),
      inject: [ConfigService],
    }),

    BullModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (cfg: ConfigService) => ({
        redis: {
          host: cfg.get('REDIS_HOST', 'localhost'),
          port: cfg.get<number>('REDIS_PORT', 6379),
          password: cfg.get('REDIS_PASSWORD') || undefined,
          db: 1,
        },
        defaultJobOptions: {
          removeOnComplete: 100,
          removeOnFail: 500,
          attempts: 3,
          backoff: { type: 'exponential', delay: 2000 },
        },
      }),
      inject: [ConfigService],
    }),

    ThrottlerModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (cfg: ConfigService) => [
        { name: 'short',  ttl: 1000,  limit: 10  },
        { name: 'medium', ttl: 10000, limit: 50  },
        { name: 'long',   ttl: 60000, limit: cfg.get<number>('THROTTLE_LIMIT', 100) },
      ],
      inject: [ConfigService],
    }),

    PrismaModule,
    HealthModule,
    AuditModule,
    AuthModule,
    UsersModule,
    GamesModule,
    PaymentsModule,
    BlockchainModule,
    CollectiblesModule,
    MarketModule,
    AdminModule,
    NotificationsModule,
    WebsocketModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: ThrottlerGuard },
  ],
})
export class AppModule {}
