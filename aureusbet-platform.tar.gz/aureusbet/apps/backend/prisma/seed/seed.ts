import { PrismaClient, UserRole, UserStatus, KycStatus, GameType, CollectibleRarity } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed...');

  // ── Admin ─────────────────────────────────────────────────────
  const adminEmail = process.env.FIRST_ADMIN_EMAIL ?? 'admin@aureusbet.com';
  const adminPass  = process.env.FIRST_ADMIN_PASSWORD ?? 'Admin@123456!';

  const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (!existingAdmin) {
    const hash = await bcrypt.hash(adminPass, 12);
    const admin = await prisma.user.create({
      data: {
        email:          adminEmail,
        username:       'admin',
        displayName:    'Administrador',
        passwordHash:   hash,
        status:         UserStatus.ACTIVE,
        role:           UserRole.SUPER_ADMIN,
        kycStatus:      KycStatus.APPROVED,
        emailVerified:  true,
        emailVerifiedAt: new Date(),
        isAdult:        true,
        dateOfBirth:    new Date('1990-01-01'),
        termsAcceptedAt: new Date(),
        privacyAcceptedAt: new Date(),
        gdprConsentAt:  new Date(),
        country:        'BR',
      },
    });

    await prisma.wallet.create({
      data: { userId: admin.id, aurBalance: 1000000, brlBalance: 0 },
    });
    console.log(`✅ Admin criado: ${adminEmail}`);
  } else {
    console.log(`ℹ️  Admin já existe: ${adminEmail}`);
  }

  // ── Jogos ─────────────────────────────────────────────────────
  const games = [
    { type: GameType.CRASH,     name: 'Crash',     slug: 'crash',     sortOrder: 1, isFeatured: true,  isNew: false, houseEdge: 0.01, minBet: 0.1, maxBet: 10000, collectibleDropRate: 0.002 },
    { type: GameType.ROULETTE,  name: 'Roleta',    slug: 'roulette',  sortOrder: 2, isFeatured: true,  isNew: false, houseEdge: 0.027, minBet: 0.1, maxBet: 5000 },
    { type: GameType.BLACKJACK, name: 'Blackjack', slug: 'blackjack', sortOrder: 3, isFeatured: false, isNew: false, houseEdge: 0.005, minBet: 1,   maxBet: 10000 },
    { type: GameType.SLOTS,     name: 'Slots',     slug: 'slots',     sortOrder: 4, isFeatured: false, isNew: true,  houseEdge: 0.04,  minBet: 0.1, maxBet: 500 },
    { type: GameType.DICE,      name: 'Dado',      slug: 'dice',      sortOrder: 5, isFeatured: false, isNew: false, houseEdge: 0.01,  minBet: 0.1, maxBet: 50000 },
    { type: GameType.MINES,     name: 'Minas',     slug: 'mines',     sortOrder: 6, isFeatured: true,  isNew: false, houseEdge: 0.01,  minBet: 0.5, maxBet: 1000 },
    { type: GameType.TOWER,     name: 'Torre',     slug: 'tower',     sortOrder: 7, isFeatured: false, isNew: true,  houseEdge: 0.01,  minBet: 0.5, maxBet: 1000 },
    { type: GameType.COINFLIP,  name: 'CoinFlip',  slug: 'coinflip',  sortOrder: 8, isFeatured: false, isNew: false, houseEdge: 0.01,  minBet: 0.1, maxBet: 10000 },
  ];

  for (const game of games) {
    await prisma.game.upsert({
      where:  { type: game.type },
      create: game as any,
      update: { name: game.name, sortOrder: game.sortOrder },
    });
  }
  console.log(`✅ ${games.length} jogos configurados`);

  // ── Colecionáveis ─────────────────────────────────────────────
  const admin = await prisma.user.findUnique({ where: { email: adminEmail } });

  const collectibles = [
    { name: 'Áureo Fundador',      slug: 'aureo-fundador',      rarity: CollectibleRarity.MYTHIC,    maxSupply: 10,   dropWeight: 0.1,  description: 'Colecionável exclusivo dos primeiros 10 jogadores. Ultra raro.' },
    { name: 'Dragão de Ouro',      slug: 'dragao-de-ouro',      rarity: CollectibleRarity.LEGENDARY, maxSupply: 50,   dropWeight: 0.5,  description: 'O lendário Dragão de Ouro. Guardião das apostas.' },
    { name: 'Cristal Épico',       slug: 'cristal-epico',       rarity: CollectibleRarity.EPIC,      maxSupply: 200,  dropWeight: 2,    description: 'Um cristal forjado no fogo do crash.' },
    { name: 'Moeda da Sorte',      slug: 'moeda-da-sorte',      rarity: CollectibleRarity.RARE,      maxSupply: 500,  dropWeight: 5,    description: 'Dizem que traz boa sorte nas próximas apostas.' },
    { name: 'Carta Selvagem',      slug: 'carta-selvagem',      rarity: CollectibleRarity.COMMON,    maxSupply: 2000, dropWeight: 15,   description: 'A mais comum, mas ainda é sua!' },
    { name: 'Estrela Cadente',     slug: 'estrela-cadente',     rarity: CollectibleRarity.RARE,      maxSupply: 300,  dropWeight: 4,    description: 'Capturada no auge do multiplicador.' },
    { name: 'Foguete Lunar',       slug: 'foguete-lunar',       rarity: CollectibleRarity.EPIC,      maxSupply: 150,  dropWeight: 1.5,  description: 'Para os jogadores que foram à lua no Crash.' },
    { name: 'Coroa Dourada',       slug: 'coroa-dourada',       rarity: CollectibleRarity.LEGENDARY, maxSupply: 25,   dropWeight: 0.3,  description: 'Apenas os verdadeiros reis do cassino a possuem.' },
  ];

  for (const col of collectibles) {
    await prisma.collectible.upsert({
      where:  { slug: col.slug },
      create: { ...col, imageUrl: `https://cdn.aureusbet.com/collectibles/${col.slug}.png`, createdById: admin!.id } as any,
      update: { description: col.description },
    });
  }
  console.log(`✅ ${collectibles.length} colecionáveis criados`);

  // ── Configurações do site ─────────────────────────────────────
  const configs = [
    { key: 'maintenance_mode',     value: { enabled: false },               label: 'Modo manutenção',       group: 'system' },
    { key: 'aur_brl_rate',         value: { rate: 1.0 },                    label: 'Taxa AUR/BRL',          group: 'finance' },
    { key: 'welcome_bonus_enabled', value: { enabled: true, amount: 25 },   label: 'Bônus boas-vindas',     group: 'promotions' },
    { key: 'site_logo',            value: { url: '' },                      label: 'Logo do site',          group: 'assets' },
    { key: 'site_primary_color',   value: { color: '#f59e0b' },             label: 'Cor primária',          group: 'theme' },
    { key: 'kyc_required_deposit', value: { minAmount: 5000 },              label: 'KYC obrigatório acima', group: 'compliance' },
    { key: 'max_withdrawal_auto',  value: { amount: 1000 },                 label: 'Saque auto máximo',     group: 'finance' },
    { key: 'support_email',        value: { email: 'suporte@aureusbet.com' }, label: 'E-mail suporte',      group: 'system' },
  ];

  for (const cfg of configs) {
    await prisma.siteConfig.upsert({
      where:  { key: cfg.key },
      create: { ...cfg, updatedById: admin!.id } as any,
      update: {},
    });
  }
  console.log(`✅ ${configs.length} configurações inseridas`);

  console.log('\n🎰 Seed concluído com sucesso!\n');
}

main()
  .catch(e => { console.error('❌ Seed falhou:', e); process.exit(1); })
  .finally(() => prisma.$disconnect());
