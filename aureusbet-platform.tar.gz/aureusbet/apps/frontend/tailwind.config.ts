import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        gold: {
          50:  '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
          700: '#b45309',
          800: '#92400e',
          900: '#78350f',
          950: '#451a03',
        },
        bg: {
          primary:   '#0a0a0f',
          secondary: '#111118',
          card:      '#16161e',
          elevated:  '#1c1c26',
          border:    '#2a2a3a',
        },
        neon: {
          gold:   '#f59e0b',
          green:  '#22c55e',
          red:    '#ef4444',
          blue:   '#3b82f6',
          purple: '#a855f7',
        },
      },
      fontFamily: {
        sans:  ['var(--font-inter)', 'sans-serif'],
        mono:  ['var(--font-mono)', 'monospace'],
        display: ['var(--font-display)', 'sans-serif'],
      },
      animation: {
        'glow-pulse': 'glow-pulse 2s ease-in-out infinite',
        'float':      'float 3s ease-in-out infinite',
        'spin-slow':  'spin 3s linear infinite',
        'counter':    'counter 0.3s ease-out',
        'crash-line': 'crash-line 0.1s linear',
        'bounce-in':  'bounce-in 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
        'shimmer':    'shimmer 2s infinite linear',
      },
      keyframes: {
        'glow-pulse': {
          '0%, 100%': { boxShadow: '0 0 10px rgba(245, 158, 11, 0.4)' },
          '50%':      { boxShadow: '0 0 30px rgba(245, 158, 11, 0.8), 0 0 60px rgba(245, 158, 11, 0.3)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%':      { transform: 'translateY(-8px)' },
        },
        'bounce-in': {
          '0%':   { opacity: '0', transform: 'scale(0.3)' },
          '50%':  { opacity: '1', transform: 'scale(1.05)' },
          '70%':  { transform: 'scale(0.9)' },
          '100%': { transform: 'scale(1)' },
        },
        'shimmer': {
          '0%':   { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      backgroundImage: {
        'gold-gradient':    'linear-gradient(135deg, #f59e0b 0%, #d97706 50%, #f59e0b 100%)',
        'dark-gradient':    'linear-gradient(180deg, #0a0a0f 0%, #111118 100%)',
        'card-gradient':    'linear-gradient(145deg, #16161e 0%, #1c1c26 100%)',
        'neon-border':      'linear-gradient(135deg, #f59e0b33, transparent, #f59e0b33)',
        'shimmer-gradient': 'linear-gradient(90deg, transparent 0%, rgba(245,158,11,0.1) 50%, transparent 100%)',
      },
    },
  },
  plugins: [],
};

export default config;
