'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { useWalletStore } from '@/store/wallet.store';
import { useAuthStore }   from '@/store/auth.store';
import { api }            from '@/lib/api/client';
import { formatAur }      from '@/lib/utils/format';
import { toast }          from 'react-toastify';
import { X, Coins, ArrowDownToLine, ArrowUpFromLine, RefreshCw, Copy, ExternalLink, Loader2 } from 'lucide-react';

type Tab = 'overview' | 'deposit' | 'withdraw';

interface Props { onClose: () => void; }

export function WalletMenu({ onClose }: Props) {
  const { aurBalance, brlBalance, fetchBalance } = useWalletStore();
  const { user } = useAuthStore();
  const [tab,        setTab]        = useState<Tab>('overview');
  const [amount,     setAmount]     = useState('');
  const [pixKey,     setPixKey]     = useState('');
  const [loading,    setLoading]    = useState(false);
  const [pixData,    setPixData]    = useState<any>(null);
  const [rate,       setRate]       = useState(1);

  const aurFromBrl = parseFloat(amount) / rate || 0;

  const handleDeposit = async () => {
    const amountBrl = parseFloat(amount);
    if (!amountBrl || amountBrl < 5) return toast.error('Mínimo R$ 5,00');
    setLoading(true);
    try {
      const res: any = await api.post('/payments/deposit/pix', { amountBrl, aurAmount: aurFromBrl });
      setPixData(res);
    } catch (err: any) {
      toast.error(err?.message ?? 'Erro ao gerar PIX.');
    } finally {
      setLoading(false);
    }
  };

  const handleWithdraw = async () => {
    const amountAur = parseFloat(amount);
    if (!amountAur || amountAur < 5) return toast.error('Mínimo 5 AUR');
    if (!pixKey) return toast.error('Informe a chave PIX');
    setLoading(true);
    try {
      await api.post('/payments/withdraw', { amountAur, pixKey, pixKeyType: 'cpf' });
      toast.success('Saque solicitado!');
      fetchBalance();
      setAmount('');
    } catch (err: any) {
      toast.error(err?.message ?? 'Erro ao solicitar saque.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copiado!');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ y: '100%', opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: '100%', opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="bg-bg-card border border-bg-border rounded-t-2xl sm:rounded-2xl w-full sm:max-w-md max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-bg-border sticky top-0 bg-bg-card z-10">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-gold-400" />
            <h2 className="font-display font-bold text-lg text-white">Carteira</h2>
          </div>
          <button onClick={onClose} className="btn-icon p-1.5">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Saldo */}
        <div className="p-5 bg-gradient-to-b from-gold-500/5 to-transparent border-b border-bg-border">
          <div className="text-center">
            <p className="text-white/50 text-xs mb-1">Saldo AUR</p>
            <p className="font-display font-black text-4xl text-gold-400" style={{ textShadow: '0 0 30px rgba(245,158,11,0.4)' }}>
              {formatAur(aurBalance)}
            </p>
            <p className="text-white/30 text-xs mt-1">AUR</p>
          </div>

          {user?.wallet?.polygonAddress && (
            <div className="flex items-center gap-2 mt-3 p-2.5 bg-bg-elevated rounded-lg">
              <span className="text-xs text-white/40 font-mono flex-1 truncate">{user.wallet.polygonAddress}</span>
              <button onClick={() => copyToClipboard(user.wallet!.polygonAddress!)} className="text-white/40 hover:text-white/70 transition-colors">
                <Copy className="w-3.5 h-3.5" />
              </button>
              <a href={`https://polygonscan.com/address/${user.wallet.polygonAddress}`} target="_blank" rel="noopener noreferrer"
                className="text-white/40 hover:text-white/70 transition-colors">
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex border-b border-bg-border">
          {([['overview', '📊 Visão'], ['deposit', '⬇️ Depositar'], ['withdraw', '⬆️ Sacar']] as [Tab, string][]).map(([key, label]) => (
            <button
              key={key}
              onClick={() => { setTab(key); setPixData(null); setAmount(''); }}
              className={`flex-1 py-3 text-sm font-medium transition-all ${tab === key ? 'text-gold-400 border-b-2 border-gold-400' : 'text-white/40 hover:text-white/60'}`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="p-5">
          {/* OVERVIEW */}
          {tab === 'overview' && (
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Total depositado', value: '—' },
                  { label: 'Total sacado',     value: '—' },
                  { label: 'Total ganho',      value: '—' },
                  { label: 'Saldo bloqueado',  value: '0' },
                ].map(s => (
                  <div key={s.label} className="card p-3">
                    <p className="text-white/40 text-xs">{s.label}</p>
                    <p className="font-mono font-bold text-white mt-0.5">{s.value}</p>
                  </div>
                ))}
              </div>
              <div className="flex gap-3">
                <button onClick={() => setTab('deposit')} className="btn-gold flex-1 py-3 justify-center flex gap-2">
                  <ArrowDownToLine className="w-4 h-4" /> Depositar
                </button>
                <button onClick={() => setTab('withdraw')} className="btn-ghost flex-1 py-3 justify-center flex gap-2">
                  <ArrowUpFromLine className="w-4 h-4" /> Sacar
                </button>
              </div>
            </div>
          )}

          {/* DEPOSIT */}
          {tab === 'deposit' && (
            <div className="flex flex-col gap-4">
              {pixData ? (
                <div className="flex flex-col items-center gap-4">
                  <div className="p-3 bg-white rounded-xl">
                    <img src={`data:image/png;base64,${pixData.qrCodeBase64}`} alt="QR Code PIX" className="w-48 h-48" />
                  </div>
                  <div className="w-full">
                    <p className="text-xs text-white/50 mb-1">Código PIX copia e cola</p>
                    <div className="flex gap-2">
                      <input readOnly value={pixData.qrCode} className="input text-xs flex-1" />
                      <button onClick={() => copyToClipboard(pixData.qrCode)} className="btn-gold px-3">
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-green-400 font-semibold">Você receberá: {formatAur(pixData.aurAmount)} AUR</p>
                    <p className="text-white/40 text-xs mt-1">Expira em 30 minutos</p>
                  </div>
                  <button onClick={() => setPixData(null)} className="btn-ghost w-full">Novo PIX</button>
                </div>
              ) : (
                <>
                  <div className="p-3 bg-gold-500/10 border border-gold-500/20 rounded-xl text-sm text-gold-400/80 text-center">
                    💡 Deposite via PIX e receba AUR instantaneamente
                  </div>
                  <div>
                    <label className="text-sm text-white/60 mb-1.5 block">Valor em R$ (BRL)</label>
                    <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="50.00" min="5" className="input font-mono" />
                  </div>
                  {parseFloat(amount) > 0 && (
                    <div className="flex items-center justify-between p-3 bg-bg-elevated rounded-lg text-sm">
                      <span className="text-white/50">Você receberá</span>
                      <span className="font-mono font-bold text-gold-400">{aurFromBrl.toFixed(2)} AUR</span>
                    </div>
                  )}
                  <button onClick={handleDeposit} disabled={loading} className="btn-gold w-full py-3 justify-center flex gap-2">
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><ArrowDownToLine className="w-4 h-4" /> Gerar PIX</>}
                  </button>
                </>
              )}
            </div>
          )}

          {/* WITHDRAW */}
          {tab === 'withdraw' && (
            <div className="flex flex-col gap-4">
              <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl text-xs text-yellow-400/80">
                ⚠️ KYC e 2FA obrigatórios para saques. Prazo: até 24h.
              </div>
              <div>
                <label className="text-sm text-white/60 mb-1.5 block">Quantidade de AUR</label>
                <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="10.00" min="5" className="input font-mono" />
                <p className="text-xs text-white/30 mt-1">Saldo: {formatAur(aurBalance)} AUR</p>
              </div>
              <div>
                <label className="text-sm text-white/60 mb-1.5 block">Chave PIX</label>
                <input type="text" value={pixKey} onChange={e => setPixKey(e.target.value)} placeholder="CPF, e-mail ou telefone" className="input" />
              </div>
              <button onClick={handleWithdraw} disabled={loading} className="btn-gold w-full py-3 justify-center flex gap-2">
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><ArrowUpFromLine className="w-4 h-4" /> Solicitar Saque</>}
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
