'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore } from '@/store/auth.store';
import { Zap } from 'lucide-react';
import { formatAur } from '@/lib/utils/format';
import { io, Socket } from 'socket.io-client';

interface LiveBet {
  id:         string;
  username:   string;
  gameName:   string;
  amount:     number;
  payout?:    number;
  multiplier?: number;
  won:        boolean;
  timestamp:  Date;
}

export function LiveBetsFeed() {
  const [bets, setBets] = useState<LiveBet[]>([]);

  useEffect(() => {
    // Simular apostas ao vivo (conectar ao WebSocket real)
    const mock: LiveBet[] = Array.from({ length: 8 }, (_, i) => ({
      id:         `${i}`,
      username:   ['Jogador1','crypto_king','aureusVIP','betmaster','goldminer','cryptobro','winner99','player42'][i],
      gameName:   ['Crash','Dice','Blackjack','Slots','Crash','Mines','Crash','Dice'][i],
      amount:     [5,12,50,1,100,8,25,3][i],
      multiplier: [1.42,2.0,undefined,undefined,3.5,undefined,1.8,undefined][i],
      payout:     [7.1,24,undefined,undefined,350,undefined,45,undefined][i],
      won:        [true,true,false,true,true,false,true,false][i],
      timestamp:  new Date(Date.now() - i * 8000),
    }));
    setBets(mock);
  }, []);

  return (
    <section>
      <div className="flex items-center gap-2 mb-4">
        <h2 className="font-display font-bold text-xl text-white">Apostas ao Vivo</h2>
        <div className="flex items-center gap-1.5 px-2 py-0.5 bg-red-500/10 border border-red-500/30 rounded-full">
          <div className="w-1.5 h-1.5 bg-red-400 rounded-full animate-pulse" />
          <span className="text-xs text-red-400 font-medium">LIVE</span>
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[500px]">
            <thead className="bg-bg-elevated border-b border-bg-border">
              <tr className="text-white/40 text-xs">
                <th className="text-left px-4 py-3">Jogo</th>
                <th className="text-left px-4 py-3">Jogador</th>
                <th className="text-right px-4 py-3">Aposta</th>
                <th className="text-right px-4 py-3">Mult.</th>
                <th className="text-right px-4 py-3">Payout</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {bets.map((bet, i) => (
                  <motion.tr
                    key={bet.id}
                    initial={{ opacity: 0, backgroundColor: bet.won ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)' }}
                    animate={{ opacity: 1, backgroundColor: 'transparent' }}
                    transition={{ delay: i * 0.05, duration: 0.5 }}
                    className="border-b border-bg-border/50 hover:bg-bg-elevated/50 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Zap className="w-3.5 h-3.5 text-gold-400/60" />
                        <span className="text-white/70">{bet.gameName}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-medium text-white/80">{bet.username}</td>
                    <td className="px-4 py-3 text-right font-mono text-white/60">{formatAur(bet.amount)}</td>
                    <td className="px-4 py-3 text-right font-mono">
                      {bet.multiplier
                        ? <span className={bet.won ? 'text-green-400 font-bold' : 'text-red-400'}>{bet.multiplier.toFixed(2)}x</span>
                        : <span className="text-white/30">—</span>}
                    </td>
                    <td className="px-4 py-3 text-right font-mono">
                      {bet.won && bet.payout
                        ? <span className="text-green-400 font-bold">+{formatAur(bet.payout)}</span>
                        : <span className="text-red-400">-{formatAur(bet.amount)}</span>}
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
