'use client';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { api } from '@/lib/api/client';
import { Rocket, Dice1, Layers, HelpCircle, Bomb, TowerControl, Coins, Circle } from 'lucide-react';

const FALLBACK_ICONS: Record<string, any> = {
  CRASH: Rocket, ROULETTE: Circle, BLACKJACK: Layers, SLOTS: Layers,
  DICE: Dice1, MINES: Bomb, TOWER: TowerControl, COINFLIP: Coins,
};

const GAME_COLORS: Record<string, string> = {
  CRASH: 'from-orange-500/20 to-red-500/20 border-orange-500/30',
  ROULETTE: 'from-red-500/20 to-pink-500/20 border-red-500/30',
  BLACKJACK: 'from-green-500/20 to-teal-500/20 border-green-500/30',
  SLOTS: 'from-purple-500/20 to-blue-500/20 border-purple-500/30',
  DICE: 'from-blue-500/20 to-cyan-500/20 border-blue-500/30',
  MINES: 'from-yellow-500/20 to-orange-500/20 border-yellow-500/30',
  TOWER: 'from-indigo-500/20 to-purple-500/20 border-indigo-500/30',
  COINFLIP: 'from-gold-500/20 to-yellow-500/20 border-gold-500/30',
};

export function GamesGrid() {
  const { data: games = [], isLoading } = useQuery<any[]>({
    queryKey: ['games'],
    queryFn:  () => api.get('/games') as any,
  });

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display font-bold text-xl text-white">Jogos</h2>
        <Link href="/games" className="text-sm text-gold-400/70 hover:text-gold-400 transition-colors">Ver todos →</Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {isLoading
          ? Array.from({ length: 8 }).map((_, i) => <div key={i} className="skeleton h-40 rounded-xl" />)
          : games.map((game, i) => {
              const Icon = FALLBACK_ICONS[game.type] ?? HelpCircle;
              const gradient = GAME_COLORS[game.type] ?? 'from-bg-elevated to-bg-card border-bg-border';

              return (
                <motion.div
                  key={game.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Link href={`/${game.slug}`}
                    className={`block relative h-40 rounded-xl border bg-gradient-to-br ${gradient} overflow-hidden group transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-gold-500/10`}
                  >
                    {game.coverUrl || game.imageUrl ? (
                      <Image src={game.coverUrl ?? game.imageUrl} alt={game.name} fill className="object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-300" />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Icon className="w-14 h-14 text-white/10" />
                      </div>
                    )}

                    {/* Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />

                    {/* Badges */}
                    <div className="absolute top-2 left-2 flex gap-1">
                      {game.isFeatured && <span className="badge-gold text-[10px] px-1.5 py-0.5">⭐ Destaque</span>}
                      {game.isNew      && <span className="badge-green text-[10px] px-1.5 py-0.5">Novo</span>}
                    </div>

                    {/* Nome */}
                    <div className="absolute bottom-0 left-0 right-0 p-3">
                      <p className="font-display font-bold text-white text-sm">{game.name}</p>
                      <p className="text-white/40 text-xs mt-0.5">
                        House edge: {(parseFloat(game.houseEdge) * 100).toFixed(1)}%
                      </p>
                    </div>

                    {/* Hover play */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="w-12 h-12 bg-gold-500/90 rounded-full flex items-center justify-center shadow-lg">
                        <Rocket className="w-6 h-6 text-black" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
      </div>
    </section>
  );
}
