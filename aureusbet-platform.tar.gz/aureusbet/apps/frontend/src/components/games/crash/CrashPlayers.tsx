'use client';
import { motion, AnimatePresence } from 'framer-motion';
import { formatAur } from '@/lib/utils/format';

interface Player {
  userId: string; username: string; amount: number;
  cashedOutAt?: number; payout?: number;
}

export function CrashPlayers({ players }: { players: Player[] }) {
  if (!players.length) {
    return <div className="p-6 text-center text-white/30 text-sm">Nenhum jogador ainda</div>;
  }

  return (
    <div className="max-h-60 overflow-y-auto no-scrollbar">
      <table className="w-full text-sm">
        <thead className="sticky top-0 bg-bg-card">
          <tr className="text-white/40 text-xs">
            <th className="text-left px-4 py-2">Jogador</th>
            <th className="text-right px-4 py-2">Aposta</th>
            <th className="text-right px-4 py-2">Mult.</th>
            <th className="text-right px-4 py-2">Payout</th>
          </tr>
        </thead>
        <tbody>
          <AnimatePresence>
            {players.map(p => (
              <motion.tr
                key={p.userId}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className={`border-t border-bg-border/50 ${p.cashedOutAt ? 'bg-green-500/5' : ''}`}
              >
                <td className="px-4 py-2 font-medium">{p.username}</td>
                <td className="px-4 py-2 text-right font-mono text-white/70">{formatAur(p.amount)}</td>
                <td className="px-4 py-2 text-right">
                  {p.cashedOutAt ? <span className="text-green-400 font-bold">{p.cashedOutAt.toFixed(2)}x</span> : <span className="text-white/30">—</span>}
                </td>
                <td className="px-4 py-2 text-right font-mono">
                  {p.payout ? <span className="text-green-400 font-bold">+{formatAur(p.payout)}</span> : <span className="text-white/30">—</span>}
                </td>
              </motion.tr>
            ))}
          </AnimatePresence>
        </tbody>
      </table>
    </div>
  );
}
