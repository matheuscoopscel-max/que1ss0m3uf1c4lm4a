'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore }   from '@/store/auth.store';
import { useWalletStore } from '@/store/wallet.store';
import { useCrashSocket } from '@/hooks/useCrashSocket';
import { CrashChart }     from './CrashChart';
import { CrashBetForm }   from './CrashBetForm';
import { CrashPlayers }   from './CrashPlayers';
import { CrashHistory }   from './CrashHistory';
import { api }            from '@/lib/api/client';
import { formatAur }      from '@/lib/utils/format';
import { toast }          from 'react-toastify';
import { Rocket, TrendingUp, Users, History } from 'lucide-react';

type GameState = 'WAITING' | 'RUNNING' | 'CRASHED';

export function CrashGame() {
  const { user }               = useAuthStore();
  const { aurBalance, fetchBalance } = useWalletStore();

  const [gameState,   setGameState]   = useState<GameState>('WAITING');
  const [multiplier,  setMultiplier]  = useState(1.00);
  const [crashPoint,  setCrashPoint]  = useState<number | null>(null);
  const [history,     setHistory]     = useState<number[]>([]);
  const [betPlaced,   setBetPlaced]   = useState(false);
  const [cashedOut,   setCashedOut]   = useState(false);
  const [myBetAmount, setMyBetAmount] = useState(0);
  const [myPayout,    setMyPayout]    = useState<number | null>(null);
  const [waitMs,      setWaitMs]      = useState(8000);
  const [players,     setPlayers]     = useState<any[]>([]);
  const [activeTab,   setActiveTab]   = useState<'players' | 'history'>('players');

  const { socket, connected } = useCrashSocket({
    onWaiting:  (data) => { setGameState('WAITING'); setMultiplier(1.00); setCrashPoint(null); setWaitMs(data.waitMs); setBetPlaced(false); setCashedOut(false); setMyPayout(null); setHistory(data.history ?? []); },
    onStarted:  ()     => { setGameState('RUNNING'); setMultiplier(1.00); },
    onTick:     (data) => setMultiplier(data.multiplier),
    onCrashed:  (data) => { setGameState('CRASHED'); setCrashPoint(data.crashPoint); setHistory(h => [data.crashPoint, ...h.slice(0,19)]); fetchBalance(); },
    onPlayerBet:    (data) => setPlayers(ps => [data, ...ps]),
    onPlayerCashout: (data) => setPlayers(ps => ps.map(p => p.userId === data.userId ? { ...p, cashedOutAt: data.multiplier, payout: data.payout } : p)),
  });

  const handlePlaceBet = async (amount: number, autoCashout?: number) => {
    if (!user) return;
    try {
      const res: any = await api.post('/games/crash/bet', { amount, autoCashout });
      setBetPlaced(true);
      setMyBetAmount(amount);
      fetchBalance();
      toast.success(`Aposta de ${formatAur(amount)} AUR registrada!`);
    } catch (err: any) {
      toast.error(err.message ?? 'Erro ao apostar.');
    }
  };

  const handleCashout = async () => {
    if (!betPlaced || cashedOut) return;
    try {
      const res: any = await api.post('/games/crash/cashout');
      setCashedOut(true);
      setMyPayout(res.payout);
      fetchBalance();
      toast.success(`💰 Saque: ${formatAur(res.payout)} AUR (${res.multiplier}x)!`);
    } catch (err: any) {
      toast.error(err.message ?? 'Erro ao sacar.');
    }
  };

  const getMultiplierColor = () => {
    if (gameState === 'CRASHED') return '#ef4444';
    if (multiplier >= 10) return '#a855f7';
    if (multiplier >= 5)  return '#f59e0b';
    if (multiplier >= 2)  return '#22c55e';
    return '#3b82f6';
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-4 max-w-[1400px] mx-auto">

      {/* Painel principal */}
      <div className="flex flex-col gap-4">

        {/* Título */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gold-gradient rounded-xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 0 20px rgba(245,158,11,0.4)' }}>
            <Rocket className="w-6 h-6 text-black" />
          </div>
          <div>
            <h1 className="font-display font-bold text-2xl text-white">Crash</h1>
            <p className="text-xs text-white/40">Provably Fair · RNG Certificado</p>
          </div>
          <div className={`ml-auto flex items-center gap-1.5 px-2 py-1 rounded-full text-xs ${connected ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
            <div className={`w-1.5 h-1.5 rounded-full ${connected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
            {connected ? 'Ao Vivo' : 'Desconectado'}
          </div>
        </div>

        {/* Display do multiplicador */}
        <div className="card-glow relative overflow-hidden min-h-[280px] flex flex-col items-center justify-center">
          {/* Background grid */}
          <div className="absolute inset-0 opacity-5" style={{
            backgroundImage: 'linear-gradient(rgba(245,158,11,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(245,158,11,0.5) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }} />

          <AnimatePresence mode="wait">
            {gameState === 'WAITING' ? (
              <motion.div key="waiting" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center gap-4 z-10">
                <div className="text-white/40 text-sm font-medium">Próximo round em</div>
                <CountdownTimer ms={waitMs} />
                <div className="text-white/30 text-xs">Faça sua aposta agora!</div>
              </motion.div>
            ) : (
              <motion.div
                key="running"
                className="flex flex-col items-center gap-2 z-10"
                animate={{ scale: gameState === 'CRASHED' ? [1, 1.1, 0.95, 1] : 1 }}
                transition={{ duration: 0.4 }}
              >
                <motion.div
                  className="font-display font-black tabular-nums"
                  style={{
                    fontSize: multiplier >= 100 ? '4rem' : multiplier >= 10 ? '5rem' : '6rem',
                    color: getMultiplierColor(),
                    textShadow: `0 0 40px ${getMultiplierColor()}80`,
                    lineHeight: 1,
                  }}
                >
                  {multiplier.toFixed(2)}x
                </motion.div>

                {gameState === 'CRASHED' ? (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="px-4 py-1.5 bg-red-500/20 border border-red-500/40 rounded-full text-red-400 font-bold text-sm"
                  >
                    💥 CRASHED!
                  </motion.div>
                ) : betPlaced && !cashedOut ? (
                  <div className="text-white/60 text-sm">
                    Lucro: <span className="text-green-400 font-bold">+{formatAur((multiplier - 1) * myBetAmount)} AUR</span>
                  </div>
                ) : cashedOut ? (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="px-4 py-1.5 bg-green-500/20 border border-green-500/40 rounded-full text-green-400 font-bold text-sm"
                  >
                    ✅ Sacou {myPayout ? formatAur(myPayout) : '?'} AUR
                  </motion.div>
                ) : null}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Chart */}
          <div className="absolute bottom-0 left-0 right-0 h-16 opacity-30">
            <CrashChart multiplier={multiplier} state={gameState} />
          </div>
        </div>

        {/* Players / History tabs */}
        <div className="card p-0 overflow-hidden">
          <div className="flex border-b border-bg-border">
            {[
              { key: 'players', label: 'Jogadores', icon: Users },
              { key: 'history', label: 'Histórico', icon: History },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as any)}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium transition-all ${
                  activeTab === tab.key
                    ? 'text-gold-400 border-b-2 border-gold-400'
                    : 'text-white/40 hover:text-white/70'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
          {activeTab === 'players' ? (
            <CrashPlayers players={players} />
          ) : (
            <CrashHistory history={history} />
          )}
        </div>
      </div>

      {/* Painel de aposta */}
      <div className="flex flex-col gap-4">
        <CrashBetForm
          gameState={gameState}
          betPlaced={betPlaced}
          cashedOut={cashedOut}
          multiplier={multiplier}
          balance={aurBalance}
          onBet={handlePlaceBet}
          onCashout={handleCashout}
        />
      </div>
    </div>
  );
}

function CountdownTimer({ ms }: { ms: number }) {
  const [remaining, setRemaining] = useState(ms);

  useEffect(() => {
    setRemaining(ms);
    const interval = setInterval(() => setRemaining(r => Math.max(0, r - 100)), 100);
    return () => clearInterval(interval);
  }, [ms]);

  const secs = (remaining / 1000).toFixed(1);

  return (
    <div className="font-display font-black text-6xl text-gold-400 tabular-nums"
      style={{ textShadow: '0 0 30px rgba(245,158,11,0.5)' }}>
      {secs}s
    </div>
  );
}
