'use client';
export function CrashHistory({ history }: { history: number[] }) {
  if (!history.length) return <div className="p-6 text-center text-white/30 text-sm">Nenhum histórico ainda</div>;

  const getColor = (v: number) => {
    if (v < 1.5) return 'text-red-400 bg-red-500/10 border-red-500/30';
    if (v < 2)   return 'text-orange-400 bg-orange-500/10 border-orange-500/30';
    if (v < 5)   return 'text-green-400 bg-green-500/10 border-green-500/30';
    if (v < 10)  return 'text-blue-400 bg-blue-500/10 border-blue-500/30';
    return 'text-purple-400 bg-purple-500/10 border-purple-500/30';
  };

  return (
    <div className="p-4 flex flex-wrap gap-2">
      {history.map((v, i) => (
        <span key={i} className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-mono font-bold border ${getColor(v)}`}>
          {v.toFixed(2)}x
        </span>
      ))}
    </div>
  );
}
