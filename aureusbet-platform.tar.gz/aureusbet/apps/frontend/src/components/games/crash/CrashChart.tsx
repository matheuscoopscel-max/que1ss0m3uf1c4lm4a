'use client';
import { useEffect, useRef } from 'react';

interface Props { multiplier: number; state: 'WAITING' | 'RUNNING' | 'CRASHED'; }

export function CrashChart({ multiplier, state }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pointsRef = useRef<{ x: number; y: number }[]>([]);

  useEffect(() => {
    if (state === 'WAITING') { pointsRef.current = []; }
  }, [state]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    const { width, height } = canvas;

    const progress = Math.min((multiplier - 1) / 9, 1);
    pointsRef.current.push({ x: progress, y: (multiplier - 1) / 9 });
    if (pointsRef.current.length > 200) pointsRef.current.shift();

    ctx.clearRect(0, 0, width, height);

    if (pointsRef.current.length < 2) return;

    const color = state === 'CRASHED' ? '#ef4444' : multiplier >= 5 ? '#f59e0b' : '#22c55e';

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth   = 2;
    ctx.shadowBlur  = 10;
    ctx.shadowColor = color;

    pointsRef.current.forEach((pt, i) => {
      const x = pt.x * width;
      const y = height - pt.y * height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  }, [multiplier, state]);

  return <canvas ref={canvasRef} className="w-full h-full" />;
}
