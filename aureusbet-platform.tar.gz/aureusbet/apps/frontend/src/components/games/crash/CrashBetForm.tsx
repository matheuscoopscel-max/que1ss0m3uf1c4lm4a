'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Coins, Zap, TrendingUp } from 'lucide-react';
import { formatAur } from '@/lib/utils/format';
import { clsx } from 'clsx';

interface Props {
  gameState:  'WAITING' | 'RUNNING' | 'CRASHED';
  betPlaced:  boolean;
  cashedOut:  boolean;
  multiplier: number;
  balance:    number;
  onBet:      (amount: number, autoCashout?: number) => void;
  onCashout:  () => void;
}

const QUICK_AMOUNTS = [0.5, 1, 5, 10, 50, 100];

export function CrashBetForm({ gameState, betPlaced, cashedOut, multiplier, balance, onBet, onCashout }: Props) {
  const [amount,      setAmount]      = useState('1');
  const [autoCashout, setAutoCashout] = useState('');
  const [isAutoCashout, setIsAutoCashout] = useState(false);
  const [loading,     setLoading]     = useState(false);

  const amountNum      = parseFloat(amount) || 0;
  const autoCashoutNum = parseFloat(autoCashout) || undefined;
  const canBet         = gameState === 'WAITING' && !betPlaced && amountNum > 0 && amountNum <= balance;
  const canCashout     = gameState === 'RUNNING' && betPlaced && !cashedOut;
  const potentialPayout = amountNum * multiplier;

  const handleBet = async () => {
    if (!canBet) return;
    setLoading(true);
    try {
      await onBet(amountNum, isAutoCashout ? autoCashoutNum : undefined);
    } finally {
      setLoading(false);
    }
  };

  const handleCashout = async () => {
    if (!canCashout) return;
    setLoading(true);
    try {
      await onCashout();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card-glow flex flex-col gap-4">
      <h3 className="font-semibold text-white flex items-center gap-2">
        <Zap className="w-4 h-4 text-gold-400" />
        Fazer Aposta
      </h3>

      {/* Saldo */}
      <div className="flex items-center justify-between p-3 bg-bg-elevated rounded-lg">
        <span className="text-white/50 text-sm">Saldo disponível</span>
        <div className="flex items-center gap-1.5">
          <Coins className="w-4 h-4 text-gold-400" />
          <span className="font-mono font-bold text-gold-400">{formatAur(balance)}</span>
          <span className="text-white/40 text-xs">AUR</span>
        </div>
      </div>

      {/* Input de valor */}
      <div>
        <label className="text-sm text-white/60 mb-2 block">Valor da aposta</label>
        <div className="relative">
          <input
            type="number"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            min="0.1"
            step="0.1"
            placeholder="0.00"
            disabled={betPlaced}
            className="input pr-16 font-mono"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
            <Coins className="w-3.5 h-3.5 text-gold-400" />
            <span className="text-xs text-gold-400 font-bold">AUR</span>
          </div>
        </div>

        {/* Valores rápidos */}
        <div className="flex flex-wrap gap-2 mt-2">
          {QUICK_AMOUNTS.map(v => (
            <button
              key={v}
              onClick={() => setAmount(v.toString())}
              disabled={betPlaced}
              className={clsx(
                'px-2.5 py-1 rounded-md text-xs font-mono font-semibold transition-all',
                parseFloat(amount) === v
                  ? 'bg-gold-500/30 text-gold-400 border border-gold-500/50'
                  : 'bg-bg-elevated text-white/50 border border-bg-border hover:border-gold-500/30 hover:text-white/80',
              )}
            >
              {v}
            </button>
          ))}
          <button
            onClick={() => setAmount((balance / 2).toFixed(2))}
            disabled={betPlaced}
            className="px-2.5 py-1 rounded-md text-xs font-semibold bg-bg-elevated text-white/50 border border-bg-border hover:border-gold-500/30 transition-all"
          >
            ½
          </button>
          <button
            onClick={() => setAmount(balance.toFixed(2))}
            disabled={betPlaced}
            className="px-2.5 py-1 rounded-md text-xs font-semibold bg-bg-elevated text-white/50 border border-bg-border hover:border-gold-500/30 transition-all"
          >
            MAX
          </button>
        </div>
      </div>

      {/* Auto cashout */}
      <div>
        <label className="flex items-center gap-2 cursor-pointer mb-2">
          <div
            onClick={() => setIsAutoCashout(!isAutoCashout)}
            className={clsx(
              'w-10 h-5 rounded-full transition-all relative',
              isAutoCashout ? 'bg-gold-500' : 'bg-bg-elevated border border-bg-border',
            )}
          >
            <div className={clsx('absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all', isAutoCashout ? 'left-5' : 'left-0.5')} />
          </div>
          <span className="text-sm text-white/60">Auto Cashout</span>
        </label>

        <AnimatePresence>
          {isAutoCashout && (
            <motion.input
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              type="number"
              value={autoCashout}
              onChange={e => setAutoCashout(e.target.value)}
              min="1.01"
              step="0.01"
              placeholder="Ex: 2.00"
              disabled={betPlaced}
              className="input font-mono"
            />
          )}
        </AnimatePresence>
      </div>

      {/* Lucro potencial */}
      {amountNum > 0 && gameState === 'RUNNING' && betPlaced && !cashedOut && (
        <motion.div
          className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/20 rounded-lg"
          animate={{ borderColor: ['rgba(34,197,94,0.2)', 'rgba(34,197,94,0.5)', 'rgba(34,197,94,0.2)'] }}
          transition={{ duration: 1, repeat: Infinity }}
        >
          <span className="text-green-400/70 text-sm flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4" />
            Payout atual
          </span>
          <span className="font-mono font-bold text-green-400">
            {formatAur(potentialPayout)} AUR
          </span>
        </motion.div>
      )}

      {/* Botão principal */}
      {canCashout ? (
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleCashout}
          disabled={loading}
          className="w-full py-4 rounded-xl font-display font-black text-xl bg-green-500 hover:bg-green-400 text-white transition-all disabled:opacity-50 shadow-lg"
          style={{ boxShadow: '0 4px 30px rgba(34,197,94,0.4)' }}
          animate={{ boxShadow: ['0 4px 20px rgba(34,197,94,0.3)', '0 4px 40px rgba(34,197,94,0.6)', '0 4px 20px rgba(34,197,94,0.3)'] }}
          transition={{ duration: 1, repeat: Infinity }}
        >
          💸 SACAR {multiplier.toFixed(2)}x
        </motion.button>
      ) : (
        <motion.button
          whileHover={canBet ? { scale: 1.02 } : {}}
          whileTap={canBet ? { scale: 0.98 } : {}}
          onClick={handleBet}
          disabled={!canBet || loading}
          className={clsx(
            'w-full py-4 rounded-xl font-display font-black text-lg transition-all',
            canBet
              ? 'bg-gold-gradient text-black shadow-lg cursor-pointer'
              : 'bg-bg-elevated text-white/30 cursor-not-allowed',
          )}
          style={canBet ? { boxShadow: '0 4px 20px rgba(245,158,11,0.3)' } : {}}
        >
          {betPlaced ? (
            gameState === 'WAITING' ? '⏳ Aguardando início...' :
            gameState === 'CRASHED' ? '💥 Perdido' : '🎰 Apostado!'
          ) : gameState !== 'WAITING' ? (
            '⏳ Aguarde o próximo round'
          ) : (
            `APOSTAR ${amountNum > 0 ? formatAur(amountNum) + ' AUR' : ''}`
          )}
        </motion.button>
      )}

      {/* Info */}
      <p className="text-xs text-white/20 text-center">
        Saque antes do crash para ganhar. RNG Provably Fair.
      </p>
    </div>
  );
}

function AnimatePresence({ children }: any) {
  return children;
}
