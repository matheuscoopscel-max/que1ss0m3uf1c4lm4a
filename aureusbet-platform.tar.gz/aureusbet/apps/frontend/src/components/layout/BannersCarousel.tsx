'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import Image from 'next/image';
import Link from 'next/link';
import { api } from '@/lib/api/client';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export function BannersCarousel() {
  const [current, setCurrent] = useState(0);
  const { data: banners = [] } = useQuery<any[]>({
    queryKey: ['banners'],
    queryFn:  () => api.get('/admin/config/banners') as any,
    retry: false,
  });

  const active = banners.filter(b => b.isActive);

  useEffect(() => {
    if (active.length <= 1) return;
    const timer = setInterval(() => setCurrent(c => (c + 1) % active.length), 5000);
    return () => clearInterval(timer);
  }, [active.length]);

  if (!active.length) {
    return (
      <div className="w-full h-40 rounded-2xl bg-gradient-to-r from-gold-500/20 via-purple-500/10 to-gold-500/20 border border-gold-500/20 flex items-center justify-center mb-6">
        <div className="text-center">
          <p className="font-display font-black text-2xl text-gradient">🎰 AureusBet</p>
          <p className="text-white/50 text-sm mt-1">Cassino Crypto Premium · Token AUR</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-44 rounded-2xl overflow-hidden mb-6 group">
      <AnimatePresence mode="wait">
        {active[current] && (
          <motion.div
            key={current}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            className="absolute inset-0"
          >
            {active[current].linkUrl ? (
              <Link href={active[current].linkUrl} className="block w-full h-full">
                <Image src={active[current].imageUrl} alt={active[current].title} fill className="object-cover" />
              </Link>
            ) : (
              <Image src={active[current].imageUrl} alt={active[current].title} fill className="object-cover" />
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {active.length > 1 && (
        <>
          <button onClick={() => setCurrent(c => (c - 1 + active.length) % active.length)}
            className="absolute left-2 top-1/2 -translate-y-1/2 btn-icon opacity-0 group-hover:opacity-100 transition-opacity">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button onClick={() => setCurrent(c => (c + 1) % active.length)}
            className="absolute right-2 top-1/2 -translate-y-1/2 btn-icon opacity-0 group-hover:opacity-100 transition-opacity">
            <ChevronRight className="w-4 h-4" />
          </button>
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {active.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)}
                className={`rounded-full transition-all ${i === current ? 'w-4 h-1.5 bg-gold-400' : 'w-1.5 h-1.5 bg-white/40'}`} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
