'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { useAuthStore } from '@/store/auth.store';
import { Rocket, Coins, Zap, Shield } from 'lucide-react';

export function HeroSection() {
  const { user } = useAuthStore();
  if (user) return null;

  return (
    <section className="relative py-8 mb-6 overflow-hidden rounded-2xl border border-bg-border bg-card-gradient">
      <div className="absolute inset-0 bg-gradient-to-r from-gold-500/5 via-transparent to-purple-500/5" />
      <div className="relative px-6 md:px-8 flex flex-col md:flex-row items-center gap-6">
        <div className="flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-3">
            <span className="badge-gold w-fit">🎰 Cassino Crypto #1 do Brasil</span>
            <h1 className="font-display font-black text-3xl md:text-4xl text-white leading-tight">
              Jogue com <span className="text-gradient">AUR</span> na Blockchain
            </h1>
            <p className="text-white/60 text-sm md:text-base max-w-lg">
              Crash, Roleta, Blackjack e muito mais. Resultados verificáveis na Polygon. Ganhe colecionáveis exclusivos.
            </p>
            <div className="flex flex-wrap gap-3 mt-2">
              {[
                { icon: Shield, text: 'Provably Fair' },
                { icon: Coins,  text: 'Token AUR' },
                { icon: Zap,    text: 'Saque rápido' },
              ].map(f => (
                <div key={f.text} className="flex items-center gap-1.5 text-xs text-white/50">
                  <f.icon className="w-3.5 h-3.5 text-gold-400" />
                  {f.text}
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-3">
              <Link href="/auth/register" className="btn-gold px-6 py-2.5 text-sm">
                <Zap className="w-4 h-4" /> Ganhar 25 AUR
              </Link>
              <Link href="/crash" className="btn-ghost px-6 py-2.5 text-sm">
                <Rocket className="w-4 h-4" /> Jogar Crash
              </Link>
            </div>
          </motion.div>
        </div>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="hidden md:block"
        >
          <div className="relative w-48 h-48">
            <div className="absolute inset-0 bg-gold-500/20 rounded-full blur-3xl animate-pulse" />
            <div className="relative w-48 h-48 bg-gold-gradient rounded-full flex items-center justify-center shadow-2xl"
              style={{ boxShadow: '0 0 60px rgba(245,158,11,0.5)' }}>
              <Coins className="w-24 h-24 text-black/80" />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
