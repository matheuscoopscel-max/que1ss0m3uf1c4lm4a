'use client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { api } from '@/lib/api/client';
import { Users, TrendingUp, Coins, Zap } from 'lucide-react';

export function StatsBar() {
  const { data: stats } = useQuery({
    queryKey: ['platform-stats'],
    queryFn:  () => api.get('/admin/realtime') as any,
    refetchInterval: 10000,
    retry: false,
  });

  const items = [
    { icon: Users,      label: 'Online',       value: stats?.activeSessions ?? '—',       color: 'text-green-400' },
    { icon: Zap,        label: 'Apostas/hora', value: stats?.betsLastHour ?? '—',          color: 'text-blue-400' },
    { icon: Coins,      label: 'Volume/hora',  value: stats?.depositsLastHour ?? '—',      color: 'text-gold-400' },
    { icon: TrendingUp, label: 'AUR/BRL',      value: '1.00',                              color: 'text-purple-400' },
  ];

  return (
    <div className="bg-bg-secondary/50 border-b border-bg-border px-4 py-1.5 overflow-x-auto">
      <div className="flex items-center gap-6 max-w-[1600px] mx-auto min-w-max">
        <span className="text-xs font-bold text-gold-400/60 uppercase tracking-wider flex-shrink-0">AureusBet</span>
        {items.map((item, i) => (
          <div key={item.label} className="flex items-center gap-1.5 text-xs flex-shrink-0">
            <item.icon className={`w-3 h-3 ${item.color}`} />
            <span className="text-white/40">{item.label}:</span>
            <span className={`font-mono font-bold ${item.color}`}>{item.value}</span>
          </div>
        ))}
        <div className="flex items-center gap-1.5 text-xs text-green-400/60 flex-shrink-0">
          <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
          Ao Vivo
        </div>
      </div>
    </div>
  );
}
