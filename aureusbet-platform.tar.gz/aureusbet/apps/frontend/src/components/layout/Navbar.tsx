'use client';
import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore }   from '@/store/auth.store';
import { useWalletStore } from '@/store/wallet.store';
import { WalletMenu }     from '@/components/wallet/WalletMenu';
import { UserMenu }       from '@/components/ui/UserMenu';
import { NotificationBell } from '@/components/ui/NotificationBell';
import { formatAur }      from '@/lib/utils/format';
import { Coins, Menu, X, Zap } from 'lucide-react';
import { clsx } from 'clsx';

export function Navbar() {
  const { user } = useAuthStore();
  const { aurBalance } = useWalletStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [walletOpen, setWalletOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-bg-secondary/95 backdrop-blur-xl border-b border-bg-border">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6 max-w-[1600px] mx-auto">

        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="relative w-9 h-9">
            <div className="absolute inset-0 bg-gold-500/20 rounded-lg blur-md group-hover:bg-gold-500/40 transition-all" />
            <div className="relative w-9 h-9 bg-gold-gradient rounded-lg flex items-center justify-center">
              <Coins className="w-5 h-5 text-black" />
            </div>
          </div>
          <span className="font-display font-bold text-xl text-gradient hidden sm:block">
            AureusBet
          </span>
        </Link>

        {/* Centro — Links */}
        <div className="hidden md:flex items-center gap-1">
          {[
            { href: '/games',       label: 'Jogos',    icon: '🎮' },
            { href: '/crash',       label: 'Crash',    icon: '🚀' },
            { href: '/market',      label: 'Mercado',  icon: '🛒' },
            { href: '/promotions',  label: 'Promoções', icon: '🎁' },
          ].map(link => (
            <Link
              key={link.href}
              href={link.href}
              className="px-3 py-2 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-bg-elevated transition-all flex items-center gap-1.5"
            >
              <span>{link.icon}</span>
              {link.label}
            </Link>
          ))}
        </div>

        {/* Direita */}
        <div className="flex items-center gap-2">
          {user ? (
            <>
              {/* Saldo AUR */}
              <button
                onClick={() => setWalletOpen(true)}
                className="flex items-center gap-2 px-3 py-2 bg-bg-elevated border border-gold-500/20 rounded-lg hover:border-gold-500/40 transition-all group"
              >
                <div className="w-5 h-5 bg-gold-gradient rounded-full flex items-center justify-center">
                  <Coins className="w-3 h-3 text-black" />
                </div>
                <span className="font-mono font-bold text-sm text-gold-400 group-hover:text-neon-gold transition-colors">
                  {formatAur(aurBalance)}
                </span>
                <span className="text-xs text-white/40">AUR</span>
              </button>

              <NotificationBell />
              <UserMenu />
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Link href="/auth/login" className="btn-ghost text-sm px-4 py-2">
                Entrar
              </Link>
              <Link href="/auth/register" className="btn-gold text-sm px-4 py-2">
                <Zap className="w-4 h-4" />
                Cadastrar
              </Link>
            </div>
          )}

          {/* Mobile menu */}
          <button
            className="md:hidden btn-icon"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Wallet Modal */}
      <AnimatePresence>
        {walletOpen && <WalletMenu onClose={() => setWalletOpen(false)} />}
      </AnimatePresence>
    </nav>
  );
}
