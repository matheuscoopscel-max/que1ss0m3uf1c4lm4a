'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Rocket, LayoutGrid, Dice1, Coins, Trophy, BarChart3, Gift, HelpCircle } from 'lucide-react';
import { clsx } from 'clsx';

const NAV = [
  { href: '/',         label: 'Início',     icon: LayoutGrid },
  { href: '/crash',    label: 'Crash',      icon: Rocket },
  { href: '/dice',     label: 'Dado',       icon: Dice1 },
  { href: '/market',   label: 'Mercado',    icon: Coins },
  { href: '/leaderboard', label: 'Ranking', icon: Trophy },
  { href: '/affiliate',   label: 'Afiliados', icon: BarChart3 },
  { href: '/promotions',  label: 'Promoções', icon: Gift },
  { href: '/support',     label: 'Suporte',   icon: HelpCircle },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden lg:flex flex-col w-16 xl:w-52 flex-shrink-0 border-r border-bg-border bg-bg-secondary/30 min-h-[calc(100vh-64px-36px)] p-2">
      {NAV.map(item => {
        const active = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={clsx(
              'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all mb-0.5',
              active
                ? 'bg-gold-500/15 text-gold-400 border border-gold-500/25'
                : 'text-white/50 hover:text-white/80 hover:bg-bg-elevated',
            )}
          >
            <item.icon className={clsx('w-5 h-5 flex-shrink-0', active ? 'text-gold-400' : 'text-white/40')} />
            <span className="hidden xl:block">{item.label}</span>
          </Link>
        );
      })}
    </aside>
  );
}
