'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth.store';
import { User, Settings, LogOut, Shield, Package, ShoppingBag, ChevronDown } from 'lucide-react';

export function UserMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const { user, logout } = useAuthStore();

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleLogout = async () => {
    await logout();
    router.push('/auth/login');
  };

  const MENU_ITEMS = [
    { href: '/profile',   icon: User,       label: 'Meu Perfil' },
    { href: '/inventory', icon: Package,     label: 'Inventário' },
    { href: '/market',    icon: ShoppingBag, label: 'Mercado' },
    { href: '/settings',  icon: Settings,    label: 'Configurações' },
    { href: '/settings/security', icon: Shield, label: 'Segurança' },
  ];

  if (!user) return null;

  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-bg-elevated transition-all">
        <div className="w-8 h-8 rounded-full overflow-hidden bg-gold-500/20 flex items-center justify-center border border-gold-500/30">
          {user.avatarUrl
            ? <Image src={user.avatarUrl} alt={user.username} width={32} height={32} className="object-cover" />
            : <User className="w-4 h-4 text-gold-400" />
          }
        </div>
        <span className="hidden sm:block text-sm font-medium text-white/80 max-w-[100px] truncate">
          {user.displayName ?? user.username}
        </span>
        <ChevronDown className={`w-3.5 h-3.5 text-white/40 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -8 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 top-full mt-2 w-52 bg-bg-card border border-bg-border rounded-xl shadow-2xl overflow-hidden z-50"
          >
            {/* Header */}
            <div className="px-4 py-3 bg-bg-elevated border-b border-bg-border">
              <p className="font-semibold text-white text-sm truncate">{user.displayName ?? user.username}</p>
              <p className="text-white/40 text-xs truncate">{user.email}</p>
              {user.role !== 'PLAYER' && (
                <span className="badge-gold text-[10px] mt-1">{user.role}</span>
              )}
            </div>

            {/* Links */}
            <div className="py-1">
              {MENU_ITEMS.map(item => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-3 px-4 py-2.5 text-sm text-white/70 hover:text-white hover:bg-bg-elevated transition-all"
                >
                  <item.icon className="w-4 h-4 text-white/40" />
                  {item.label}
                </Link>
              ))}
            </div>

            {/* Logout */}
            <div className="border-t border-bg-border py-1">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10 transition-all"
              >
                <LogOut className="w-4 h-4" />
                Sair da conta
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
