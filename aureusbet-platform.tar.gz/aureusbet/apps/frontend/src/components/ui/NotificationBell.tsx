'use client';
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api/client';

interface Notification { id: string; type: string; title: string; body: string; isRead: boolean; createdAt: string; }

export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const qc  = useQueryClient();

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const { data: notifs = [] } = useQuery<Notification[]>({
    queryKey: ['notifications'],
    queryFn:  () => api.get('/users/notifications') as any,
    refetchInterval: 30000,
  });

  const unread = notifs.filter(n => !n.isRead).length;

  const markRead = useMutation({
    mutationFn: (id: string) => api.patch(`/users/notifications/${id}/read`),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ['notifications'] }),
  });

  const typeIcons: Record<string, string> = {
    SYSTEM: '⚙️', PROMOTION: '🎁', TRANSACTION: '💰',
    GAME: '🎮', KYC: '📋', SECURITY: '🔒', SUPPORT: '💬',
  };

  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(!open)} className="btn-icon relative">
        <Bell className="w-5 h-5" />
        {unread > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center"
          >
            {unread > 9 ? '9+' : unread}
          </motion.span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -8 }}
            className="absolute right-0 top-full mt-2 w-80 bg-bg-card border border-bg-border rounded-xl shadow-2xl overflow-hidden z-50"
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-bg-border bg-bg-elevated">
              <h3 className="font-semibold text-white text-sm">Notificações</h3>
              {unread > 0 && <span className="badge-red text-xs">{unread} novas</span>}
            </div>

            <div className="max-h-80 overflow-y-auto no-scrollbar">
              {notifs.length === 0 ? (
                <div className="p-6 text-center text-white/30 text-sm">Nenhuma notificação</div>
              ) : (
                notifs.slice(0, 15).map(n => (
                  <div
                    key={n.id}
                    onClick={() => !n.isRead && markRead.mutate(n.id)}
                    className={`flex gap-3 px-4 py-3 border-b border-bg-border/50 cursor-pointer hover:bg-bg-elevated transition-all ${!n.isRead ? 'bg-gold-500/5' : ''}`}
                  >
                    <span className="text-xl mt-0.5">{typeIcons[n.type] ?? '📢'}</span>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium truncate ${n.isRead ? 'text-white/60' : 'text-white'}`}>{n.title}</p>
                      <p className="text-xs text-white/40 line-clamp-2 mt-0.5">{n.body}</p>
                    </div>
                    {!n.isRead && <div className="w-2 h-2 bg-gold-400 rounded-full mt-1.5 flex-shrink-0" />}
                  </div>
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
