import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { api } from '@/lib/api/client';
import { toast } from 'react-toastify';

interface User {
  id:             string;
  username:       string;
  email:          string;
  displayName?:   string;
  avatarUrl?:     string;
  role:           string;
  status:         string;
  kycStatus:      string;
  twoFaEnabled:   boolean;
  wallet?:        { aurBalance: number; brlBalance: number; polygonAddress?: string };
}

interface AuthState {
  user:           User | null;
  accessToken:    string | null;
  isLoading:      boolean;
  requiresTwoFa:  boolean;
  tempToken:      string | null;

  login:          (email: string, password: string) => Promise<void>;
  verifyTwoFa:    (code: string) => Promise<void>;
  logout:         () => Promise<void>;
  register:       (data: any) => Promise<void>;
  refreshProfile: () => Promise<void>;
  setToken:       (token: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user:          null,
      accessToken:   null,
      isLoading:     false,
      requiresTwoFa: false,
      tempToken:     null,

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const res: any = await api.post('/auth/login', { email, password });

          if (res.requiresTwoFa) {
            set({ requiresTwoFa: true, tempToken: res.tempToken, isLoading: false });
            return;
          }

          localStorage.setItem('access_token', res.accessToken);
          set({ accessToken: res.accessToken, isLoading: false });
          await get().refreshProfile();
        } catch (err: any) {
          set({ isLoading: false });
          throw err;
        }
      },

      verifyTwoFa: async (code) => {
        const { tempToken } = get();
        set({ isLoading: true });
        try {
          const res: any = await api.post('/auth/2fa/verify', { code }, {
            headers: { 'x-temp-token': tempToken! },
          } as any);
          localStorage.setItem('access_token', res.accessToken);
          set({ accessToken: res.accessToken, requiresTwoFa: false, tempToken: null, isLoading: false });
          await get().refreshProfile();
        } catch (err) {
          set({ isLoading: false });
          throw err;
        }
      },

      logout: async () => {
        try {
          await api.post('/auth/logout');
        } finally {
          localStorage.removeItem('access_token');
          set({ user: null, accessToken: null, requiresTwoFa: false });
        }
      },

      register: async (data) => {
        set({ isLoading: true });
        try {
          await api.post('/auth/register', data);
          set({ isLoading: false });
        } catch (err) {
          set({ isLoading: false });
          throw err;
        }
      },

      refreshProfile: async () => {
        try {
          const user: any = await api.get('/users/me');
          set({ user });
        } catch { /* token inválido — ignorar */ }
      },

      setToken: (token) => {
        localStorage.setItem('access_token', token);
        set({ accessToken: token });
      },
    }),
    {
      name:    'auth-store',
      storage: createJSONStorage(() => localStorage),
      partialize: state => ({ accessToken: state.accessToken }),
    },
  ),
);
