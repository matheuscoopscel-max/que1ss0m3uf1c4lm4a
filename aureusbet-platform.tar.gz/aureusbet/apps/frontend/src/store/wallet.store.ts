import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { api } from '@/lib/api/client';

interface WalletState {
  aurBalance:    number;
  brlBalance:    number;
  lockedBalance: number;
  isLoading:     boolean;

  fetchBalance:  () => Promise<void>;
  updateBalance: (currency: 'AUR' | 'BRL', amount: number) => void;
}

export const useWalletStore = create<WalletState>()(
  subscribeWithSelector((set, get) => ({
    aurBalance:    0,
    brlBalance:    0,
    lockedBalance: 0,
    isLoading:     false,

    fetchBalance: async () => {
      set({ isLoading: true });
      try {
        const data: any = await api.get('/payments/balance');
        set({ aurBalance: data.aurBalance, brlBalance: data.brlBalance, lockedBalance: data.lockedBalance, isLoading: false });
      } catch { set({ isLoading: false }); }
    },

    updateBalance: (currency, amount) => {
      if (currency === 'AUR') set(s => ({ aurBalance: Math.max(0, s.aurBalance + amount) }));
      else set(s => ({ brlBalance: Math.max(0, s.brlBalance + amount) }));
    },
  })),
);
