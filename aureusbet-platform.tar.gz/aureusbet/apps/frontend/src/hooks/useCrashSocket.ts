import { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:3001';

interface CrashCallbacks {
  onWaiting?:      (data: any) => void;
  onStarted?:      (data: any) => void;
  onTick?:         (data: any) => void;
  onCrashed?:      (data: any) => void;
  onPlayerBet?:    (data: any) => void;
  onPlayerCashout?: (data: any) => void;
}

export function useCrashSocket(callbacks: CrashCallbacks) {
  const socketRef  = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('access_token');

    const socket = io(`${WS_URL}/game`, {
      auth:       { token },
      transports: ['websocket'],
    });

    socketRef.current = socket;

    socket.on('connect',    () => { setConnected(true); socket.emit('join:crash'); });
    socket.on('disconnect', () => setConnected(false));

    socket.on('crash:waiting',         callbacks.onWaiting     ?? (() => {}));
    socket.on('crash:started',         callbacks.onStarted     ?? (() => {}));
    socket.on('crash:tick',            callbacks.onTick        ?? (() => {}));
    socket.on('crash:crashed',         callbacks.onCrashed     ?? (() => {}));
    socket.on('crash:player_bet',      callbacks.onPlayerBet   ?? (() => {}));
    socket.on('crash:player_cashout',  callbacks.onPlayerCashout ?? (() => {}));

    return () => { socket.disconnect(); };
  }, []);

  return { socket: socketRef.current, connected };
}
