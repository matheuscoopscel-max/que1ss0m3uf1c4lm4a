/**
 * Formata valor AUR — ex: 1234.5678 → "1,234.57"
 */
export function formatAur(value: number, decimals = 2): string {
  if (isNaN(value) || value === null || value === undefined) return '0.00';
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
}

/**
 * Formata valor BRL — ex: 1234.5 → "R$ 1.234,50"
 */
export function formatBrl(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style:    'currency',
    currency: 'BRL',
  }).format(value);
}

/**
 * Formata data relativa — ex: "2 horas atrás"
 */
export function formatRelativeTime(date: Date | string): string {
  const d     = typeof date === 'string' ? new Date(date) : date;
  const diff  = Date.now() - d.getTime();
  const secs  = Math.floor(diff / 1000);
  const mins  = Math.floor(secs  / 60);
  const hours = Math.floor(mins  / 60);
  const days  = Math.floor(hours / 24);

  if (secs  < 60)  return 'agora';
  if (mins  < 60)  return `${mins}min`;
  if (hours < 24)  return `${hours}h`;
  if (days  < 7)   return `${days}d`;
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

/**
 * Abrevia endereço Polygon — ex: "0x1234...5678"
 */
export function formatAddress(addr: string): string {
  if (!addr || addr.length < 10) return addr;
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

/**
 * Cor do multiplicador crash
 */
export function crashMultiplierColor(mult: number): string {
  if (mult < 1.5) return '#ef4444';
  if (mult < 2)   return '#f97316';
  if (mult < 5)   return '#22c55e';
  if (mult < 10)  return '#3b82f6';
  return '#a855f7';
}
