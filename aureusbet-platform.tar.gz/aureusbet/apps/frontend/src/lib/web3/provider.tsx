'use client';
import { ReactNode } from 'react';
import { createWeb3Modal } from '@web3modal/wagmi/react';
import { defaultWagmiConfig } from '@web3modal/wagmi/react/config';
import { WagmiProvider, http } from 'wagmi';
import { polygon } from 'wagmi/chains';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const projectId = process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID ?? '';

const metadata = {
  name:        'AureusBet',
  description: 'Cassino Crypto com Token AUR na Polygon',
  url:         process.env.NEXT_PUBLIC_APP_URL ?? 'https://app.aureusbet.com',
  icons:       ['https://app.aureusbet.com/logo.png'],
};

const config = defaultWagmiConfig({
  chains:   [polygon],
  projectId,
  metadata,
  transports: { [polygon.id]: http(process.env.NEXT_PUBLIC_POLYGON_RPC ?? 'https://polygon-rpc.com') },
  ssr: true,
});

createWeb3Modal({
  wagmiConfig: config,
  projectId,
  themeMode:   'dark',
  themeVariables: {
    '--w3m-accent': '#f59e0b',
    '--w3m-border-radius-master': '12px',
  },
  featuredWalletIds: [],
});

const qc = new QueryClient();

export function Web3Provider({ children }: { children: ReactNode }) {
  return (
    <WagmiProvider config={config}>
      <QueryClientProvider client={qc}>{children}</QueryClientProvider>
    </WagmiProvider>
  );
}
