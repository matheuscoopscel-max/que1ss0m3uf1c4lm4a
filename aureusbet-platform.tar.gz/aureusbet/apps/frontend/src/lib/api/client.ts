import axios, { AxiosInstance, InternalAxiosRequestConfig, AxiosError } from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';

let isRefreshing = false;
let failedQueue: Array<{ resolve: (val: string) => void; reject: (err: any) => void }> = [];

function processQueue(error: any, token: string | null) {
  failedQueue.forEach(p => error ? p.reject(error) : p.resolve(token!));
  failedQueue = [];
}

export function createApiClient(): AxiosInstance {
  const client = axios.create({
    baseURL:         API_URL,
    withCredentials: true,
    timeout:         15000,
    headers:         { 'Content-Type': 'application/json' },
  });

  // Request: injetar token
  client.interceptors.request.use((config: InternalAxiosRequestConfig) => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('access_token');
      if (token) config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });

  // Response: refresh automático em 401
  client.interceptors.response.use(
    res => res.data?.data ?? res.data,
    async (error: AxiosError) => {
      const original = error.config as any;

      if (error.response?.status === 401 && !original._retry) {
        if (isRefreshing) {
          return new Promise((resolve, reject) => {
            failedQueue.push({ resolve, reject });
          }).then(token => {
            original.headers.Authorization = `Bearer ${token}`;
            return client(original);
          });
        }

        original._retry = true;
        isRefreshing    = true;

        try {
          const { data } = await axios.post(`${API_URL}/auth/refresh`, {}, { withCredentials: true });
          const newToken = data.data?.accessToken ?? data.accessToken;
          localStorage.setItem('access_token', newToken);
          processQueue(null, newToken);
          original.headers.Authorization = `Bearer ${newToken}`;
          return client(original);
        } catch (refreshError) {
          processQueue(refreshError, null);
          localStorage.removeItem('access_token');
          if (typeof window !== 'undefined') window.location.href = '/auth/login';
          return Promise.reject(refreshError);
        } finally {
          isRefreshing = false;
        }
      }

      return Promise.reject(error.response?.data ?? error);
    },
  );

  return client;
}

export const api = createApiClient();
