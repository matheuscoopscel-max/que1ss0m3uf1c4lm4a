import type { Metadata, Viewport } from 'next';
import { Inter, JetBrains_Mono, Sora } from 'next/font/google';
import { ThemeProvider } from 'next-themes';
import { ToastContainer } from 'react-toastify';
import { ReactQueryProvider } from '@/lib/api/query-provider';
import { Web3Provider }       from '@/lib/web3/provider';
import 'react-toastify/dist/ReactToastify.css';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

const sora = Sora({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
});

export const metadata: Metadata = {
  title: { default: 'AureusBet — Cassino Crypto', template: '%s | AureusBet' },
  description: 'Plataforma de apostas online com token AUR na blockchain Polygon. Crash, Roleta, Blackjack, Slots e mais.',
  keywords: ['cassino', 'crypto', 'apostas', 'AUR', 'Polygon', 'crash', 'provably fair'],
  authors: [{ name: 'AureusBet' }],
  robots: { index: true, follow: true },
  openGraph: {
    type: 'website',
    siteName: 'AureusBet',
    title: 'AureusBet — Cassino Crypto Premium',
    description: 'Apostas online com token AUR. Jogos provably fair na blockchain Polygon.',
  },
};

export const viewport: Viewport = {
  themeColor: '#f59e0b',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning className="dark">
      <body className={`${inter.variable} ${jetbrainsMono.variable} ${sora.variable}`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
          <ReactQueryProvider>
            <Web3Provider>
              {children}
              <ToastContainer
                position="bottom-right"
                theme="dark"
                toastClassName="!bg-bg-card !border !border-bg-border !text-white"
                progressClassName="!bg-gold-500"
              />
            </Web3Provider>
          </ReactQueryProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
