import { Metadata } from 'next';
import { CrashGame } from '@/components/games/crash/CrashGame';
import { Navbar }    from '@/components/layout/Navbar';

export const metadata: Metadata = { title: 'Crash — AureusBet' };

export default function CrashPage() {
  return (
    <div className="min-h-screen bg-bg-primary">
      <Navbar />
      <main className="p-4 lg:p-6">
        <CrashGame />
      </main>
    </div>
  );
}
