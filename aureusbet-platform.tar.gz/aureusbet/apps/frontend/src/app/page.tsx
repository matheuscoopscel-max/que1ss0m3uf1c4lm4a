import { Metadata } from 'next';
import { HeroSection }     from '@/components/layout/HeroSection';
import { GamesGrid }       from '@/components/games/GamesGrid';
import { LiveBetsFeed }    from '@/components/games/LiveBetsFeed';
import { StatsBar }        from '@/components/layout/StatsBar';
import { BannersCarousel } from '@/components/layout/BannersCarousel';
import { Navbar }          from '@/components/layout/Navbar';
import { Sidebar }         from '@/components/layout/Sidebar';

export const metadata: Metadata = {
  title: 'AureusBet — Cassino Crypto | Apostas com Token AUR',
};

export default function HomePage() {
  return (
    <div className="min-h-screen bg-bg-primary">
      <Navbar />
      <StatsBar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-4 lg:p-6 max-w-[1400px]">
          <BannersCarousel />
          <HeroSection />
          <GamesGrid />
          <LiveBetsFeed />
        </main>
      </div>
    </div>
  );
}
