'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuthStore } from '@/store/auth.store';
import { Eye, EyeOff, Coins, Lock, Mail, Loader2 } from 'lucide-react';
import { toast } from 'react-toastify';

const schema = z.object({
  email:    z.string().email('E-mail inválido'),
  password: z.string().min(1, 'Senha obrigatória'),
});

type FormData = z.infer<typeof schema>;

export default function LoginPage() {
  const router = useRouter();
  const { login, requiresTwoFa, verifyTwoFa, isLoading } = useAuthStore();
  const [showPass,    setShowPass]    = useState(false);
  const [twoFaCode,   setTwoFaCode]   = useState('');

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    try {
      await login(data.email, data.password);
      if (!requiresTwoFa) {
        toast.success('Bem-vindo de volta!');
        router.push('/');
      }
    } catch (err: any) {
      toast.error(err?.message ?? 'Credenciais inválidas.');
    }
  };

  const onVerify2fa = async () => {
    try {
      await verifyTwoFa(twoFaCode);
      toast.success('Autenticado com sucesso!');
      router.push('/');
    } catch {
      toast.error('Código 2FA inválido.');
    }
  };

  return (
    <div className="min-h-screen bg-bg-primary flex items-center justify-center p-4">
      {/* Fundo decorativo */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-gold-500/5 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="flex flex-col items-center gap-3 mb-8">
          <div className="w-16 h-16 bg-gold-gradient rounded-2xl flex items-center justify-center shadow-2xl"
            style={{ boxShadow: '0 0 40px rgba(245,158,11,0.4)' }}>
            <Coins className="w-9 h-9 text-black" />
          </div>
          <h1 className="font-display font-bold text-3xl text-gradient">AureusBet</h1>
          <p className="text-white/40 text-sm">Cassino Crypto Premium</p>
        </div>

        <div className="card-glow p-6">
          {!requiresTwoFa ? (
            <>
              <h2 className="font-bold text-xl text-white mb-6">Entrar na sua conta</h2>

              <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
                {/* E-mail */}
                <div>
                  <label className="text-sm text-white/60 mb-1.5 block">E-mail</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                    <input
                      {...register('email')}
                      type="email"
                      placeholder="seu@email.com"
                      className={`input pl-9 ${errors.email ? 'input-error' : ''}`}
                    />
                  </div>
                  {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email.message}</p>}
                </div>

                {/* Senha */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-sm text-white/60">Senha</label>
                    <Link href="/auth/forgot-password" className="text-xs text-gold-400 hover:text-gold-300 transition-colors">
                      Esqueci a senha
                    </Link>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                    <input
                      {...register('password')}
                      type={showPass ? 'text' : 'password'}
                      placeholder="••••••••"
                      className={`input pl-9 pr-10 ${errors.password ? 'input-error' : ''}`}
                    />
                    <button type="button" onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password.message}</p>}
                </div>

                <motion.button
                  type="submit"
                  disabled={isLoading}
                  whileTap={{ scale: 0.98 }}
                  className="btn-gold w-full py-3 mt-2 text-base"
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Entrar'}
                </motion.button>
              </form>

              <p className="text-center text-white/40 text-sm mt-6">
                Não tem conta?{' '}
                <Link href="/auth/register" className="text-gold-400 hover:text-gold-300 font-medium transition-colors">
                  Cadastre-se grátis
                </Link>
              </p>
            </>
          ) : (
            /* 2FA */
            <div className="flex flex-col gap-4">
              <div className="text-center mb-2">
                <div className="w-14 h-14 bg-gold-500/20 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <Lock className="w-7 h-7 text-gold-400" />
                </div>
                <h2 className="font-bold text-xl text-white">Autenticação 2FA</h2>
                <p className="text-white/50 text-sm mt-1">Digite o código do seu app autenticador</p>
              </div>

              <input
                type="text"
                value={twoFaCode}
                onChange={e => setTwoFaCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="000000"
                className="input text-center text-2xl font-mono tracking-[0.4em]"
                maxLength={6}
              />

              <button onClick={onVerify2fa} disabled={twoFaCode.length < 6 || isLoading} className="btn-gold w-full py-3">
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Verificar'}
              </button>
            </div>
          )}
        </div>

        {/* Disclaimer */}
        <p className="text-center text-white/20 text-xs mt-6">
          Ao continuar, você confirma ter 18+ anos e aceitar os{' '}
          <Link href="/terms" className="text-white/40 hover:text-white/60 underline">Termos de Uso</Link>.
        </p>
      </motion.div>
    </div>
  );
}
