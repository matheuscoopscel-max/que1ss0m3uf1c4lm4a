'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuthStore } from '@/store/auth.store';
import { Coins, Eye, EyeOff, Loader2, CheckCircle2, ChevronRight } from 'lucide-react';
import { toast } from 'react-toastify';

const schema = z.object({
  username:        z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/, 'Apenas letras, números e _'),
  email:           z.string().email('E-mail inválido'),
  password:        z.string().min(8, 'Mínimo 8 caracteres')
                    .regex(/[A-Z]/, 'Precisa de maiúscula')
                    .regex(/[0-9]/, 'Precisa de número'),
  confirmPassword: z.string(),
  dateOfBirth:     z.string().min(1, 'Data de nascimento obrigatória'),
  cpf:             z.string().optional(),
  country:         z.string().min(2).max(2),
  termsAccepted:   z.literal(true, { errorMap: () => ({ message: 'Aceite os termos' }) }),
  gdprConsent:     z.boolean().optional(),
  marketingConsent: z.boolean().optional(),
}).refine(d => d.password === d.confirmPassword, {
  message: 'Senhas não coincidem',
  path: ['confirmPassword'],
});

type FormData = z.infer<typeof schema>;

const STEPS = ['Conta', 'Pessoal', 'Confirmação'];

export default function RegisterPage() {
  const router = useRouter();
  const { register: registerUser, isLoading } = useAuthStore();
  const [step,     setStep]     = useState(0);
  const [showPass, setShowPass] = useState(false);
  const [done,     setDone]     = useState(false);

  const { register, handleSubmit, trigger, formState: { errors }, watch } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { country: 'BR', gdprConsent: false, marketingConsent: false },
  });

  const nextStep = async () => {
    const fields: (keyof FormData)[][] = [
      ['username', 'email', 'password', 'confirmPassword'],
      ['dateOfBirth', 'country'],
    ];
    const valid = await trigger(fields[step]);
    if (valid) setStep(s => s + 1);
  };

  const onSubmit = async (data: FormData) => {
    try {
      await registerUser(data);
      setDone(true);
    } catch (err: any) {
      toast.error(err?.message ?? 'Erro no cadastro.');
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center p-4">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="card-glow p-8 max-w-md w-full text-center">
          <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 0.6 }} className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10 text-green-400" />
          </motion.div>
          <h2 className="font-display font-bold text-2xl text-white mb-2">Conta criada! 🎉</h2>
          <p className="text-white/60 mb-2">Verifique seu e-mail para ativar a conta.</p>
          <p className="text-gold-400 font-semibold text-sm mb-6">Você receberá <strong>25 AUR</strong> de bônus após verificar!</p>
          <Link href="/auth/login" className="btn-gold w-full py-3 justify-center flex">Ir para Login</Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-primary flex items-center justify-center p-4">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-gold-500/5 rounded-full blur-3xl" />
      </div>

      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        {/* Logo */}
        <div className="flex flex-col items-center gap-2 mb-6">
          <div className="w-14 h-14 bg-gold-gradient rounded-2xl flex items-center justify-center shadow-2xl"
            style={{ boxShadow: '0 0 30px rgba(245,158,11,0.4)' }}>
            <Coins className="w-8 h-8 text-black" />
          </div>
          <h1 className="font-display font-bold text-2xl text-gradient">Criar Conta</h1>
          <p className="text-white/40 text-xs">Ganhe 25 AUR de boas-vindas!</p>
        </div>

        {/* Steps */}
        <div className="flex items-center gap-0 mb-6">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center flex-1">
              <div className={`flex items-center gap-1.5 text-xs font-medium ${i <= step ? 'text-gold-400' : 'text-white/30'}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i < step ? 'bg-gold-500 text-black' : i === step ? 'bg-gold-500/20 border border-gold-500 text-gold-400' : 'bg-bg-elevated border border-bg-border text-white/30'}`}>
                  {i < step ? '✓' : i + 1}
                </div>
                <span className="hidden sm:inline">{s}</span>
              </div>
              {i < STEPS.length - 1 && <div className={`flex-1 h-px mx-2 ${i < step ? 'bg-gold-500/50' : 'bg-bg-border'}`} />}
            </div>
          ))}
        </div>

        <div className="card-glow p-6">
          <form onSubmit={handleSubmit(onSubmit)}>
            <AnimatePresence mode="wait">
              {/* STEP 0 — Conta */}
              {step === 0 && (
                <motion.div key="step0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-4">
                  <div>
                    <label className="text-sm text-white/60 mb-1.5 block">Nome de usuário</label>
                    <input {...register('username')} placeholder="seunick" className={`input ${errors.username ? 'input-error' : ''}`} />
                    {errors.username && <p className="text-red-400 text-xs mt-1">{errors.username.message}</p>}
                  </div>
                  <div>
                    <label className="text-sm text-white/60 mb-1.5 block">E-mail</label>
                    <input {...register('email')} type="email" placeholder="seu@email.com" className={`input ${errors.email ? 'input-error' : ''}`} />
                    {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email.message}</p>}
                  </div>
                  <div>
                    <label className="text-sm text-white/60 mb-1.5 block">Senha</label>
                    <div className="relative">
                      <input {...register('password')} type={showPass ? 'text' : 'password'} placeholder="••••••••" className={`input pr-10 ${errors.password ? 'input-error' : ''}`} />
                      <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30">
                        {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password.message}</p>}
                  </div>
                  <div>
                    <label className="text-sm text-white/60 mb-1.5 block">Confirmar senha</label>
                    <input {...register('confirmPassword')} type="password" placeholder="••••••••" className={`input ${errors.confirmPassword ? 'input-error' : ''}`} />
                    {errors.confirmPassword && <p className="text-red-400 text-xs mt-1">{errors.confirmPassword.message}</p>}
                  </div>
                  <button type="button" onClick={nextStep} className="btn-gold w-full py-3 mt-2 justify-center flex gap-2">
                    Próximo <ChevronRight className="w-4 h-4" />
                  </button>
                </motion.div>
              )}

              {/* STEP 1 — Pessoal */}
              {step === 1 && (
                <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-4">
                  <div>
                    <label className="text-sm text-white/60 mb-1.5 block">Data de nascimento <span className="text-red-400">*</span></label>
                    <input {...register('dateOfBirth')} type="date" className={`input ${errors.dateOfBirth ? 'input-error' : ''}`} />
                    {errors.dateOfBirth && <p className="text-red-400 text-xs mt-1">{errors.dateOfBirth.message}</p>}
                    <p className="text-white/30 text-xs mt-1">Você precisa ter 18 anos ou mais.</p>
                  </div>
                  <div>
                    <label className="text-sm text-white/60 mb-1.5 block">CPF (opcional)</label>
                    <input {...register('cpf')} placeholder="000.000.000-00" className="input" />
                  </div>
                  <div>
                    <label className="text-sm text-white/60 mb-1.5 block">País</label>
                    <select {...register('country')} className="input">
                      <option value="BR">🇧🇷 Brasil</option>
                      <option value="US">🇺🇸 Estados Unidos</option>
                      <option value="PT">🇵🇹 Portugal</option>
                      <option value="AR">🇦🇷 Argentina</option>
                    </select>
                  </div>
                  <div className="flex gap-3 mt-2">
                    <button type="button" onClick={() => setStep(0)} className="btn-ghost flex-1 py-3 justify-center flex">Voltar</button>
                    <button type="button" onClick={nextStep} className="btn-gold flex-1 py-3 justify-center flex gap-2">
                      Próximo <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              )}

              {/* STEP 2 — Confirmação */}
              {step === 2 && (
                <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-4">
                  {/* Bônus destaque */}
                  <div className="p-4 bg-gold-500/10 border border-gold-500/30 rounded-xl text-center">
                    <div className="text-3xl font-black text-gold-400">25 AUR</div>
                    <div className="text-xs text-white/60 mt-1">Bônus de boas-vindas após verificar o e-mail</div>
                  </div>

                  <label className="flex items-start gap-3 cursor-pointer">
                    <input {...register('termsAccepted')} type="checkbox" className="mt-0.5 rounded accent-gold-500" />
                    <span className="text-sm text-white/60">
                      Confirmo ter 18+ anos, li e aceito os{' '}
                      <Link href="/terms" className="text-gold-400 hover:underline">Termos de Uso</Link> e{' '}
                      <Link href="/privacy" className="text-gold-400 hover:underline">Política de Privacidade</Link>.
                    </span>
                  </label>
                  {errors.termsAccepted && <p className="text-red-400 text-xs">{errors.termsAccepted.message}</p>}

                  <label className="flex items-start gap-3 cursor-pointer">
                    <input {...register('gdprConsent')} type="checkbox" className="mt-0.5 rounded accent-gold-500" />
                    <span className="text-sm text-white/60">Consinto com o tratamento dos meus dados (LGPD/GDPR)</span>
                  </label>

                  <label className="flex items-start gap-3 cursor-pointer">
                    <input {...register('marketingConsent')} type="checkbox" className="mt-0.5 rounded accent-gold-500" />
                    <span className="text-sm text-white/60">Quero receber promoções e novidades por e-mail</span>
                  </label>

                  <div className="flex gap-3 mt-2">
                    <button type="button" onClick={() => setStep(1)} className="btn-ghost flex-1 py-3 justify-center flex">Voltar</button>
                    <button type="submit" disabled={isLoading} className="btn-gold flex-1 py-3 justify-center flex">
                      {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : '🚀 Criar Conta'}
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </form>

          <p className="text-center text-white/40 text-sm mt-5">
            Já tem conta?{' '}
            <Link href="/auth/login" className="text-gold-400 hover:text-gold-300 font-medium">Entrar</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
