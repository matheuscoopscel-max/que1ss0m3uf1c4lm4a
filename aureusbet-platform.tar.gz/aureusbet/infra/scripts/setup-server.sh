#!/usr/bin/env bash
# ================================================================
# AureusBet — Setup inicial de servidor Ubuntu 22.04/24.04
# Execute como root: curl ... | bash
# ================================================================
set -euo pipefail

log() { echo -e "\033[1;34m[SETUP] $*\033[0m"; }

log "Atualizando sistema..."
apt-get update && apt-get upgrade -y

log "Instalando dependências..."
apt-get install -y curl wget git ufw fail2ban certbot python3-certbot-nginx \
  build-essential htop unzip software-properties-common

log "Instalando Docker..."
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker
usermod -aG docker $SUDO_USER 2>/dev/null || true

log "Instalando Docker Compose v2..."
apt-get install -y docker-compose-plugin

log "Instalando Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

log "Configurando UFW..."
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

log "Configurando Fail2Ban..."
cat > /etc/fail2ban/jail.local << 'FAIL2BAN'
[DEFAULT]
bantime  = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port    = ssh

[nginx-http-auth]
enabled = true

[nginx-limit-req]
enabled  = true
filter   = nginx-limit-req
logpath  = /var/log/nginx/error.log
maxretry = 10
FAIL2BAN
systemctl enable fail2ban
systemctl restart fail2ban

log "Configurando limites do sistema..."
cat >> /etc/sysctl.conf << 'SYSCTL'
net.core.somaxconn = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.ip_local_port_range = 1024 65535
vm.overcommit_memory = 1
SYSCTL
sysctl -p

log "✅ Servidor configurado! Execute o deploy com ./infra/scripts/deploy.sh"
