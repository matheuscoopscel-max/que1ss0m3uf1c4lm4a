#!/usr/bin/env bash
# ================================================================
# AureusBet — Script de Deploy em Produção
# Uso: ./deploy.sh [TAG]
# ================================================================
set -euo pipefail
IFS=$'\n\t'

TAG=${1:-$(git describe --tags --abbrev=0 2>/dev/null || echo "latest")}
COMPOSE_FILE="./infra/docker/docker-compose.prod.yml"
ENV_FILE=".env"

log() { echo -e "\033[1;34m[$(date '+%T')] $*\033[0m"; }
ok()  { echo -e "\033[1;32m✓ $*\033[0m"; }
err() { echo -e "\033[1;31m✗ $*\033[0m" >&2; exit 1; }

log "Deploy AureusBet — TAG: $TAG"

# 1. Verificar .env
[ -f "$ENV_FILE" ] || err ".env não encontrado. Copie .env.example e preencha os valores."
grep -qE "^JWT_SECRET=.{32}" "$ENV_FILE" || err "JWT_SECRET inseguro no .env"
grep -qE "^ENCRYPTION_KEY=.{32}" "$ENV_FILE" || err "ENCRYPTION_KEY inseguro no .env"
ok "Variáveis de ambiente verificadas"

# 2. Pull das imagens
log "Baixando imagens..."
docker-compose -f "$COMPOSE_FILE" pull || true

# 3. Build local se necessário
log "Building imagens..."
docker-compose -f "$COMPOSE_FILE" build --no-cache

# 4. Migrations
log "Executando migrations..."
docker-compose -f "$COMPOSE_FILE" run --rm backend sh -c "npx prisma migrate deploy"
ok "Migrations executadas"

# 5. Deploy com zero-downtime (rolling update)
log "Deploy rolling update..."
export TAG
docker-compose -f "$COMPOSE_FILE" up -d --remove-orphans

# 6. Health check
log "Aguardando serviços ficarem saudáveis..."
sleep 10
for i in {1..12}; do
  if docker-compose -f "$COMPOSE_FILE" ps --services --filter status=healthy | grep -q backend; then
    ok "Backend saudável!"
    break
  fi
  [ $i -eq 12 ] && err "Backend não ficou saudável em 60s. Verifique os logs."
  sleep 5
done

# 7. Seed (apenas se nova instalação)
log "Verificando seed..."
docker-compose -f "$COMPOSE_FILE" exec -T backend sh -c \
  "node -e \"const { PrismaClient } = require('@prisma/client'); const p = new PrismaClient(); p.user.count().then(c => { if (c === 0) { console.log('SEED_NEEDED'); } }).finally(() => p.\$disconnect());\"" \
  | grep -q "SEED_NEEDED" && {
  log "Executando seed inicial..."
  docker-compose -f "$COMPOSE_FILE" exec -T backend sh -c "npx ts-node prisma/seed/seed.ts"
  ok "Seed executado"
}

# 8. Limpeza de imagens antigas
log "Limpando imagens antigas..."
docker image prune -f --filter "label=app=aureusbet" || true

ok "🎰 Deploy concluído! TAG: $TAG"
log "Frontend: https://app.aureusbet.com"
log "API:      https://api.aureusbet.com"
log "Admin:    https://admin.aureusbet.com"
