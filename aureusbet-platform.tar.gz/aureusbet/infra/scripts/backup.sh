#!/usr/bin/env bash
# ================================================================
# AureusBet — Backup automático (PostgreSQL + uploads)
# Configure via cron: 0 2 * * * /path/to/backup.sh
# ================================================================
set -euo pipefail

BACKUP_DIR="/var/backups/aureusbet"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30
S3_BACKUP_BUCKET=${S3_BACKUP_BUCKET:-"aureusbet-backups"}

log() { echo "[$(date '+%Y-%m-%d %T')] $*"; }

mkdir -p "$BACKUP_DIR/db" "$BACKUP_DIR/uploads"

# 1. Backup do banco
log "Iniciando backup do PostgreSQL..."
docker exec aureusbet_postgres_prod pg_dump \
  -U "${POSTGRES_USER:-aureusbet}" \
  "${POSTGRES_DB:-aureusbet}" \
  | gzip > "$BACKUP_DIR/db/aureusbet_${TIMESTAMP}.sql.gz"
log "DB backup: $BACKUP_DIR/db/aureusbet_${TIMESTAMP}.sql.gz"

# 2. Upload para S3
if command -v aws &> /dev/null; then
  log "Enviando backup para S3..."
  aws s3 cp "$BACKUP_DIR/db/aureusbet_${TIMESTAMP}.sql.gz" \
    "s3://$S3_BACKUP_BUCKET/db/aureusbet_${TIMESTAMP}.sql.gz" \
    --storage-class STANDARD_IA
  log "Backup enviado para S3"
fi

# 3. Limpeza de backups antigos
log "Removendo backups com mais de $RETENTION_DAYS dias..."
find "$BACKUP_DIR" -name "*.sql.gz" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +$RETENTION_DAYS -delete

# 4. Verificar integridade
BACKUP_SIZE=$(du -sh "$BACKUP_DIR/db/aureusbet_${TIMESTAMP}.sql.gz" | cut -f1)
log "✅ Backup concluído: $BACKUP_SIZE — $BACKUP_DIR/db/aureusbet_${TIMESTAMP}.sql.gz"
