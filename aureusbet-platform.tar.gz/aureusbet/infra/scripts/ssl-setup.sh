#!/usr/bin/env bash
# ================================================================
# AureusBet — Configurar certificados SSL com Let's Encrypt
# Uso: ./ssl-setup.sh seu-dominio.com email@dominio.com
# ================================================================
set -euo pipefail

DOMAIN=${1:-aureusbet.com}
EMAIL=${2:-admin@aureusbet.com}
SUBDOMAINS="app admin api"

certbot certonly --standalone --agree-tos --no-eff-email \
  -m "$EMAIL" \
  -d "$DOMAIN" \
  $(for sub in $SUBDOMAINS; do echo "-d $sub.$DOMAIN"; done)

echo "✅ Certificados SSL gerados para $DOMAIN e subdomínios"
echo "Renove automaticamente: certbot renew --quiet"

# Auto-renewal via cron
echo "0 3 * * * certbot renew --quiet && docker exec aureusbet_nginx_prod nginx -s reload" | crontab -
echo "✅ Renovação automática configurada"
