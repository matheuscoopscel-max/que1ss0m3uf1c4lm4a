#!/usr/bin/env bash
# ================================================================
# AureusBet — Restaurar backup do PostgreSQL
# Uso: ./restore.sh /caminho/para/backup.sql.gz
# ================================================================
set -euo pipefail

BACKUP_FILE=${1:-""}
[ -z "$BACKUP_FILE" ] && { echo "Uso: $0 /caminho/backup.sql.gz"; exit 1; }
[ -f "$BACKUP_FILE" ] || { echo "Arquivo não encontrado: $BACKUP_FILE"; exit 1; }

echo "⚠️  Isso irá SOBRESCREVER o banco atual. Confirme (s/N): "
read -r CONFIRM
[ "$CONFIRM" != "s" ] && { echo "Operação cancelada."; exit 0; }

echo "Restaurando backup..."
gunzip -c "$BACKUP_FILE" | docker exec -i aureusbet_postgres_prod psql \
  -U "${POSTGRES_USER:-aureusbet}" "${POSTGRES_DB:-aureusbet}"

echo "✅ Backup restaurado de: $BACKUP_FILE"
