// Shared types between frontend and backend

export interface ApiResponse<T = any> {
  success:   boolean;
  data:      T;
  timestamp: string;
}

export interface PaginatedResponse<T> {
  data:       T[];
  total:      number;
  page:       number;
  perPage:    number;
  totalPages: number;
}

export type UserRole     = 'PLAYER' | 'VIP' | 'MODERATOR' | 'ADMIN' | 'SUPER_ADMIN';
export type KycStatus    = 'NOT_SUBMITTED' | 'PENDING' | 'APPROVED' | 'REJECTED' | 'RESUBMIT_REQUIRED';
export type GameType     = 'CRASH' | 'ROULETTE' | 'BLACKJACK' | 'SLOTS' | 'DICE' | 'MINES' | 'TOWER' | 'COINFLIP';
export type Rarity       = 'COMMON' | 'RARE' | 'EPIC' | 'LEGENDARY' | 'MYTHIC';

export const RARITY_COLORS: Record<Rarity, string> = {
  COMMON:    '#9ca3af',
  RARE:      '#3b82f6',
  EPIC:      '#a855f7',
  LEGENDARY: '#f59e0b',
  MYTHIC:    '#ef4444',
};

export const RARITY_LABELS: Record<Rarity, string> = {
  COMMON:    'Comum',
  RARE:      'Raro',
  EPIC:      'Épico',
  LEGENDARY: 'Lendário',
  MYTHIC:    'Mítico',
};
